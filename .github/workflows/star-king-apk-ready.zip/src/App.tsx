import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Updates from './components/Updates';
import Services from './components/Services';
import Form from './components/Form';
import Tracking from './components/Tracking';
import WhyChooseUs from './components/WhyChooseUs';
import HowItWorks from './components/HowItWorks';
import LaunchOffer from './components/LaunchOffer';
import FAQ from './components/FAQ';
import Reviews from './components/Reviews';
import AdminPanel from './components/AdminPanel';
import GlobalFooter from './components/GlobalFooter';
import AboutPoliciesPage from './components/AboutPoliciesPage';
import InfoPages from './components/InfoPages';
import BottomNav, { ScreenType } from './components/BottomNav';
import { MessageCircle, ArrowUp, ShieldAlert, Users, Lock, X } from 'lucide-react';

export default function App() {
  const [activeScreen, setActiveScreen] = useState<ScreenType>('home');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [prefilledService, setPrefilledService] = useState('');
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [isInfoOpen, setIsInfoOpen] = useState(false);
  const [infoTab, setInfoTab] = useState('about');
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  const handleOpenInfoModal = (tab: string) => {
    setInfoTab(tab);
    setIsInfoOpen(true);
  };

  const handleSwitchScreen = (screen: ScreenType, initialTab?: string) => {
    if (initialTab) {
      setInfoTab(initialTab);
    }
    setActiveScreen(screen);
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  // Trigger switch to customer form screen
  const handleFormNavigate = () => {
    handleSwitchScreen('form');
  };

  const handleTrackingNavigate = () => {
    handleSwitchScreen('track');
  };

  // Handler for service card Apply buttons
  const handleApplyForService = (serviceName: string) => {
    setPrefilledService(serviceName);
    handleSwitchScreen('form');
  };

  // Scroll to top of current screen
  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDataChanged = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-wheat-cream flex flex-col justify-between font-sans selection:bg-deep-indigo/10 selection:text-deep-indigo pb-16 md:pb-0">
      
      {/* Non-Govt Notice Strip */}
      <div className="bg-turmeric-gold text-white text-center py-2 px-4 text-xs font-black flex items-center justify-center gap-2 relative z-50">
        <ShieldAlert className="w-4 h-4 shrink-0" />
        <span>સ્ટાર કિંગ નેટવર્ક એક સ્વતંત્ર ઓનલાઇન સેવા કેન્દ્ર છે, અમે કોઈ સરકારી સંસ્થા સાથે જોડાયેલા નથી.</span>
      </div>

      {/* Navigation Header */}
      <Header
        activeScreen={activeScreen}
        onNavigate={handleSwitchScreen}
        onRequestClick={handleFormNavigate}
        isMobileMenuOpen={isMobileMenuOpen}
        onToggleMobileMenu={() => setIsMobileMenuOpen(prev => !prev)}
        onCloseMobileMenu={() => setIsMobileMenuOpen(false)}
      />

      {/* Main Tab Screen Container with Smooth Fade Transition */}
      <div key={activeScreen} className="screen-fade-in flex-grow flex flex-col justify-between">
        <main className="flex-grow">
          {/* SCREEN 1: HOME */}
          {activeScreen === 'home' && (
            <div>
              {/* Hero Banner Section */}
              <Hero onFormScroll={handleFormNavigate} onTrackingScroll={handleTrackingNavigate} />

              {/* Why Choose Us Trust Markers with Hidden 3-Tap Admin Trigger */}
              <WhyChooseUs onSecretAdminTrigger={() => setIsAdminOpen(true)} />

              {/* Latest Updates Ticker */}
              <Updates onApplyForService={handleApplyForService} />

              {/* How It Works process steps */}
              <HowItWorks />

              {/* Launch Offer Premium Section */}
              <LaunchOffer onFormScroll={handleFormNavigate} />

              {/* FAQ Modern Accordion section */}
              <FAQ />

              {/* Social Proof Testimonials */}
              <Reviews />
            </div>
          )}

          {/* SCREEN 2: SERVICES */}
          {activeScreen === 'services' && (
            <div className="min-h-[70vh]">
              {/* Core Services Section */}
              <Services onApplyForService={handleApplyForService} />
            </div>
          )}

          {/* SCREEN 3: FORM */}
          {activeScreen === 'form' && (
            <div className="min-h-[70vh]">
              {/* Customer Information Submission Form */}
              <Form
                prefilledService={prefilledService}
                onRequestSubmitted={handleDataChanged}
                onNavigateHome={() => handleSwitchScreen('home')}
                onNavigateTrack={() => handleSwitchScreen('track')}
                onNavigateServices={() => handleSwitchScreen('services')}
              />
            </div>
          )}

          {/* SCREEN 4: TRACKING / STATUS */}
          {activeScreen === 'track' && (
            <div className="min-h-[70vh]">
              {/* Real-time Localized Tracking Center */}
              <Tracking refreshTrigger={refreshTrigger} />
            </div>
          )}

          {/* SCREEN 5: ABOUT & POLICIES (Dedicated Page) */}
          {activeScreen === 'about-policies' && (
            <div className="min-h-[70vh]">
              <AboutPoliciesPage
                onNavigate={handleSwitchScreen}
                initialTab={infoTab}
              />
            </div>
          )}
        </main>

        {/* Global Minimal Footer (Appears at the bottom of every page) */}
        <GlobalFooter onNavigate={handleSwitchScreen} />
      </div>

      {/* Secret Admin Panel Modal Overlay */}
      {isAdminOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex flex-col justify-start">
          <div className="min-h-screen bg-wheat-cream flex flex-col justify-between">
            {/* Top Admin Bar */}
            <div className="bg-deep-indigo text-white px-4 py-3 border-b border-turmeric-gold/30 flex items-center justify-between sticky top-0 z-50 shadow-md">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded bg-white/10 flex items-center justify-center border border-turmeric-gold/30">
                  <Lock className="w-4 h-4 text-turmeric-gold" />
                </div>
                <span className="font-heading font-bold text-sm text-white">
                  STAR KING NETWORK • એડમિનિસ્ટ્રેટર મેનેજમેન્ટ પેનલ
                </span>
              </div>

              <button
                onClick={() => setIsAdminOpen(false)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-all border border-white/20 cursor-pointer shadow-xs"
                title="બંધ કરો (Close)"
              >
                <X className="w-4 h-4" />
                <span>બંધ કરો (Close)</span>
              </button>
            </div>

            {/* Admin Dashboard & Login Content */}
            <div className="flex-1">
              <AdminPanel
                onDataChanged={handleDataChanged}
                refreshTrigger={refreshTrigger}
                onClose={() => setIsAdminOpen(false)}
              />
            </div>
          </div>
        </div>
      )}

      {/* Policy & Info Dialog Pages */}
      <InfoPages
        isOpen={isInfoOpen}
        initialTab={infoTab}
        onClose={() => setIsInfoOpen(false)}
      />

      {/* Interactive Floating Utilities for quick contact */}
      <div className="fixed bottom-20 md:bottom-6 right-4 sm:right-6 z-40 flex flex-col gap-2.5 sm:gap-3">
        
        {/* Floating Scroll to Top */}
        <button
          onClick={handleScrollToTop}
          className="w-11 h-11 sm:w-12 sm:h-12 rounded-md bg-white border border-deep-indigo/15 text-deep-indigo shadow-md flex items-center justify-center hover:bg-wheat-cream/30 transition-all hover:scale-105 active:scale-95 cursor-pointer"
          title="ટોચ પર જાઓ"
        >
          <ArrowUp className="w-5 h-5" />
        </button>

        {/* WhatsApp Group bubble */}
        <a
          href="https://chat.whatsapp.com/GUpckcU2YiSKa9WdyN87ZX?s=sh&p=a&mlu=0&ilr=0"
          target="_blank"
          rel="noopener noreferrer"
          className="w-11 h-11 sm:w-12 sm:h-12 rounded-md bg-field-green border border-white/20 text-white shadow-md flex items-center justify-center hover:bg-field-green/90 transition-all hover:scale-105 active:scale-95 cursor-pointer group"
          title="વોટ્સએપ ગ્રૂપમાં જોડાઓ"
        >
          <Users className="w-5 h-5" />
        </a>

        {/* Floating WhatsApp Quick Action Button */}
        <a
          href="https://wa.me/919726074581?text=નમસ્તે સ્ટાર કિંગ નેટવર્ક, મને ઓનલાઈન ફોર્મ અને સરકારી સેવાઓ માટે તમારી મદદ જોઈએ છે."
          target="_blank"
          rel="noopener noreferrer"
          className="w-12 h-12 sm:w-14 sm:h-14 rounded-md bg-field-green text-white shadow-md flex items-center justify-center hover:bg-field-green/90 transition-all hover:scale-110 active:scale-95 cursor-pointer border border-transparent hover:border-white/30"
          title="વોટ્સએપ ચેટ / કૉલ"
        >
          <MessageCircle className="w-6 h-6 sm:w-7 sm:h-7 fill-current" />
        </a>
      </div>

      {/* Fixed Mobile Bottom Navigation Bar (Visible only on mobile < md) */}
      <BottomNav
        activeScreen={activeScreen}
        onNavigate={handleSwitchScreen}
        isMobileMenuOpen={isMobileMenuOpen}
        onToggleMobileMenu={() => setIsMobileMenuOpen(prev => !prev)}
      />

    </div>
  );
}
