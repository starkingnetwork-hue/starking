// ============================================================================
// STAR KING NEXUS - CENTRAL SITE & SERVICE CONFIGURATION
// ============================================================================

export const SITE_CONFIG = {
  name: 'STAR KING NETWORK',
  tagline: 'ઓનલાઇન સેવા કેન્દ્ર • GUJARAT',
  shortDescription: 'STAR KING મને online form/application ભરવામાં મદદ કરે છે.',
  subText: 'સરકારી અને અન્ય ઓનલાઇન અરજીઓ માટે સરળ, ઝડપી અને વિશ્વસનીય સહાય પ્લેટફોર્મ.',
  
  // WhatsApp Configuration (Single Source of Truth)
  whatsapp: {
    rawNumber: '919726074581',
    displayNumber: '+91 97260 74581',
    defaultHelpMessage: 'નમસ્તે STAR KING NETWORK, મને ઓનલાઈન ફોર્મ અને સરકારી સેવાઓ માટે તમારી મદદ જોઈએ છે.',
    groupInviteUrl: 'https://chat.whatsapp.com/GUpckcU2YiSKa9WdyN87ZX?s=sh&p=a&mlu=0&ilr=0',
    getApplicationQueryMessage: (appId: string) => 
      `નમસ્તે STAR KING NETWORK,\nમારી અરજી ID: #${appId.replace(/^#/, '')} વિશે વાત કરવી છે.`,
    getTrackingHelpMessage: (appId?: string) => 
      appId 
        ? `નમસ્તે STAR KING NETWORK, મારી અરજી ID: #${appId.replace(/^#/, '')} નું સ્ટેટસ ચકાસવા માટે સહાય જોઈએ છે.`
        : `નમસ્તે STAR KING NETWORK, મારી અરજી ટ્રેક કરવામાં સમસ્યા આવી રહી છે. કૃપા કરીને સહાય કરશો.`
  },

  // Contact Details
  contact: {
    email: 'starkingnetwork@gmail.com',
    location: 'ગુજરાત, ભારત (Gujarat, India)',
    supportHours: 'સવારે ૯:૦૦ થી રાત્રે ૮:૦૦ (સોમવાર થી શનિવાર)'
  },

  // Disclaimer Statements
  disclaimer: {
    shortNotice: 'સ્ટાર કિંગ નેટવર્ક એક સ્વતંત્ર ઓનલાઇન સેવા કેન્દ્ર છે, અમે કોઈ સરકારી સંસ્થા સાથે જોડાયેલા નથી.',
    officialStatement: 'STAR KING NETWORK (સ્ટાર કિંગ નેટવર્ક) એ સંપૂર્ણપણે સ્વતંત્ર, વ્યાવસાયિક ઓનલાઇન સેવા સહાય પ્લેટફોર્મ છે. અમે ભારત સરકાર અથવા ગુજરાત સરકારના કોઈ પણ વિભાગ કે એજન્સી સાથે અધિકૃત જોડાણ ધરાવતા નથી. અમે ગ્રાહકો વતી જાહેરમાં ઉપલબ્ધ સરકારી પોર્ટલ પરથી ઓનલાઇન ફોર્મ સબમિટ કરવામાં માત્ર વ્યાવસાયિક માર્ગદર્શન અને સહાય પૂરી પાડીએ છીએ.'
  }
};

/**
 * Helper to build sanitized WhatsApp web/app link
 */
export function buildWhatsAppLink(message?: string): string {
  const text = message || SITE_CONFIG.whatsapp.defaultHelpMessage;
  return `https://wa.me/${SITE_CONFIG.whatsapp.rawNumber}?text=${encodeURIComponent(text)}`;
}
