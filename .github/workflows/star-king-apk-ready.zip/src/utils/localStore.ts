// ---------------------------------------------------------------------------
// LOCAL IN-MEMORY DATA LAYER (STAR KING NEXUS MVP)
// ---------------------------------------------------------------------------
// All operations run locally in memory using `mockData.ts`.
// No external database, Firebase, or Google Sheets connections are active.
// ---------------------------------------------------------------------------

import { CustomerRequest } from '../types';
import { saveNewRequest, getSavedRequests, updateRequestStatus } from './mockData';

export interface NewApplicationInput {
  fullName: string;
  mobile: string;
  village: string;
  taluka: string;
  district: string;
  service: string;
  message: string;
}

// Simple in-memory counter used to generate application IDs (e.g. SKN000042)
let localIdCounter = 41;

/**
 * Generates a sequential local Application ID.
 */
export function generateNextApplicationId(): string {
  localIdCounter += 1;
  return `SKN${String(localIdCounter).padStart(6, '0')}`;
}

/**
 * Saves a new application locally (in-memory store from mockData.ts).
 */
export async function submitApplication(data: NewApplicationInput): Promise<string> {
  // 1. Basic validation (same rules as before)
  if (!data.fullName || !data.fullName.trim()) {
    throw new Error('કૃપા કરીને અરજદારનું પૂરું નામ દાખલ કરો.');
  }
  const cleanMobile = (data.mobile || '').trim().replace(/[^0-9]/g, '');
  if (cleanMobile.length !== 10) {
    throw new Error('કૃપા કરીને માન્ય ૧૦-આંકડાનો મોબાઈલ નંબર દાખલ કરો.');
  }
  if (!data.district || !data.district.trim()) {
    throw new Error('કૃપા કરીને જિલ્લો પસંદ કરો.');
  }
  if (!data.taluka || !data.taluka.trim()) {
    throw new Error('કૃપા કરીને તાલુકો પસંદ કરો.');
  }
  if (!data.village || !data.village.trim()) {
    throw new Error('કૃપા કરીને ગામ / શહેરનું નામ દાખલ કરો.');
  }
  if (!data.service || !data.service.trim()) {
    throw new Error('કૃપા કરીને સેવા પસંદ કરો.');
  }

  // 2. Generate a local application ID
  const applicationId = generateNextApplicationId();
  const createdDateStr = new Date().toLocaleString('gu-IN', { timeZone: 'Asia/Kolkata' });

  // 3. Save to the local in-memory store
  saveNewRequest({
    id: applicationId,
    fullName: data.fullName.trim(),
    mobileNumber: cleanMobile,
    village: data.village.trim(),
    taluka: data.taluka.trim(),
    district: data.district.trim(),
    category: data.service.trim(),
    message: (data.message || '').trim(),
    createdAt: createdDateStr,
    status: 'સબમિટ કરેલ',
    notes: '',
    ipAddress: ''
  });

  return applicationId;
}

/**
 * Tracks an application using the local in-memory store.
 */
export async function trackApplication(appIdInput: string, mobileInput: string): Promise<CustomerRequest[]> {
  const cleanId = appIdInput.trim().replace(/^#/, '').toUpperCase();
  const cleanMobile = mobileInput.trim().replace(/[^0-9]/g, '');

  if (!cleanId || !cleanMobile) {
    return [];
  }

  const mobileLast4 = cleanMobile.slice(-4);

  const local = getSavedRequests().filter(
    r => r.id.toUpperCase() === cleanId && (
      r.mobileNumber.replace(/[^0-9]/g, '') === cleanMobile ||
      r.mobileNumber.replace(/[^0-9]/g, '').endsWith(mobileLast4)
    )
  );

  return local;
}

/**
 * Returns all locally saved applications for the Admin Panel.
 */
export async function fetchAllApplications(): Promise<CustomerRequest[]> {
  return getSavedRequests();
}

/**
 * Updates an application's status and notes in the local store.
 */
export async function updateApplicationDoc(
  docId: string,
  appId: string,
  status: CustomerRequest['status'],
  notes: string
): Promise<{ success: boolean; error?: string }> {
  const cleanId = (docId || appId).trim().replace(/^#/, '');
  updateRequestStatus(cleanId, status, notes);
  return { success: true };
}
