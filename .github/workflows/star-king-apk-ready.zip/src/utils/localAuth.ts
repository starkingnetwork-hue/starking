// ---------------------------------------------------------------------------
// DEMO ADMIN SESSION HELPER (LOCAL UI PREVIEW ONLY - NO HARDCODED CREDENTIALS)
// ---------------------------------------------------------------------------
// For frontend preview, this demo session helper enables interface navigation
// without hardcoded credentials or persistent PII storage.
// ---------------------------------------------------------------------------

const DEMO_SESSION_KEY = 'skn_demo_admin_active';

export function checkLocalAdminLogin(email: string, password?: string): boolean {
  // Demo mode check: Accepts any valid non-empty demo input for UI preview testing
  return Boolean(email && email.trim().length > 0 && password && password.trim().length > 0);
}

export function setLocalAdminSession(loggedIn: boolean): void {
  try {
    if (loggedIn) {
      sessionStorage.setItem(DEMO_SESSION_KEY, 'true');
    } else {
      sessionStorage.removeItem(DEMO_SESSION_KEY);
    }
  } catch {
    // In-memory fallback if sessionStorage is blocked
  }
}

export function getLocalAdminSession(): boolean {
  try {
    return sessionStorage.getItem(DEMO_SESSION_KEY) === 'true';
  } catch {
    return false;
  }
}

