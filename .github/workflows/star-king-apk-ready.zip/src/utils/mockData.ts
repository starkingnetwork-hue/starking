import { ServiceItem, NewsUpdate, CustomerReview, CustomerRequest } from '../types';

export const SERVICES: ServiceItem[] = [
  {
    id: 'aadhaar',
    title: 'Aadhaar Card',
    gujaratiTitle: 'આધાર કાર્ડ',
    description: 'નવું આધાર કાર્ડ, બાયોમેટ્રિક અપડેટ, સરનામું બદલવા અને મોબાઈલ નંબર લિંક કરવા સંબંધિત કામગીરી.',
    iconName: 'CreditCard',
    color: '#1B3A5C',
  },
  {
    id: 'pan',
    title: 'PAN Card',
    gujaratiTitle: 'પાન કાર્ડ',
    description: 'નવું ઇન્સ્ટન્ટ પાન કાર્ડ બનાવવા, નામ-જન્મતારીખમાં સુધારો કરવા અને ભૌતિક કાર્ડ મેળવવાની પ્રક્રિયા.',
    iconName: 'IdCard',
    color: '#1B3A5C',
  },
  {
    id: 'income-cert',
    title: 'Income Certificate',
    gujaratiTitle: 'આવકનો દાખલો',
    description: 'શાળા-કોલેજ પ્રવેશ અથવા સ્કોલરશીપ હેતુ માટે ૧ વર્ષ કે ૩ વર્ષની માન્યતા ધરાવતો આવકનો સત્તાવાર દાખલો.',
    iconName: 'FileText',
    color: '#1B3A5C',
  },
  {
    id: 'caste-cert',
    title: 'Caste Certificate',
    gujaratiTitle: 'જાતિનો દાખલો',
    description: 'સામાજિક અને શૈક્ષણિક પછાત વર્ગ (OBC/SEBC), EWS અને નોન-ક્રીમીલેયર પ્રમાણપત્રો મેળવવાની સુવિધા.',
    iconName: 'Users',
    color: '#1B3A5C',
  },
  {
    id: 'pm-kisan',
    title: 'PM Kisan',
    gujaratiTitle: 'પીએમ કિસાન',
    description: 'પ્રધાનમંત્રી કિસાન સન્માન નિધિ યોજના અંતર્ગત નવા ખાતા નોંધણી, બેંક સીડીંગ અને હપ્તા સ્ટેટસ ચકાસણી.',
    iconName: 'Sprout',
    color: '#1B3A5C',
  },
  {
    id: 'ayushman',
    title: 'Ayushman Card',
    gujaratiTitle: 'આયુષ્માન કાર્ડ',
    description: 'રૂપિયા ૫ લાખથી ૧૦ લાખ સુધીની નિઃશુલ્ક હોસ્પિટલ સારવાર પૂરી પાડતું સત્તાવાર આયુષ્માન પીએમ-જેવાય કાર્ડ.',
    iconName: 'Heart',
    color: '#1B3A5C',
  },
  {
    id: 'scholarship',
    title: 'Scholarship',
    gujaratiTitle: 'શિષ્યવૃત્તિ',
    description: 'ડિજિટલ ગુજરાત (Digital Gujarat) તથા રાષ્ટ્રીય શિષ્યવૃત્તિ પોર્ટલ (NSP) પર ઓનલાઈન ફોર્મ સબમિશન.',
    iconName: 'GraduationCap',
    color: '#1B3A5C',
  },
  {
    id: 'seven-twelve',
    title: '7/12 RoR',
    gujaratiTitle: '૭/૧૨ ના ઉતારા',
    description: 'જમીનના અધિકાર પત્રો (RoR) જેવા કે ૭/૧૨, ૮-અ અને ગામ નમૂના નંબર ૬ ની હક્ક પત્રક નકલો મેળવો.',
    iconName: 'FileSpreadsheet',
    color: '#1B3A5C',
  },
  {
    id: 'ration-card',
    title: 'રેશન કાર્ડ',
    gujaratiTitle: 'રેશન કાર્ડ',
    description: 'નવું રેશન કાર્ડ બનાવવા, વિભાજન કરવા, નવા સભ્યનું નામ ઉમેરવા કે કમી કરવા સંબંધી તમામ ઓનલાઇન સેવાઓ.',
    iconName: 'FileCheck',
    color: '#1B3A5C',
  },
];

export const NEWS_UPDATES: NewsUpdate[] = [
  {
    id: 'news-pc',
    title: 'ગુજરાત પોલીસ કોન્સ્ટેબલ ભરતી ફોર્મ ચાલુ છે. (સત્વરે અરજી કરો)',
    date: '15-07-2026',
    category: 'નવી ભરતી',
    isUrgent: true,
  },
  {
    id: 'news-subsidy',
    title: 'i-Khedut સહાય: ખેડૂત સાધન સબસિડી યોજના મંજૂર.',
    date: '15-07-2026',
    category: 'ખેડૂત',
    isUrgent: true,
    status: 'મંજૂર',
  },
  {
    id: 'news-1',
    title: 'ગુજરાત ગૌણ સેવા (GSSSB) દ્વારા જુનિયર ક્લાર્કની નવી ભરતીના ફોર્મ શરૂ થયા.',
    date: '15-07-2026',
    category: 'નવી ભરતી',
    isUrgent: false,
  },
  {
    id: 'news-2',
    title: 'આઈ-ખેડૂત પોર્ટલ પર સ્માર્ટફોન સહાય અને સોલાર પેનલ સબસિડીના ફોર્મ ભરવાના શરૂ.',
    date: '14-07-2026',
    category: 'ખેડૂત',
    isUrgent: false,
  },
  {
    id: 'news-3',
    title: 'ડિજિટલ ગુજરાત સ્કોલરશીપ (સેમિસ્ટર ૧ અને ૨) અરજી પ્રક્રિયા શરૂ થઈ ગઈ છે.',
    date: '12-07-2026',
    category: 'સ્કૉલરશિપ',
    isUrgent: false,
  },
  {
    id: 'news-4',
    title: 'વિકાસશીલ જાતિ કલ્યાણ ખાતાની યોજના હેઠળ ટેબલેટ સહાય યોજના.',
    date: '10-07-2026',
    category: 'સરકારી યોજના',
    isUrgent: false,
  },
];

export const REVIEWS: CustomerReview[] = [
  {
    id: 'rev-1',
    name: 'ભાવેશભાઈ પટેલ',
    village: 'ગાંધીનગર',
    rating: 5,
    text: 'સ્ટાર કિંગ નેટવર્ક દ્વારા મેં આઈ-ખેડૂત ફોર્મ ભરાવ્યું હતું. ફોર્મ સચોટ ભરાયું અને સહાય પણ મંજૂર થઈ ગઈ. તેઓની સેવા ખુબ સરસ છે.',
    date: 'છેલ્લા અઠવાડિયે',
  },
  {
    id: 'rev-2',
    name: 'જયેશભાઈ સોલંકી',
    village: 'ગારિયાધાર, ભાવનગર',
    rating: 5,
    text: 'ઓનલાઇન ભરતીનું ફોર્મ સબમિટ કરવા માટે સૌથી ઝડપી સર્વિસ. ઘરે બેઠા કામ થઈ ગયું અને વોટ્સએપ પર જ હોલ ટીકીટ પણ મળી ગઈ.',
    date: '૧૫ દિવસ પહેલાં',
  },
  {
    id: 'rev-3',
    name: 'મનીષાબેન ડાભી',
    village: 'ગોંડલ',
    rating: 5,
    text: 'દિજિટલ ગુજરાત સ્કોલરશીપ ફોર્મ ખુબ જ ચોકસાઈ પૂર્વક ભરી આપ્યું. દસ્તાવેજોમાં કોઈ ભૂલ ન રહી જેથી શિષ્યવૃત્તિ બેંક ખાતામાં આવી ગઈ.',
    date: '૧ મહિનો પહેલાં',
  },
];

// In-memory requests storage for local demo MVP (session-only persistence)
let inMemoryRequests: CustomerRequest[] = [
  {
    id: 'SKN000041',
    fullName: 'રમેશભાઈ કાંતિલાલ પટેલ',
    mobileNumber: '9876543210',
    village: 'સરધાર',
    taluka: 'રાજકોટ',
    district: 'રાજકોટ',
    category: 'આવકનો દાખલો (Income Certificate)',
    message: 'કોલેજ એડમિશન માટે આવકના દાખલાની જરૂર છે.',
    createdAt: '14/09/2026, 11:30:00 AM',
    status: 'પ્રક્રિયા હેઠળ',
    notes: 'દસ્તાવેજો ચકાસી મામલતદાર કચેરી પોર્ટલ પર અપલોડ કરેલ છે.',
    ipAddress: ''
  },
  {
    id: 'SKN000040',
    fullName: 'પ્રિયાબેન દિનેશભાઈ સોલંકી',
    mobileNumber: '9898989898',
    village: 'વડનગર',
    taluka: 'વડનગર',
    district: 'મહેસાણા',
    category: 'ડિજિટલ ગુજરાત સ્કોલરશીપ',
    message: 'પોસ્ટ મેટ્રિક સ્કોલરશીપ રીન્યુઅલ.',
    createdAt: '12/09/2026, 02:15:00 PM',
    status: 'પૂર્ણ થયેલ',
    notes: 'સ્કોલરશીપ ફોર્મ મંજૂર થયેલ છે. એકનોલેજમેન્ટ વોટ્સએપ કરેલ છે.',
    ipAddress: ''
  }
];

export const getSavedRequests = (): CustomerRequest[] => {
  return inMemoryRequests;
};

export const saveNewRequest = (request: CustomerRequest): CustomerRequest => {
  // Prevent duplicate items in the list and insert at the top
  const exists = inMemoryRequests.some((r) => r.id === request.id);
  if (exists) {
    inMemoryRequests = inMemoryRequests.map((r) => r.id === request.id ? request : r);
  } else {
    inMemoryRequests.unshift(request);
  }
  return request;
};

export const updateRequestStatus = (id: string, status: CustomerRequest['status'], notes?: string): CustomerRequest[] => {
  inMemoryRequests = inMemoryRequests.map((req) => {
    if (req.id === id) {
      return { ...req, status, notes };
    }
    return req;
  });
  return inMemoryRequests;
};

export const deleteRequest = (id: string): CustomerRequest[] => {
  inMemoryRequests = inMemoryRequests.filter((req) => req.id !== id);
  return inMemoryRequests;
};
