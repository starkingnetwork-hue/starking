export interface CustomerRequest {
  id: string;
  docId?: string;
  fullName: string;
  mobileNumber: string;
  village: string;
  taluka: string;
  district: string;
  category: string;
  message: string;
  createdAt: string;
  status: 'સબમિટ કરેલ' | 'દસ્તાવેજ ચકાસણી' | 'પ્રક્રિયા હેઠળ' | 'પૂર્ણ થયેલ' | 'અસ્વીકાર';
  notes?: string;
  ipAddress?: string;
  email?: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  gujaratiTitle: string;
  description: string;
  iconName: string;
  color: string;
}

export interface NewsUpdate {
  id: string;
  title: string;
  date: string;
  category: 'નવી ભરતી' | 'સરકારી યોજના' | 'ખેડૂત' | 'સ્કૉલરશિપ';
  isUrgent?: boolean;
  status?: string;
}

export interface ActiveFormItem {
  id: string;
  title: string;
  englishTitle?: string;
  category: string;
  categoryKey: 'schemes' | 'recruitment' | 'ikhedut' | 'scholarship' | 'admission' | 'other';
  categoryBadge: string;
  status: 'active' | 'closing_soon' | 'upcoming';
  statusText: string;
  deadline: string;
  deadlineRaw?: string;
  daysLeft?: number;
  department: string;
  eligibility: string;
  documents: string[];
  description: string;
  feeNote?: string;
  popular?: boolean;
}

export interface ServiceCategoryInfo {
  key: 'schemes' | 'recruitment' | 'ikhedut' | 'scholarship' | 'admission' | 'other';
  title: string;
  subtitle: string;
  iconName: string;
  color: string;
  badge: string;
  count: number;
}

export interface CustomerReview {
  id: string;
  name: string;
  village: string;
  rating: number;
  text: string;
  date: string;
}
