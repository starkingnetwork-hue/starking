import React from 'react';

export type ScreenType = 'home' | 'services' | 'form' | 'track' | 'about-policies';

interface GlobalFooterProps {
  onNavigate: (screen: ScreenType, initialTab?: string) => void;
}

export default function GlobalFooter({ onNavigate }: GlobalFooterProps) {
  return (
    <footer className="bg-deep-indigo text-white py-8 border-t border-white/10 text-center">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        
        {/* Brand Header */}
        <div className="flex flex-col items-center justify-center space-y-2">
          
          <div className="flex items-center gap-2.5">
            <img 
              src="/star_king_logo.png" 
              alt="STAR KING NETWORK" 
              className="w-10 h-10 object-contain object-center shrink-0"
            />

            <div className="text-left">
              <span className="text-base font-heading font-black tracking-tight text-white block leading-tight">
                STAR KING NETWORK
              </span>
              <span className="text-[9px] text-turmeric-gold font-bold uppercase tracking-widest block leading-tight">
                Digital Service Platform
              </span>
            </div>
          </div>

          {/* Short Tagline */}
          <p className="text-xs text-gray-300 font-medium">
            “ગુજરાતના નાગરિકો માટે વિશ્વસનીય ઓનલાઈન સેવા સહાય પ્લેટફોર્મ.”
          </p>

        </div>

        {/* Minimal Footer Navigation */}
        <nav aria-label="Footer Navigation" className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs font-bold text-gray-300">
          <button
            type="button"
            onClick={() => onNavigate('about-policies', 'about')}
            className="hover:text-turmeric-gold transition-colors cursor-pointer"
          >
            About & Policies
          </button>
          
          <span className="text-white/20 hidden sm:inline">•</span>

          <button
            type="button"
            onClick={() => onNavigate('about-policies', 'contact')}
            className="hover:text-turmeric-gold transition-colors cursor-pointer"
          >
            Contact
          </button>

          <span className="text-white/20 hidden sm:inline">•</span>

          <button
            type="button"
            onClick={() => onNavigate('about-policies', 'privacy')}
            className="hover:text-turmeric-gold transition-colors cursor-pointer"
          >
            Privacy
          </button>

          <span className="text-white/20 hidden sm:inline">•</span>

          <button
            type="button"
            onClick={() => onNavigate('about-policies', 'terms')}
            className="hover:text-turmeric-gold transition-colors cursor-pointer"
          >
            Terms
          </button>

          <span className="text-white/20 hidden sm:inline">•</span>

          <button
            type="button"
            onClick={() => onNavigate('about-policies', 'refund')}
            className="hover:text-turmeric-gold transition-colors cursor-pointer"
          >
            Refund
          </button>
        </nav>

        {/* Copyright */}
        <div className="pt-4 border-t border-white/10 text-[11px] text-gray-400 font-medium">
          © ૨૦૨૬ STAR KING NETWORK. સર્વ હક સ્વાધીન.
        </div>

      </div>
    </footer>
  );
}
