import React from 'react';
import { 
  ShieldCheck, 
  Scale, 
  Receipt, 
  Info, 
  ArrowRight, 
  ChevronRight,
  Sparkles
} from 'lucide-react';

export type PolicyType = 'privacy' | 'terms' | 'refund' | 'about';

export interface PolicyCardProps {
  id: PolicyType;
  title: string;
  englishTitle: string;
  description: string;
  iconName: 'privacy' | 'terms' | 'refund' | 'about';
  onReadMore: (id: PolicyType) => void;
  badge?: string;
}

export default function PolicyCard({
  id,
  title,
  englishTitle,
  description,
  iconName,
  onReadMore,
  badge
}: PolicyCardProps) {
  const getIcon = () => {
    switch (iconName) {
      case 'privacy':
        return <ShieldCheck className="w-5 h-5 text-field-green" />;
      case 'terms':
        return <Scale className="w-5 h-5 text-deep-indigo" />;
      case 'refund':
        return <Receipt className="w-5 h-5 text-turmeric-gold" />;
      case 'about':
      default:
        return <Info className="w-5 h-5 text-deep-indigo" />;
    }
  };

  const getAccentColor = () => {
    switch (iconName) {
      case 'privacy':
        return 'hover:border-field-green/40 hover:shadow-field-green/5';
      case 'terms':
        return 'hover:border-deep-indigo/40 hover:shadow-deep-indigo/5';
      case 'refund':
        return 'hover:border-turmeric-gold/40 hover:shadow-turmeric-gold/5';
      case 'about':
      default:
        return 'hover:border-deep-indigo/40 hover:shadow-deep-indigo/5';
    }
  };

  return (
    <div 
      onClick={() => onReadMore(id)}
      className={`group bg-white rounded-2xl border border-deep-indigo/15 p-5 sm:p-6 shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col justify-between text-left ${getAccentColor()}`}
    >
      <div className="space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="w-10 h-10 rounded-xl bg-wheat-cream/50 border border-deep-indigo/10 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
            {getIcon()}
          </div>
          {badge && (
            <span className="text-[10px] font-bold text-field-green bg-field-green/10 border border-field-green/20 px-2 py-0.5 rounded-full">
              {badge}
            </span>
          )}
        </div>

        <div>
          <h4 className="text-base font-heading font-black text-deep-indigo group-hover:text-deep-indigo transition-colors flex items-center gap-1.5">
            <span>{title}</span>
          </h4>
          <p className="text-[11px] font-extrabold uppercase tracking-wider text-warm-gray mt-0.5">
            {englishTitle}
          </p>
        </div>

        <p className="text-xs text-gray-600 leading-relaxed font-medium line-clamp-3">
          {description}
        </p>
      </div>

      <div className="pt-4 mt-3 border-t border-gray-100 flex items-center justify-between">
        <span className="text-xs font-bold text-deep-indigo group-hover:text-field-green transition-colors inline-flex items-center gap-1">
          <span>વિગતવાર વાંચો (Read More)</span>
          <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform text-turmeric-gold" />
        </span>
        <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-deep-indigo transition-colors" />
      </div>
    </div>
  );
}
