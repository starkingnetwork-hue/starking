import React from 'react';
import { Home, LayoutGrid, FileEdit, Search, Info } from 'lucide-react';

export type ScreenType = 'home' | 'services' | 'form' | 'track' | 'about-policies';

interface BottomNavProps {
  activeScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
  isMobileMenuOpen: boolean;
  onToggleMobileMenu: () => void;
}

export default function BottomNav({
  activeScreen,
  onNavigate,
  isMobileMenuOpen,
  onToggleMobileMenu,
}: BottomNavProps) {
  const isHomeActive = activeScreen === 'home' && !isMobileMenuOpen;
  const isServicesActive = activeScreen === 'services' && !isMobileMenuOpen;
  const isFormActive = activeScreen === 'form' && !isMobileMenuOpen;
  const isTrackingActive = activeScreen === 'track' && !isMobileMenuOpen;
  const isAboutPoliciesActive = activeScreen === 'about-policies' && !isMobileMenuOpen;

  return (
    <nav
      aria-label="Mobile Navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/98 backdrop-blur-md border-t border-deep-indigo/15 shadow-[0_-3px_12px_rgba(27,58,92,0.08)] pb-[max(env(safe-area-inset-bottom,0px),0.4rem)] pt-1"
    >
      <div className="max-w-md mx-auto px-1 grid grid-cols-5 items-center justify-items-center">
        
        {/* 1. હોમ (Home Screen) */}
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className={`flex flex-col items-center justify-center w-full min-h-[48px] py-1 transition-colors duration-100 cursor-pointer ${
            isHomeActive
              ? 'text-deep-indigo font-black'
              : 'text-warm-gray hover:text-deep-indigo font-bold'
          }`}
          aria-label="હોમ પેજ"
        >
          <div className="relative flex items-center justify-center">
            <Home className={`w-5 h-5 transition-transform ${isHomeActive ? 'stroke-[2.5px] text-deep-indigo' : 'stroke-[1.75px]'}`} />
            {isHomeActive && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-turmeric-gold rounded-full" />
            )}
          </div>
          <span className="text-[10px] sm:text-[11px] mt-0.5 tracking-tight">હોમ</span>
        </button>

        {/* 2. સેવાઓ (Services Screen) */}
        <button
          type="button"
          onClick={() => onNavigate('services')}
          className={`flex flex-col items-center justify-center w-full min-h-[48px] py-1 transition-colors duration-100 cursor-pointer ${
            isServicesActive
              ? 'text-deep-indigo font-black'
              : 'text-warm-gray hover:text-deep-indigo font-bold'
          }`}
          aria-label="સેવાઓ"
        >
          <div className="relative flex items-center justify-center">
            <LayoutGrid className={`w-5 h-5 transition-transform ${isServicesActive ? 'stroke-[2.5px] text-deep-indigo' : 'stroke-[1.75px]'}`} />
            {isServicesActive && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-turmeric-gold rounded-full" />
            )}
          </div>
          <span className="text-[10px] sm:text-[11px] mt-0.5 tracking-tight">સેવાઓ</span>
        </button>

        {/* 3. ફોર્મ ભરો (Form Screen - Primary Raised Action) */}
        <button
          type="button"
          onClick={() => onNavigate('form')}
          className="flex flex-col items-center justify-center w-full min-h-[48px] -mt-3.5 transition-colors duration-100 cursor-pointer group"
          aria-label="ફોર્મ ભરો"
        >
          <div
            className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full flex items-center justify-center shadow-md transition-all duration-150 border-2 border-white ring-2 ${
              isFormActive
                ? 'bg-turmeric-gold text-deep-indigo ring-deep-indigo scale-105 shadow-lg'
                : 'bg-deep-indigo text-white ring-turmeric-gold/50 group-hover:bg-deep-indigo-hover'
            }`}
          >
            <FileEdit className="w-5 h-5 stroke-[2.25px]" />
          </div>
          <span
            className={`text-[10px] sm:text-[11px] mt-0.5 tracking-tight font-black ${
              isFormActive ? 'text-deep-indigo' : 'text-deep-indigo'
            }`}
          >
            ફોર્મ ભરો
          </span>
        </button>

        {/* 4. સ્ટેટસ (Tracking / Status Screen) */}
        <button
          type="button"
          onClick={() => onNavigate('track')}
          className={`flex flex-col items-center justify-center w-full min-h-[48px] py-1 transition-colors duration-100 cursor-pointer ${
            isTrackingActive
              ? 'text-deep-indigo font-black'
              : 'text-warm-gray hover:text-deep-indigo font-bold'
          }`}
          aria-label="સ્ટેટસ તપાસો"
        >
          <div className="relative flex items-center justify-center">
            <Search className={`w-5 h-5 transition-transform ${isTrackingActive ? 'stroke-[2.5px] text-deep-indigo' : 'stroke-[1.75px]'}`} />
            {isTrackingActive && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-turmeric-gold rounded-full" />
            )}
          </div>
          <span className="text-[10px] sm:text-[11px] mt-0.5 tracking-tight">સ્ટેટસ</span>
        </button>

        {/* 5. About & Policies */}
        <button
          type="button"
          onClick={() => onNavigate('about-policies')}
          className={`flex flex-col items-center justify-center w-full min-h-[48px] py-1 transition-colors duration-100 cursor-pointer ${
            isAboutPoliciesActive
              ? 'text-deep-indigo font-black'
              : 'text-warm-gray hover:text-deep-indigo font-bold'
          }`}
          aria-label="અમારા વિશે અને પોલિસી"
        >
          <div className="relative flex items-center justify-center">
            <Info className={`w-5 h-5 transition-transform ${isAboutPoliciesActive ? 'stroke-[2.5px] text-deep-indigo' : 'stroke-[1.75px]'}`} />
            {isAboutPoliciesActive && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-turmeric-gold rounded-full" />
            )}
          </div>
          <span className="text-[10px] sm:text-[11px] mt-0.5 tracking-tight">About</span>
        </button>

      </div>
    </nav>
  );
}
