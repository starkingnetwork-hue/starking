import React, { useRef } from 'react';
import { ShieldCheck, Zap, MessageCircle, Award } from 'lucide-react';

interface WhyChooseUsProps {
  onSecretAdminTrigger?: () => void;
}

export default function WhyChooseUs({ onSecretAdminTrigger }: WhyChooseUsProps) {
  const clickCountRef = useRef(0);
  const resetTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleSecretTrigger = () => {
    clickCountRef.current += 1;

    if (resetTimerRef.current) {
      clearTimeout(resetTimerRef.current);
    }

    if (clickCountRef.current >= 3) {
      clickCountRef.current = 0;
      if (onSecretAdminTrigger) {
        onSecretAdminTrigger();
      }
    } else {
      resetTimerRef.current = setTimeout(() => {
        clickCountRef.current = 0;
      }, 3000);
    }
  };

  const reasons = [
    {
      icon: ShieldCheck,
      title: 'Secure Service (સુરક્ષિત સેવા)',
      description: 'અમે તમારા સંવેદનશીલ દસ્તાવેજો (આધાર, પાન, બેંક વગેરે) અત્યંત સુરક્ષિત અને ગોપનીય રાખીએ છીએ. ડેટા લીક કે અન્ય કોઈ જોખમ રહેતું નથી.',
      color: 'bg-white text-deep-indigo border border-deep-indigo/15',
    },
    {
      icon: Zap,
      title: 'Fast Process (ઝડપી પ્રક્રિયા)',
      description: 'તમારા દ્વારા મોકલવામાં આવેલ માહિતીના આધારે ગણતરીની મિનિટો કે કલાકોમાં ચોકસાઈપૂર્વક ફોર્મ ઓનલાઇન ભરી દેવામાં આવે છે.',
      color: 'bg-white text-field-green border border-deep-indigo/15',
    },
    {
      icon: MessageCircle,
      title: 'WhatsApp Support (વોટ્સએપ સપોર્ટ)',
      description: 'તમારે ધક્કા ખાવાની જરૂર નથી. કોઈપણ પ્રશ્ન અથવા દસ્તાવેજ માર્ગદર્શન માટે સીધો વોટ્સએપ પર અમારો ત્વરિત સંપર્ક કરી શકો છો.',
      color: 'bg-white text-turmeric-gold border border-deep-indigo/15',
    },
    {
      icon: Award,
      title: 'Trusted Platform (ભરોસાપાત્ર પ્લેટફોર્મ)',
      description: 'સ્ટાર કિંગ નેટવર્ક એ હજારો સંતુષ્ટ ગ્રાહકો ધરાવતું ગુજરાતનું અગ્રણી અને સંપૂર્ણ પારદર્શક ઓનલાઇન ડિજિટલ સેવા પ્લેટફોર્મ છે.',
      color: 'bg-white text-deep-indigo border border-deep-indigo/15',
    },
  ];

  return (
    <section id="why-us" className="py-16 sm:py-24 bg-wheat-cream/30 relative border-b border-deep-indigo/10">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-deep-indigo/10 text-deep-indigo rounded-md text-xs font-bold border border-deep-indigo/15">
            <Award className="w-3.5 h-3.5 text-turmeric-gold" />
            <span>શા માટે અમારી પસંદગી?</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-heading font-bold text-deep-indigo">
            શા માટે પસંદ કરશો STAR KING?
          </h2>
          <p className="text-warm-gray text-sm sm:text-base">
            ગુજરાતના હજારો નાગરિકો અમારી ઝડપી અને પારદર્શક ડિજિટલ સેવાઓ પર ૧૦૦% વિશ્વાસ ધરાવે છે.
          </p>
        </div>

        {/* Reasons Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {reasons.map((reason, idx) => {
            const IconComponent = reason.icon;
            const isFastProcess = reason.icon === Zap;
            return (
              <div
                key={idx}
                onClick={isFastProcess ? handleSecretTrigger : undefined}
                className="bg-white border border-deep-indigo/15 p-5 sm:p-6 rounded-sm shadow-xs hover:border-turmeric-gold transition-colors duration-150 flex flex-col items-center text-center space-y-3.5 cursor-pointer"
              >
                <div className={`w-12 h-12 rounded-sm ${reason.color} flex items-center justify-center`}>
                  <IconComponent className="w-6 h-6" />
                </div>
                
                <h3 className="font-heading font-black text-deep-indigo text-base sm:text-lg">
                  {reason.title}
                </h3>
                
                <p className="text-warm-gray text-xs sm:text-sm leading-relaxed font-semibold">
                  {reason.description}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
