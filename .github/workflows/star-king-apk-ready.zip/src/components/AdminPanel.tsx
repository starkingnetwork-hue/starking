import React, { useState, useEffect } from 'react';
import { fetchAllApplications, updateApplicationDoc } from '../utils/localStore';
import { checkLocalAdminLogin, setLocalAdminSession, getLocalAdminSession } from '../utils/localAuth';
import { CustomerRequest } from '../types';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { 
  Database, 
  Search, 
  CheckCircle2, 
  ShieldAlert, 
  Lock, 
  Download, 
  RefreshCw, 
  Clock, 
  Loader2, 
  AlertCircle,
  FileText,
  Eye,
  X,
  Save,
  Phone,
  MapPin,
  Globe,
  LogOut
} from 'lucide-react';

interface AdminPanelProps {
  onDataChanged: () => void;
  refreshTrigger: number;
  onClose?: () => void;
}

export default function AdminPanel({ onDataChanged, refreshTrigger, onClose }: AdminPanelProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(() => getLocalAdminSession());
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const [requests, setRequests] = useState<CustomerRequest[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Modal View / Edit Details State
  const [selectedRequest, setSelectedRequest] = useState<CustomerRequest | null>(null);
  const [editStatus, setEditStatus] = useState<CustomerRequest['status']>('સબમિટ કરેલ');
  const [editNotes, setEditNotes] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);
  const [saveErrorMessage, setSaveErrorMessage] = useState<string | null>(null);

  // Filters state
  const [filterDistrict, setFilterDistrict] = useState('તમામ');
  const [filterService, setFilterService] = useState('તમામ');
  const [filterStatus, setFilterStatus] = useState('All'); // 'All' | 'Pending' | 'Processing' | 'Completed'
  const [searchTerm, setSearchTerm] = useState('');

  // Fetch data function from the local store
  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await fetchAllApplications();
      setRequests(data);
    } catch (err: any) {
      console.error("Failed to load applications data:", err);
      setError("ડેટા મેળવવામાં નિષ્ફળતા મળી છે.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      loadData();
    }
  }, [isAuthenticated, refreshTrigger]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setIsLoggingIn(true);

    try {
      const ok = checkLocalAdminLogin(email, password);
      if (ok) {
        setLocalAdminSession(true);
        setIsAuthenticated(true);
        setEmail('');
        setPassword('');
      } else {
        setLoginError('ઈમેલ અથવા પાસવર્ડ ખોટો છે.');
      }
    } catch (err: any) {
      console.error("Login failed:", err);
      setLoginError('કંઈક ખોટું થયું છે. ફરી પ્રયાસ કરો.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = () => {
    setLocalAdminSession(false);
    setIsAuthenticated(false);
    setRequests([]);
  };

  // Open Details Modal
  const handleOpenDetails = (req: CustomerRequest) => {
    setSelectedRequest(req);
    setEditStatus(req.status);
    setEditNotes(req.notes || '');
    setSaveSuccessMessage(null);
    setSaveErrorMessage(null);
  };

  // Close Details Modal
  const handleCloseDetails = () => {
    if (isSaving) return;
    setSelectedRequest(null);
    setSaveSuccessMessage(null);
    setSaveErrorMessage(null);
  };

  // Save Status & Notes to Firestore
  const handleSaveDetails = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!selectedRequest) return;

    setIsSaving(true);
    setSaveSuccessMessage(null);
    setSaveErrorMessage(null);

    try {
      const result = await updateApplicationDoc(
        selectedRequest.docId || '',
        selectedRequest.id,
        editStatus,
        editNotes
      );

      if (result.success) {
        // Update local state immediately without full page refresh
        setRequests((prev) =>
          prev.map((r) =>
            r.id === selectedRequest.id
              ? { ...r, status: editStatus, notes: editNotes }
              : r
          )
        );

        // Update active selection
        setSelectedRequest((prev) =>
          prev ? { ...prev, status: editStatus, notes: editNotes } : null
        );

        setSaveSuccessMessage('અરજી સ્ટેટસ અને નોંધ સફળતાપૂર્વક સાચવવામાં આવી છે!');
        onDataChanged();

        // Close modal after brief confirmation
        setTimeout(() => {
          handleCloseDetails();
        }, 900);
      } else {
        setSaveErrorMessage(result.error || 'અપડેટ કરવામાં ભૂલ આવી છે.');
      }
    } catch (err: any) {
      setSaveErrorMessage(err.message || 'સર્વર સાથે જોડાણ થઈ શક્યું નથી.');
    } finally {
      setIsSaving(false);
    }
  };

  // Unique districts & services for filtering dropdowns
  const districts = ['તમામ', ...Array.from(new Set(requests.map((r) => r.district).filter(Boolean)))];
  const services = ['તમામ', ...Array.from(new Set(requests.map((r) => r.category).filter(Boolean)))];

  // Map request status to logical categories
  const matchesStatusCategory = (reqStatus: CustomerRequest['status'], category: string) => {
    if (category === 'All') return true;
    if (category === 'Pending') {
      return reqStatus === 'સબમિટ કરેલ';
    }
    if (category === 'Processing') {
      return reqStatus === 'દસ્તાવેજ ચકાસણી' || reqStatus === 'પ્રક્રિયા હેઠળ';
    }
    if (category === 'Completed') {
      return reqStatus === 'પૂર્ણ થયેલ';
    }
    return true;
  };

  // Filter requests
  const filteredRequests = requests.filter((req) => {
    const matchesDistrict = filterDistrict === 'તમામ' || req.district === filterDistrict;
    const matchesService = filterService === 'તમામ' || req.category === filterService;
    const matchesStatus = matchesStatusCategory(req.status, filterStatus);
    
    const term = searchTerm.toLowerCase().trim();
    const matchesSearch = !term || 
      req.fullName.toLowerCase().includes(term) ||
      req.mobileNumber.includes(term) ||
      req.id.toLowerCase().includes(term);

    return matchesDistrict && matchesService && matchesStatus && matchesSearch;
  });

  // Calculate Dashboard KPIs based on raw requests
  const totalRequests = requests.length;
  const pendingRequests = requests.filter(r => r.status === 'સબમિટ કરેલ').length;
  const processingRequests = requests.filter(r => r.status === 'દસ્તાવેજ ચકાસણી' || r.status === 'પ્રક્રિયા હેઠળ').length;
  const completedRequests = requests.filter(r => r.status === 'પૂર્ણ થયેલ').length;

  const exportToCSV = () => {
    const headers = 'Application ID,Date,Full Name,Mobile,Village,Taluka,District,Service,IP Address,Status,Notes\n';
    const rows = filteredRequests.map(r => 
      `"${r.id}","${r.createdAt}","${r.fullName}","${r.mobileNumber}","${r.village}","${r.taluka}","${r.district}","${r.category}","${r.ipAddress || ''}","${r.status}","${r.notes || ''}"`
    ).join('\n');
    
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `starking_requests_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportToPDF = async () => {
    const element = document.getElementById('pdf-report-content');
    if (!element) {
      console.error("PDF report container element not found");
      return;
    }
    
    setIsGeneratingPDF(true);
    try {
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210; // A4 width in mm
      const pageHeight = 297; // A4 height in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;
      
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight, '', 'FAST');
      heightLeft -= pageHeight;
      
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight, '', 'FAST');
        heightLeft -= pageHeight;
      }
      
      pdf.save(`starking_network_pdf_report_${Date.now()}.pdf`);
    } catch (err) {
      console.error("Failed to generate PDF:", err);
      alert("પીડીએફ રીપોર્ટ બનાવવામાં ભૂલ આવી છે.");
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <section id="admin" className="py-16 bg-wheat-cream/30 relative border-t border-deep-indigo/15">
        <div className="max-w-md mx-auto px-4">
          <div className="bg-white p-8 rounded-md border border-deep-indigo/15 text-center shadow-sm space-y-6 relative">
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="absolute top-4 right-4 p-1.5 text-gray-400 hover:text-deep-indigo rounded-md hover:bg-gray-100 transition-colors cursor-pointer"
                title="બંધ કરો (Close)"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            )}

            <div className="w-14 h-14 rounded-md bg-deep-indigo text-white flex items-center justify-center mx-auto shadow border border-turmeric-gold/30">
              <Lock className="w-6 h-6 text-turmeric-gold" />
            </div>
            
            <div className="space-y-1">
              <div className="inline-block px-2.5 py-0.5 rounded text-[11px] font-black bg-amber-100 text-amber-900 border border-amber-300 uppercase tracking-wider mb-1">
                DEMO ONLY • UI PREVIEW
              </div>
              <h2 className="text-xl font-heading font-extrabold text-deep-indigo">ડેમો એડમિન પ્રવેશ</h2>
              <p className="text-xs text-gray-500 font-semibold">સ્ટાર કિંગ નેટવર્ક ગ્રાહક વિનંતીઓનું પૂર્વાવલોકન (UI Demo)</p>
            </div>

            <div className="p-3 bg-amber-50/90 border border-amber-200 rounded-lg text-left text-xs text-amber-900 space-y-1">
              <p className="font-bold flex items-center gap-1 text-amber-950">
                <AlertCircle className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                <span>ડેમો નોટિસ (Demo Notice):</span>
              </p>
              <p className="text-[11px] leading-relaxed text-amber-800">
                આ V1 વર્ઝનમાં કોઈ હાર્ડકોડેડ ઓળખપત્રો નથી. UI પૂર્વાવલોકન માટે કોઈપણ યુઝરનેમ અને પાસવર્ડ દાખલ કરીને ડેશબોર્ડ જોઈ શકો છો.
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-1.5 text-left">
                <label className="text-xs font-extrabold text-gray-500">ડેમો ઈમેલ / યુઝરનેમ</label>
                <input
                  type="text"
                  placeholder="admin@starkingnetwork.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 rounded-md bg-white border border-deep-indigo/15 text-base sm:text-sm text-deep-indigo focus:outline-none focus:border-deep-indigo focus:bg-white font-bold"
                  required
                />
              </div>

              <div className="space-y-1.5 text-left">
                <label className="text-xs font-extrabold text-gray-500">ડેમો પાસવર્ડ</label>
                <input
                  type="password"
                  placeholder="કોઈપણ પાસવર્ડ દાખલ કરો..."
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 rounded-md bg-white border border-deep-indigo/15 text-base sm:text-sm text-deep-indigo focus:outline-none focus:border-deep-indigo focus:bg-white font-mono font-bold"
                  required
                />
              </div>

              {loginError && (
                <p className="text-xs text-brick-red font-bold text-left bg-brick-red/5 p-2.5 rounded-md border border-brick-red/15 flex gap-1.5 items-center">
                  <ShieldAlert className="w-4 h-4 text-brick-red shrink-0" />
                  <span>{loginError}</span>
                </p>
              )}

              <button
                type="submit"
                disabled={isLoggingIn}
                className="w-full py-3 bg-deep-indigo hover:bg-deep-indigo/95 border border-transparent hover:border-turmeric-gold text-white font-bold rounded-md text-sm shadow cursor-pointer transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isLoggingIn ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-turmeric-gold" />
                    <span>ચકાસણી થઈ રહી છે...</span>
                  </>
                ) : (
                  <span>ડેમો ડેશબોર્ડ ખોલો (Open Demo)</span>
                )}
              </button>
            </form>

            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">
              DEMO UI PREVIEW • NO PERSISTENT PII IN LOCALSTORAGE
            </p>

            {onClose && (
              <div className="pt-2 border-t border-deep-indigo/10">
                <button
                  type="button"
                  onClick={onClose}
                  className="text-xs font-bold text-deep-indigo hover:text-turmeric-gold transition-colors cursor-pointer inline-flex items-center gap-1"
                >
                  ← પાછા વેબસાઇટ પર જાઓ
                </button>
              </div>
            )}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="admin" className="py-16 bg-wheat-cream/30 relative border-t border-deep-indigo/15 text-left">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-deep-indigo/10 pb-6 mb-8">
          <div>
            <div className="flex items-center gap-2">
              <Database className="w-6 h-6 text-turmeric-gold" />
              <h2 className="text-2xl font-heading font-black text-deep-indigo">એડમિન ડેશબોર્ડ</h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-black bg-amber-100 text-amber-900 border border-amber-300 uppercase">
                DEMO ONLY
              </span>
            </div>
            <p className="text-xs text-gray-500 font-semibold">ગ્રાહકોની સબમિટ કરેલી ઇન-મેમરી મોક અરજીઓનું પૂર્વાવલોકન સંચાલન કરો.</p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {onClose && (
              <button
                onClick={onClose}
                className="px-3.5 py-2 bg-white border border-deep-indigo/15 hover:border-deep-indigo text-deep-indigo rounded-md text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm"
                title="હોમ પેજ પર પાછા જાઓ"
              >
                <X className="w-4 h-4 text-turmeric-gold" />
                <span>બંધ કરો</span>
              </button>
            )}

            <button
              onClick={loadData}
              disabled={isLoading}
              className="px-4 py-2 bg-white border border-deep-indigo/15 hover:border-deep-indigo text-deep-indigo rounded-md text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm disabled:opacity-50"
              title="રીફ્રેશ કરો"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              <span>રીફ્રેશ (Refresh)</span>
            </button>

            <button
              onClick={exportToCSV}
              disabled={filteredRequests.length === 0}
              className="px-4 py-2 bg-white border border-deep-indigo/15 hover:border-deep-indigo text-deep-indigo rounded-md text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>ડેટા એક્સપોર્ટ (CSV)</span>
            </button>

            <button
              onClick={exportToPDF}
              disabled={filteredRequests.length === 0 || isGeneratingPDF}
              className="px-4 py-2 bg-deep-indigo hover:bg-deep-indigo/95 border border-transparent hover:border-turmeric-gold disabled:bg-deep-indigo/40 text-white rounded-md text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
            >
              {isGeneratingPDF ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  <span>પીડીએફ બની રહી છે...</span>
                </>
              ) : (
                <>
                  <FileText className="w-4 h-4 text-white" />
                  <span>રિપોર્ટ ડાઉનલોડ (PDF)</span>
                </>
              )}
            </button>

            <button
              onClick={handleLogout}
              className="px-4 py-2 bg-brick-red hover:bg-brick-red/90 text-white rounded-md text-xs font-bold cursor-pointer inline-flex items-center gap-1.5 shadow-sm"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>લૉગઆઉટ</span>
            </button>
          </div>
        </div>

        {/* Dashboard KPIs Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {/* Total Requests */}
          <div className="bg-white border border-deep-indigo/15 p-5 rounded-md shadow-sm flex items-center gap-4 hover:border-deep-indigo/35 transition-all">
            <div className="w-12 h-12 rounded-md bg-deep-indigo/10 text-deep-indigo flex items-center justify-center border border-deep-indigo/15">
              <Database className="w-5 h-5 text-deep-indigo" />
            </div>
            <div>
              <p className="text-[10px] text-gray-500 font-black uppercase tracking-wider">Total Requests</p>
              <h3 className="text-xl font-heading font-black text-deep-indigo">{isLoading ? '...' : totalRequests}</h3>
            </div>
          </div>

          {/* Pending */}
          <div className="bg-white border border-deep-indigo/15 p-5 rounded-md shadow-sm flex items-center gap-4 hover:border-deep-indigo/35 transition-all">
            <div className="w-12 h-12 rounded-md bg-turmeric-gold/10 text-turmeric-gold flex items-center justify-center border border-turmeric-gold/15">
              <Clock className="w-5 h-5 text-turmeric-gold" />
            </div>
            <div>
              <p className="text-[10px] text-gray-500 font-black uppercase tracking-wider">Pending</p>
              <h3 className="text-xl font-heading font-black text-turmeric-gold">{isLoading ? '...' : pendingRequests}</h3>
            </div>
          </div>

          {/* Processing */}
          <div className="bg-white border border-deep-indigo/15 p-5 rounded-md shadow-sm flex items-center gap-4 hover:border-deep-indigo/35 transition-all">
            <div className="w-12 h-12 rounded-md bg-deep-indigo/10 text-deep-indigo flex items-center justify-center border border-deep-indigo/15">
              <Loader2 className="w-5 h-5 text-deep-indigo" />
            </div>
            <div>
              <p className="text-[10px] text-gray-500 font-black uppercase tracking-wider">Processing</p>
              <h3 className="text-xl font-heading font-black text-deep-indigo">{isLoading ? '...' : processingRequests}</h3>
            </div>
          </div>

          {/* Completed */}
          <div className="bg-white border border-deep-indigo/15 p-5 rounded-md shadow-sm flex items-center gap-4 hover:border-deep-indigo/35 transition-all">
            <div className="w-12 h-12 rounded-md bg-field-green/10 text-field-green flex items-center justify-center border border-field-green/15">
              <CheckCircle2 className="w-5 h-5 text-field-green" />
            </div>
            <div>
              <p className="text-[10px] text-gray-500 font-black uppercase tracking-wider">Completed</p>
              <h3 className="text-xl font-heading font-black text-field-green">{isLoading ? '...' : completedRequests}</h3>
            </div>
          </div>
        </div>

        {/* Filters Panel */}
        <div className="bg-white border border-deep-indigo/15 p-5 rounded-md shadow-sm mb-6 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Search field */}
          <div className="space-y-1">
            <label className="text-xs font-extrabold text-gray-500">ગ્રાહક શોધો (નામ અથવા મોબાઈલ)</label>
            <div className="relative">
              <input
                type="text"
                placeholder="નામ / મોબાઈલ નંબર..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-3 py-2 pl-8 border border-deep-indigo/15 rounded-md text-base sm:text-xs text-gray-800 placeholder-gray-400 focus:outline-none focus:border-deep-indigo"
              />
              <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-2.5" />
            </div>
          </div>

          {/* Status Filter */}
          <div className="space-y-1">
            <label className="text-xs font-extrabold text-gray-500">સ્ટેટસ ફિલ્ટર (Status)</label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full px-3 py-2 border border-deep-indigo/15 rounded-md text-base sm:text-xs text-gray-700 focus:outline-none focus:border-deep-indigo cursor-pointer"
            >
              <option value="All">તમામ સ્ટેટસ (All)</option>
              <option value="Pending">સબમિટ કરેલ / બાકી (Pending)</option>
              <option value="Processing">પ્રક્રિયા હેઠળ (Processing)</option>
              <option value="Completed">પૂર્ણ થયેલ (Completed)</option>
            </select>
          </div>

          {/* District Filter */}
          <div className="space-y-1">
            <label className="text-xs font-extrabold text-gray-500">જીલ્લા ફિલ્ટર</label>
            <select
              value={filterDistrict}
              onChange={(e) => setFilterDistrict(e.target.value)}
              className="w-full px-3 py-2 border border-deep-indigo/15 rounded-md text-base sm:text-xs text-gray-700 focus:outline-none focus:border-deep-indigo cursor-pointer"
            >
              {districts.map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>

          {/* Service Filter */}
          <div className="space-y-1">
            <label className="text-xs font-extrabold text-gray-500">સેવા ફિલ્ટર</label>
            <select
              value={filterService}
              onChange={(e) => setFilterService(e.target.value)}
              className="w-full px-3 py-2 border border-deep-indigo/15 rounded-md text-base sm:text-xs text-gray-700 focus:outline-none focus:border-deep-indigo cursor-pointer"
            >
              {services.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

        </div>

        {/* Requests Table */}
        <div className="bg-white border border-deep-indigo/15 rounded-md overflow-hidden shadow-sm">
          {isLoading ? (
            <div className="py-20 text-center space-y-3">
              <Loader2 className="w-8 h-8 animate-spin text-deep-indigo mx-auto" />
              <p className="text-sm font-bold text-gray-500">ફાયરબેઝ (Firestore) પરથી માહિતી લોડ થઈ રહી છે...</p>
            </div>
          ) : error ? (
            <div className="py-16 text-center space-y-4 px-4">
              <AlertCircle className="w-10 h-10 text-brick-red mx-auto" />
              <div className="space-y-1">
                <p className="text-sm font-extrabold text-gray-800">{error}</p>
                <p className="text-xs text-gray-400">કૃપા કરીને ઇન્ટરનેટ જોડાણ અથવા ફાયરબેઝ કનેક્શન તપાસો.</p>
              </div>
              <button
                onClick={loadData}
                className="px-4 py-2 bg-deep-indigo text-white font-bold rounded-md text-xs hover:bg-deep-indigo/95 border border-transparent hover:border-turmeric-gold transition-all cursor-pointer"
              >
                ફરી પ્રયાસ કરો (Retry)
              </button>
            </div>
          ) : (
            <>
              {/* Mobile Stacked Card View (Below md breakpoint) */}
              <div className="block md:hidden divide-y divide-deep-indigo/10">
                {filteredRequests.length > 0 ? (
                  filteredRequests.map((req) => (
                    <div
                      key={req.id}
                      onClick={() => handleOpenDetails(req)}
                      className="p-4 bg-white hover:bg-wheat-cream/15 transition-colors cursor-pointer space-y-3"
                    >
                      {/* Card Header: Application ID & Date */}
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono font-black text-sm text-deep-indigo bg-deep-indigo/10 border border-deep-indigo/20 px-2 py-0.5 rounded">
                          #{req.id}
                        </span>
                        <span className="text-[11px] text-gray-500 font-medium whitespace-nowrap">
                          {req.createdAt}
                        </span>
                      </div>

                      {/* Applicant Full Name */}
                      <div>
                        <span className="text-[10px] uppercase font-bold text-gray-400 block tracking-wider">અરજદારનું નામ</span>
                        <h4 className="text-sm font-extrabold text-gray-900 leading-snug">
                          {req.fullName}
                        </h4>
                      </div>

                      {/* Details Grid: Mobile & District */}
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="bg-wheat-cream/20 p-2 rounded border border-deep-indigo/10">
                          <span className="text-[10px] text-gray-500 font-bold block">મોબાઈલ નંબર</span>
                          <span className="font-bold text-gray-800 font-mono">
                            {req.mobileNumber}
                          </span>
                        </div>
                        <div className="bg-wheat-cream/20 p-2 rounded border border-deep-indigo/10">
                          <span className="text-[10px] text-gray-500 font-bold block">જિલ્લો / ગામ</span>
                          <span className="font-bold text-gray-800 truncate block" title={`${req.district}, ${req.village}`}>
                            {req.district} {req.village ? `(${req.village})` : ''}
                          </span>
                        </div>
                      </div>

                      {/* Service Name */}
                      <div>
                        <span className="text-[10px] uppercase font-bold text-gray-400 block tracking-wider mb-0.5">સેવા</span>
                        <span className="font-bold text-xs text-gray-800 bg-wheat-cream/40 border border-deep-indigo/15 px-2.5 py-1 rounded inline-block max-w-full truncate">
                          {req.category}
                        </span>
                      </div>

                      {/* Footer: Status Badge & View Details Action */}
                      <div className="flex items-center justify-between pt-2 border-t border-deep-indigo/10 gap-2">
                        <div>
                          <span className={`inline-block px-2.5 py-1 rounded-md text-xs font-black ${
                            req.status === 'પૂર્ણ થયેલ'
                              ? 'bg-field-green/10 text-field-green border border-field-green/15'
                              : req.status === 'પ્રક્રિયા હેઠળ'
                              ? 'bg-deep-indigo/10 text-deep-indigo border border-deep-indigo/15'
                              : req.status === 'દસ્તાવેજ ચકાસણી'
                              ? 'bg-turmeric-gold/10 text-turmeric-gold border border-turmeric-gold/15'
                              : 'bg-deep-indigo/10 text-deep-indigo border border-deep-indigo/15'
                          }`}>
                            {req.status}
                          </span>
                          {req.notes && (
                            <p className="text-[10px] text-gray-400 mt-0.5 italic max-w-[170px] truncate" title={req.notes}>
                              {req.notes}
                            </p>
                          )}
                        </div>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenDetails(req);
                          }}
                          className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-deep-indigo/10 hover:bg-deep-indigo hover:text-white text-deep-indigo rounded-md text-xs font-bold transition-all duration-150 cursor-pointer border border-deep-indigo/20 shadow-2xs min-h-[38px]"
                          title="અરજી વિગત જુઓ અને સ્ટેટસ બદલો"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>વિગત</span>
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-16 px-4 text-gray-400 font-bold text-xs">
                    શોધ ફિલ્ટર મુજબ કોઈ ફાયરબેઝ અરજી વિગત મળી નથી.
                  </div>
                )}
              </div>

              {/* Desktop and Tablet Table View (md and above) */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-gray-500 font-extrabold uppercase bg-wheat-cream/20 border-b border-deep-indigo/10">
                    <tr>
                      <th className="px-5 py-4 text-left whitespace-nowrap">Application ID</th>
                      <th className="px-5 py-4 text-left whitespace-nowrap">Date</th>
                      <th className="px-5 py-4 text-left">Full Name</th>
                      <th className="px-5 py-4 text-left">Mobile</th>
                      <th className="px-5 py-4 text-left">Village</th>
                      <th className="px-5 py-4 text-left">Taluka</th>
                      <th className="px-5 py-4 text-left">District</th>
                      <th className="px-5 py-4 text-left whitespace-nowrap">Service</th>
                      <th className="px-5 py-4 text-left whitespace-nowrap">IP ઍડ્રેસ</th>
                      <th className="px-5 py-4 text-left whitespace-nowrap">Status</th>
                      <th className="px-5 py-4 text-center whitespace-nowrap">વિગત</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-deep-indigo/10">
                    {filteredRequests.length > 0 ? (
                      filteredRequests.map((req) => (
                        <tr key={req.id} className="hover:bg-wheat-cream/10 transition-colors">
                          
                          {/* Application ID */}
                          <td className="px-5 py-4 font-mono font-bold text-xs text-deep-indigo whitespace-nowrap">
                            #{req.id}
                          </td>

                          {/* Date */}
                          <td className="px-5 py-4 text-gray-500 text-xs whitespace-nowrap font-medium">
                            {req.createdAt}
                          </td>

                          {/* Full Name */}
                          <td className="px-5 py-4 font-extrabold text-gray-900">
                            {req.fullName}
                          </td>

                          {/* Mobile */}
                          <td className="px-5 py-4 text-gray-700 font-bold text-xs whitespace-nowrap">
                            {req.mobileNumber}
                          </td>

                          {/* Village */}
                          <td className="px-5 py-4 text-xs text-gray-600 font-medium">
                            {req.village}
                          </td>

                          {/* Taluka */}
                          <td className="px-5 py-4 text-xs text-gray-600 font-medium">
                            {req.taluka}
                          </td>

                          {/* District */}
                          <td className="px-5 py-4 text-xs text-gray-900 font-bold">
                            {req.district}
                          </td>

                          {/* Service */}
                          <td className="px-5 py-4 whitespace-nowrap">
                            <span className="font-semibold text-gray-800 text-xs bg-wheat-cream/20 border border-deep-indigo/10 px-2.5 py-1 rounded-md">
                              {req.category}
                            </span>
                          </td>

                          {/* IP Address */}
                          <td className="px-5 py-4 whitespace-nowrap">
                            <span className="font-mono text-xs text-gray-700 bg-wheat-cream/30 border border-deep-indigo/10 px-2 py-1 rounded">
                              {req.ipAddress || '-'}
                            </span>
                          </td>

                          {/* Status */}
                          <td className="px-5 py-4 whitespace-nowrap">
                            <span className={`inline-block px-3 py-1 rounded-md text-xs font-black ${
                              req.status === 'પૂર્ણ થયેલ'
                                ? 'bg-field-green/10 text-field-green border border-field-green/15'
                                : req.status === 'પ્રક્રિયા હેઠળ'
                                ? 'bg-deep-indigo/10 text-deep-indigo border border-deep-indigo/15'
                                : req.status === 'દસ્તાવેજ ચકાસણી'
                                ? 'bg-turmeric-gold/10 text-turmeric-gold border border-turmeric-gold/15'
                                : 'bg-deep-indigo/10 text-deep-indigo border border-deep-indigo/15'
                            }`}>
                              {req.status}
                            </span>
                            {req.notes && (
                              <p className="text-[10px] text-gray-400 mt-1 italic max-w-[150px] truncate" title={req.notes}>
                                {req.notes}
                              </p>
                            )}
                          </td>

                          {/* View Details Button */}
                          <td className="px-5 py-4 text-center whitespace-nowrap">
                            <button
                              type="button"
                              onClick={() => handleOpenDetails(req)}
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-deep-indigo/10 hover:bg-deep-indigo hover:text-white text-deep-indigo rounded-md text-xs font-bold transition-all duration-150 cursor-pointer border border-deep-indigo/20 shadow-xs"
                              title="અરજી વિગત જુઓ અને સ્ટેટસ બદલો"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>વિગત</span>
                            </button>
                          </td>

                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={11} className="text-center py-16 text-gray-400 font-bold">
                          શોધ ફિલ્ટર મુજબ કોઈ ફાયરબેઝ અરજી વિગત મળી નથી.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>

        {/* View & Edit Details Modal Popup */}
        {selectedRequest && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-deep-indigo/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
            <div className="bg-white rounded-lg border border-deep-indigo/15 shadow-2xl max-w-2xl w-full overflow-hidden animate-fade-in relative text-left">
              
              {/* Modal Header */}
              <div className="bg-wheat-cream/30 px-4 sm:px-6 py-3.5 sm:py-4 border-b border-deep-indigo/10 flex items-center justify-between">
                <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
                  <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-md bg-deep-indigo text-white flex items-center justify-center font-bold shrink-0">
                    <FileText className="w-4 h-4 sm:w-5 sm:h-5 text-turmeric-gold" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-sm sm:text-base font-heading font-black text-deep-indigo truncate">અરજી વિગત</h3>
                      <span className="font-mono text-xs font-bold bg-deep-indigo/10 text-deep-indigo px-1.5 py-0.5 rounded border border-deep-indigo/20">
                        #{selectedRequest.id}
                      </span>
                    </div>
                    <p className="text-[10px] sm:text-[11px] text-gray-500 font-semibold mt-0.5 truncate">
                      સબમિશન તારીખ: {selectedRequest.createdAt}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleCloseDetails}
                  disabled={isSaving}
                  className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-md transition-colors cursor-pointer disabled:opacity-50 shrink-0 min-w-[36px] min-h-[36px] flex items-center justify-center"
                  title="બંધ કરો"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-4 sm:p-6 space-y-4 sm:space-y-6 max-h-[calc(90vh-120px)] overflow-y-auto">
                
                {/* Customer Information Cards */}
                <div className="bg-wheat-cream/15 border border-deep-indigo/10 rounded-md p-4 space-y-3">
                  <h4 className="text-xs font-extrabold uppercase text-gray-500 tracking-wider">ગ્રાહકની માહિતી (Applicant Info)</h4>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
                    
                    <div>
                      <span className="text-gray-500 font-semibold block text-[11px]">અરજદારનું નામ (Full Name)</span>
                      <p className="font-extrabold text-deep-indigo text-sm">{selectedRequest.fullName}</p>
                    </div>

                    <div>
                      <span className="text-gray-500 font-semibold block text-[11px]">મોબાઈલ નંબર (Mobile)</span>
                      <p className="font-bold text-gray-900 flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-field-green" />
                        <a href={`tel:${selectedRequest.mobileNumber}`} className="hover:underline text-deep-indigo">
                          {selectedRequest.mobileNumber}
                        </a>
                      </p>
                    </div>

                    <div>
                      <span className="text-gray-500 font-semibold block text-[11px]">સ્થળ / સરનામું (Address)</span>
                      <p className="font-medium text-gray-800 flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-turmeric-gold shrink-0" />
                        <span>ગામ: <strong>{selectedRequest.village}</strong>, તા: <strong>{selectedRequest.taluka}</strong>, જી: <strong>{selectedRequest.district}</strong></span>
                      </p>
                    </div>

                    <div>
                      <span className="text-gray-500 font-semibold block text-[11px]">જરૂરી સેવા (Requested Service)</span>
                      <span className="inline-block mt-0.5 font-bold text-deep-indigo bg-wheat-cream/40 border border-deep-indigo/15 px-2.5 py-1 rounded text-xs">
                        {selectedRequest.category}
                      </span>
                    </div>

                    <div>
                      <span className="text-gray-500 font-semibold block text-[11px]">IP ઍડ્રેસ (IP Address)</span>
                      <p className="font-mono text-xs font-bold text-gray-800 flex items-center gap-1.5 mt-0.5">
                        <Globe className="w-3.5 h-3.5 text-deep-indigo shrink-0" />
                        <span>{selectedRequest.ipAddress || 'ઉપલબ્ધ નથી (N/A)'}</span>
                      </p>
                    </div>

                  </div>

                  {selectedRequest.message && (
                    <div className="pt-2 border-t border-deep-indigo/10">
                      <span className="text-gray-500 font-semibold block text-[11px]">ગ્રાહકનો સંદેશ / વિશેષ નોંધ (Customer Message)</span>
                      <p className="text-xs text-gray-700 bg-white/80 p-2.5 rounded border border-deep-indigo/10 mt-1 italic leading-relaxed">
                        "{selectedRequest.message}"
                      </p>
                    </div>
                  )}
                </div>

                {/* Status and Notes Edit Form */}
                <form onSubmit={handleSaveDetails} className="space-y-4">
                  <div className="border-t border-deep-indigo/10 pt-4">
                    <h4 className="text-xs font-extrabold uppercase text-gray-500 tracking-wider mb-3">
                      સ્ટેટસ અને એડમિન નોંધ સંચાલન (Update Status & Admin Remarks)
                    </h4>

                    {/* Status Selector */}
                    <div className="space-y-1.5 mb-4">
                      <label className="text-xs font-extrabold text-deep-indigo flex items-center justify-between">
                        <span>અરજીનું સ્ટેટસ બદલો (Change Status) *</span>
                        <span className={`text-[11px] px-2 py-0.5 rounded font-black ${
                          editStatus === 'પૂર્ણ થયેલ'
                            ? 'bg-field-green/10 text-field-green'
                            : editStatus === 'પ્રક્રિયા હેઠળ'
                            ? 'bg-deep-indigo/10 text-deep-indigo'
                            : editStatus === 'દસ્તાવેજ ચકાસણી'
                            ? 'bg-turmeric-gold/10 text-turmeric-gold'
                            : 'bg-deep-indigo/10 text-deep-indigo'
                        }`}>
                          હાલનું સ્ટેટસ: {editStatus}
                        </span>
                      </label>

                      <select
                        value={editStatus}
                        onChange={(e) => setEditStatus(e.target.value as CustomerRequest['status'])}
                        className="w-full px-3.5 py-2.5 bg-white border border-deep-indigo/20 rounded-md text-base sm:text-xs font-bold text-gray-800 focus:outline-none focus:border-deep-indigo focus:ring-1 focus:ring-deep-indigo/20 cursor-pointer"
                      >
                        <option value="સબમિટ કરેલ">સબમિટ કરેલ (Submitted / Pending)</option>
                        <option value="દસ્તાવેજ ચકાસણી">દસ્તાવેજ ચકાસણી (Document Verification)</option>
                        <option value="પ્રક્રિયા હેઠળ">પ્રક્રિયા હેઠળ (In Progress / Processing)</option>
                        <option value="પૂર્ણ થયેલ">પૂર્ણ થયેલ (Completed / Success)</option>
                      </select>
                    </div>

                    {/* Admin Notes */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-extrabold text-deep-indigo">
                        એડમિન નોંધ / રીમાર્ક (Admin Notes / Remarks)
                      </label>
                      <textarea
                        rows={3}
                        value={editNotes}
                        onChange={(e) => setEditNotes(e.target.value)}
                        placeholder="દા.ત. આધાર કાર્ડ અપડેટ થઈ ગયું છે, દસ્તાવેજ ખૂટે છે, ફોન કરીને જાણ કરેલ છે..."
                        className="w-full px-3.5 py-2.5 bg-white border border-deep-indigo/20 rounded-md text-base sm:text-xs text-gray-800 focus:outline-none focus:border-deep-indigo focus:ring-1 focus:ring-deep-indigo/20 placeholder-gray-400"
                      />
                      <p className="text-[10px] text-gray-500">
                        * આ નોંધ Firestore ડેટાબેઝમાં સેવ થશે અને ગ્રાહક ટ્રેકિંગ પેજ પર જોઈ શકાશે.
                      </p>
                    </div>

                    {/* Success Message Banner */}
                    {saveSuccessMessage && (
                      <div className="mt-3 p-3 bg-field-green/10 border border-field-green/20 rounded-md flex items-center gap-2 text-xs font-bold text-field-green animate-fade-in">
                        <CheckCircle2 className="w-4 h-4 shrink-0 text-field-green" />
                        <span>{saveSuccessMessage}</span>
                      </div>
                    )}

                    {/* Error Message Banner */}
                    {saveErrorMessage && (
                      <div className="mt-3 p-3 bg-brick-red/10 border border-brick-red/20 rounded-md flex items-center gap-2 text-xs font-bold text-brick-red animate-fade-in">
                        <AlertCircle className="w-4 h-4 shrink-0 text-brick-red" />
                        <span>{saveErrorMessage}</span>
                      </div>
                    )}

                  </div>

                  {/* Modal Footer Controls */}
                  <div className="flex items-center justify-end gap-3 pt-3 border-t border-deep-indigo/10">
                    <button
                      type="button"
                      onClick={handleCloseDetails}
                      disabled={isSaving}
                      className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-md text-xs font-bold transition-all cursor-pointer disabled:opacity-50"
                    >
                      બંધ કરો
                    </button>

                    <button
                      type="submit"
                      disabled={isSaving}
                      className="px-5 py-2 bg-deep-indigo hover:bg-deep-indigo/95 border border-transparent hover:border-turmeric-gold text-white rounded-md text-xs font-bold flex items-center gap-2 shadow cursor-pointer transition-all disabled:opacity-50"
                    >
                      {isSaving ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin text-white" />
                          <span>સાચવી રહ્યા છીએ...</span>
                        </>
                      ) : (
                        <>
                          <Save className="w-4 h-4 text-turmeric-gold" />
                          <span>સેવ કરો (Save)</span>
                        </>
                      )}
                    </button>
                  </div>

                </form>

              </div>

            </div>
          </div>
        )}

        {/* Hidden PDF Report Element for html2canvas */}
        <div style={{ position: 'absolute', left: '-9999px', top: '-9999px' }}>
          <div id="pdf-report-content" style={{ width: '820px', padding: '40px', backgroundColor: '#ffffff', color: '#111827' }} className="font-sans">
            {/* PDF Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '3px solid #1B3A5C', paddingBottom: '20px', marginBottom: '25px' }}>
              <div>
                <h1 style={{ fontSize: '26px', fontWeight: '900', color: '#1B3A5C', margin: 0, letterSpacing: '-0.5px' }}>STAR KING NETWORK</h1>
                <p style={{ fontSize: '12px', color: '#4B5563', margin: '4px 0 0 0', fontWeight: '700' }}>સરકારી અને બિન-સરકારી ઓનલાઇન સેવાઓનું ડિજિટલ કેન્દ્ર</p>
                <p style={{ fontSize: '10px', color: '#6B7280', margin: '2px 0 0 0' }}>મોબાઈલ: +91 97260 74581 | ઈમેલ: starking@gmail.com</p>
              </div>
              <div style={{ textAlign: 'right' }}>
                <span style={{ fontSize: '10px', fontWeight: '800', backgroundColor: '#1B3A5C', color: '#ffffff', padding: '4px 10px', borderRadius: '4px', textTransform: 'uppercase' }}>સત્તાવાર રેકોર્ડ</span>
                <h2 style={{ fontSize: '15px', fontWeight: '800', color: '#111827', margin: '8px 0 0 0' }}>ગ્રાહક અરજીઓનો અહેવાલ</h2>
                <p style={{ fontSize: '10px', color: '#4B5563', margin: '4px 0 0 0', fontFamily: 'monospace', fontWeight: 'bold' }}>તારીખ: {new Date().toLocaleString('gu-IN')}</p>
              </div>
            </div>

            {/* Summary Statistics Cards */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '15px', marginBottom: '25px' }}>
              <div style={{ border: '1px solid #E5E7EB', padding: '12px', borderRadius: '4px', backgroundColor: '#F9FAFB' }}>
                <p style={{ fontSize: '10px', color: '#6B7280', margin: 0, fontWeight: '800' }}>કુલ ફિલ્ટર કરેલ</p>
                <p style={{ fontSize: '20px', fontWeight: '900', color: '#111827', margin: '4px 0 0 0' }}>{filteredRequests.length} અરજી</p>
              </div>
              <div style={{ border: '1px solid #E5E7EB', padding: '12px', borderRadius: '4px', backgroundColor: '#F9FAFB' }}>
                <p style={{ fontSize: '10px', color: '#6B7280', margin: 0, fontWeight: '800' }}>બાકી (Pending)</p>
                <p style={{ fontSize: '20px', fontWeight: '900', color: '#C98A2B', margin: '4px 0 0 0' }}>{filteredRequests.filter(r => r.status === 'સબમિટ કરેલ').length}</p>
              </div>
              <div style={{ border: '1px solid #E5E7EB', padding: '12px', borderRadius: '4px', backgroundColor: '#F9FAFB' }}>
                <p style={{ fontSize: '10px', color: '#6B7280', margin: 0, fontWeight: '800' }}>પ્રક્રિયા હેઠળ</p>
                <p style={{ fontSize: '20px', fontWeight: '900', color: '#1B3A5C', margin: '4px 0 0 0' }}>{filteredRequests.filter(r => r.status === 'પ્રક્રિયા હેઠળ' || r.status === 'દસ્તાવેજ ચકાસણી').length}</p>
              </div>
              <div style={{ border: '1px solid #E5E7EB', padding: '12px', borderRadius: '4px', backgroundColor: '#F9FAFB' }}>
                <p style={{ fontSize: '10px', color: '#6B7280', margin: 0, fontWeight: '800' }}>પૂર્ણ થયેલ (Success)</p>
                <p style={{ fontSize: '20px', fontWeight: '900', color: '#4C7A3D', margin: '4px 0 0 0' }}>{filteredRequests.filter(r => r.status === 'પૂર્ણ થયેલ').length}</p>
              </div>
            </div>

            {/* Filter Metadata block */}
            <div style={{ fontSize: '11px', color: '#1B3A5C', marginBottom: '25px', padding: '12px 16px', borderLeft: '4px solid #1B3A5C', backgroundColor: '#F7F2E7', borderRadius: '0 4px 4px 0', fontWeight: '600', display: 'flex', justifyContent: 'space-between' }}>
              <div>
                રિપોર્ટ ફિલ્ટર વિગતો — જીલ્કો: <strong style={{ color: '#1B3A5C' }}>{filterDistrict}</strong> | સેવા: <strong style={{ color: '#1B3A5C' }}>{filterService}</strong> | સ્ટેટસ: <strong style={{ color: '#1B3A5C' }}>{filterStatus === 'All' ? 'તમામ' : filterStatus === 'Pending' ? 'સબમિટ કરેલ' : filterStatus === 'Processing' ? 'પ્રક્રિયા હેઠળ' : 'પૂર્ણ થયેલ'}</strong>
              </div>
              {searchTerm && (
                <div>
                  શોધ: <strong style={{ color: '#1B3A5C' }}>"{searchTerm}"</strong>
                </div>
              )}
            </div>

            {/* PDF Table */}
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '11px', textAlign: 'left', marginBottom: '35px' }}>
              <thead>
                <tr style={{ backgroundColor: '#F3F4F6', borderBottom: '2px solid #D1D5DB' }}>
                  <th style={{ padding: '10px 12px', color: '#374151', fontWeight: '800', width: '85px' }}>ID</th>
                  <th style={{ padding: '10px 12px', color: '#374151', fontWeight: '800', width: '130px' }}>તારીખ</th>
                  <th style={{ padding: '10px 12px', color: '#374151', fontWeight: '800', width: '140px' }}>અરજદારનું નામ</th>
                  <th style={{ padding: '10px 12px', color: '#374151', fontWeight: '800', width: '90px' }}>મોબાઈલ</th>
                  <th style={{ padding: '10px 12px', color: '#374151', fontWeight: '800', width: '160px' }}>સરનામું</th>
                  <th style={{ padding: '10px 12px', color: '#374151', fontWeight: '800', width: '130px' }}>સેવા પ્રકાર</th>
                  <th style={{ padding: '10px 12px', color: '#374151', fontWeight: '800', width: '85px' }}>સ્ટેટસ</th>
                </tr>
              </thead>
              <tbody>
                {filteredRequests.length > 0 ? (
                  filteredRequests.map((req) => (
                    <tr key={req.id} style={{ borderBottom: '1px solid #E5E7EB' }}>
                      <td style={{ padding: '12px 12px', fontFamily: 'monospace', fontWeight: 'bold', color: '#1B3A5C' }}>#{req.id}</td>
                      <td style={{ padding: '12px 12px', color: '#4B5563' }}>{req.createdAt}</td>
                      <td style={{ padding: '12px 12px', fontWeight: 'bold', color: '#111827' }}>{req.fullName}</td>
                      <td style={{ padding: '12px 12px', fontWeight: 'bold', color: '#4B5563' }}>{req.mobileNumber}</td>
                      <td style={{ padding: '12px 12px', color: '#4B5563', fontSize: '10.5px', lineHeight: '1.4' }}>
                        ગામ: {req.village}, તા: {req.taluka}, જી: {req.district}
                      </td>
                      <td style={{ padding: '12px 12px', color: '#111827', fontWeight: '600' }}>{req.category}</td>
                      <td style={{ padding: '12px 12px' }}>
                        <span style={{
                          display: 'inline-block',
                          padding: '3px 8px',
                          borderRadius: '4px',
                          fontSize: '10px',
                          fontWeight: '900',
                          backgroundColor: req.status === 'પૂર્ણ થયેલ' ? '#ECFDF5' : req.status === 'પ્રક્રિયા હેઠળ' ? '#F5F3FF' : req.status === 'દસ્તાવેજ ચકાસણી' ? '#FEF3C7' : '#EFF6FF',
                          color: req.status === 'પૂર્ણ થયેલ' ? '#4C7A3D' : req.status === 'પ્રક્રિયા હેઠળ' ? '#1B3A5C' : req.status === 'દસ્તાવેજ ચકાસણી' ? '#C98A2B' : '#1B3A5C',
                          border: req.status === 'પૂર્ણ થયેલ' ? '1px solid #A7F3D0' : req.status === 'પ્રક્રિયા હેઠળ' ? '1px solid #DDD6FE' : req.status === 'દસ્તાવેજ ચકાસણી' ? '1px solid #FDE68A' : '1px solid #BFDBFE'
                        }}>
                          {req.status}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} style={{ padding: '30px', textAlign: 'center', color: '#9CA3AF', fontWeight: 'bold' }}>
                      કોઈ ડેટા ઉપલબ્ધ નથી
                    </td>
                  </tr>
                )}
              </tbody>
            </table>

            {/* PDF Footer */}
            <div style={{ borderTop: '2px solid #E5E7EB', paddingTop: '15px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '10px', color: '#9CA3AF', fontWeight: '700' }}>
              <div>સ્ટાર કિંગ નેટવર્ક • સત્તાવાર રેકોર્ડ અહેવાલ</div>
              <div>© {new Date().getFullYear()} STAR KING NETWORK</div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
