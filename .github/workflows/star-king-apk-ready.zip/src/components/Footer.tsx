import React from 'react';
import GlobalFooter, { ScreenType } from './GlobalFooter';

interface FooterProps {
  onPolicyClick?: (tab: string) => void;
  onNavigate?: (screen: ScreenType, tab?: string) => void;
}

export default function Footer({ onPolicyClick, onNavigate }: FooterProps) {
  const handleNav = (screen: ScreenType, tab?: string) => {
    if (onNavigate) {
      onNavigate(screen, tab);
    } else if (onPolicyClick && tab) {
      onPolicyClick(tab);
    }
  };

  return <GlobalFooter onNavigate={handleNav} />;
}
