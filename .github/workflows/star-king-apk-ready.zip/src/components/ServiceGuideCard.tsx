import React from 'react';
import { FileText, Download, Sparkles, CheckCircle2 } from 'lucide-react';
import { SERVICES } from '../utils/mockData';

export default function ServiceGuideCard() {
  const handleDownloadPDF = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const servicesHtml = SERVICES.map((service, idx) => `
      <div class="service-card" style="border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; background-color: #ffffff; page-break-inside: avoid; margin-bottom: 12px;">
        <div class="service-header" style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
          <span class="service-number" style="background-color: #1b3a5c; color: #ffffff; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: bold;">${idx + 1}</span>
          <h3 class="service-title" style="font-size: 16px; font-weight: 750; margin: 0; color: #0f172a;">${service.gujaratiTitle}</h3>
        </div>
        <p class="service-desc" style="font-size: 13px; color: #475569; margin: 0 0 8px 0; font-weight: 500; line-height: 1.5;">${service.description}</p>
        <div class="service-meta" style="font-size: 11px; color: #2e7d32; font-weight: bold;">સુવિધા: ઘરે બેઠા ઓનલાઈન સહાય અને માર્ગદર્શન</div>
      </div>
    `).join('');

    printWindow.document.write(`
      <!DOCTYPE html>
      <html lang="gu">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Star King Network - Service Guide</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Hind+Vadodara:wght@400;500;600;700&display=swap');
          
          body {
            font-family: 'Hind Vadodara', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            color: #1e293b;
            margin: 0;
            padding: 30px;
            line-height: 1.6;
            background-color: #ffffff;
          }

          .container {
            max-width: 800px;
            margin: 0 auto;
          }

          .header {
            text-align: center;
            border-bottom: 3px solid #1b3a5c;
            padding-bottom: 20px;
            margin-bottom: 30px;
          }

          .logo-text {
            font-size: 28px;
            font-weight: 800;
            color: #1b3a5c;
            margin: 0;
            letter-spacing: 1px;
          }

          .logo-sub {
            font-size: 14px;
            font-weight: bold;
            color: #d97706;
            margin: 5px 0 0 0;
            text-transform: uppercase;
            letter-spacing: 2px;
          }

          .doc-title {
            font-size: 20px;
            font-weight: 700;
            margin: 15px 0 0 0;
            color: #0f172a;
          }

          .intro-box {
            background-color: #f8fafc;
            border-left: 4px solid #2e7d32;
            padding: 15px;
            margin-bottom: 30px;
            border-radius: 0 8px 8px 0;
          }

          .intro-text {
            font-size: 13px;
            font-weight: 600;
            margin: 0;
            color: #475569;
          }

          .section-title {
            font-size: 18px;
            font-weight: 700;
            border-bottom: 1.5px solid #e2e8f0;
            padding-bottom: 8px;
            margin-top: 30px;
            margin-bottom: 20px;
            color: #1b3a5c;
          }

          .contacts-box {
            background-color: #f0fdf4;
            border: 1px dashed #bbf7d0;
            border-radius: 8px;
            padding: 15px;
            margin-top: 30px;
            page-break-inside: avoid;
          }

          .contact-row {
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 8px;
            color: #166534;
          }

          .disclaimer-box {
            background-color: #fffbeb;
            border: 1px solid #fef3c7;
            border-radius: 8px;
            padding: 15px;
            margin-top: 20px;
            font-size: 11px;
            color: #92400e;
            line-height: 1.5;
            page-break-inside: avoid;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1 class="logo-text">STAR KING NETWORK</h1>
            <p class="logo-sub">DIGITAL SERVICE PLATFORM</p>
            <h2 class="doc-title">સત્તાવાર ઓનલાઇન સેવા માર્ગદર્શિકા (Service Directory)</h2>
          </div>

          <div class="intro-box">
            <p class="intro-text">
              સ્ટાર કિંગ નેટવર્ક એ ગુજરાતભરના નાગરિકો માટે સરકારી યોજના, ભરતી ફોર્મ, આઈ-ખેડૂત, સ્કૉલરશિપ અને કોલેજ એડમિશન સંબંધિત ઓનલાઈન કામગીરી ચોકસાઈપૂર્વક કરી આપતી અગ્રણી ડિજિટલ સહાય એજન્સી છે.
            </p>
          </div>

          <h3 class="section-title">મુખ્ય ઓનલાઇન સેવાઓ</h3>
          <div class="services-grid">
            ${servicesHtml}
          </div>

          <div class="contacts-box">
            <div class="contact-row"><strong>સંપર્ક (WhatsApp Only):</strong> +91 97260 74581</div>
            <div class="contact-row"><strong>ઈમેઈલ:</strong> starkingnetwork@gmail.com</div>
            <div class="contact-row"><strong>કાર્યક્ષેત્ર:</strong> ગાંધીનગર, ગુજરાત (સંપૂર્ણ ઓનલાઈન સહાય)</div>
          </div>

          <div class="disclaimer-box">
            <strong>મહત્વપૂર્ણ ડિસ્ક્લેમર:</strong> STAR KING NETWORK (સ્ટાર કિંગ નેટવર્ક) એ સંપૂર્ણપણે સ્વતંત્ર, વ્યાવસાયિક ઓનલાઇન સેવા પ્લેટફોર્મ છે. અમે ભારત સરકાર અથવા ગુજરાત સરકારના કોઈ પણ વિભાગ કે એજન્સી સાથે કોઈ સત્તાવાર જોડાણ ધરાવતા નથી. અમે ગ્રાહકો વતી જાહેરમાં ઉપલબ્ધ સરકારી પોર્ટલ પરથી ઓનલાઇન ફોર્મ સબમિટ કરવામાં માત્ર વ્યાવસાયિક માર્ગદર્શન અને સહાય પૂરી પાડીએ છીએ.
          </div>
        </div>

        <script>
          window.onload = function() {
            window.print();
            setTimeout(function() { window.close(); }, 1000);
          };
        </script>
      </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="bg-gradient-to-br from-wheat-cream/70 via-white to-wheat-cream/30 rounded-2xl border border-turmeric-gold/35 p-5 sm:p-6 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5 text-left">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-turmeric-gold/15 text-turmeric-gold border border-turmeric-gold/30 flex items-center justify-center shrink-0">
          <FileText className="w-6 h-6" />
        </div>

        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h3 className="text-lg font-heading font-black text-deep-indigo">
              સેવા માર્ગદર્શિકા
            </h3>
            <span className="text-[10px] font-black uppercase bg-deep-indigo text-white px-2 py-0.5 rounded-full">
              PDF Guide
            </span>
          </div>

          <p className="text-xs text-gray-600 font-medium max-w-md">
            તમામ સરકારી યોજનાઓ, ઓનલાઇન ફોર્મ્સ અને જરૂરી દસ્તાવેજોની સંપૂર્ણ વિગતવાર માર્ગદર્શિકા જુઓ અથવા ડાઉનલોડ કરો.
          </p>
        </div>
      </div>

      <button
        type="button"
        onClick={handleDownloadPDF}
        className="w-full sm:w-auto px-5 py-3 bg-turmeric-gold hover:bg-turmeric-gold/90 text-white font-black text-xs rounded-xl shadow-sm hover:shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 shrink-0 active:scale-95 border border-turmeric-gold/30"
      >
        <span className="text-sm">📄</span>
        <span>માર્ગદર્શિકા જુઓ (View PDF Guide)</span>
      </button>
    </div>
  );
}
