import React from 'react';
import { AlertTriangle, ShieldAlert, CheckCircle2 } from 'lucide-react';

export default function DisclaimerCard() {
  return (
    <div className="bg-amber-50/70 border border-amber-200/90 rounded-2xl p-6 sm:p-7 shadow-sm text-left space-y-4">
      
      <div className="flex items-center gap-2.5">
        <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-xs">
          <AlertTriangle className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-lg font-heading font-black text-amber-950 flex items-center gap-2">
            <span>⚠ મહત્વપૂર્ણ ડિસ્ક્લેમર (Important Disclaimer)</span>
          </h3>
          <p className="text-[11px] font-bold text-amber-800">
            બિન-સરકારી ખાનગી સેવા પ્લેટફોર્મ ઘોષણા
          </p>
        </div>
      </div>

      <div className="p-4 bg-white/90 rounded-xl border border-amber-200 shadow-2xs space-y-3">
        <p className="text-xs sm:text-sm text-amber-950 font-semibold leading-relaxed">
          “STAR KING NETWORK (સ્ટાર કિંગ નેટવર્ક) એ સંપૂર્ણપણે સ્વતંત્ર, વ્યાવસાયિક ઓનલાઇન સેવા પ્લેટફોર્મ છે. અમે ભારત સરકાર અથવા ગુજરાત સરકારના કોઈ પણ વિભાગ કે એજન્સી સાથે અધિકૃત જોડાણ ધરાવતા નથી. અમે ગ્રાહકો વતી જાહેરમાં ઉપલબ્ધ સરકારી પોર્ટલ પરથી ઓનલાઇન ફોર્મ સબમિટ કરવામાં માત્ર વ્યાવસાયિક માર્ગદર્શન અને સહાય પૂરી પાડીએ છીએ.”
        </p>

        <div className="pt-2.5 border-t border-amber-200/70 text-xs font-bold text-amber-900 italic">
          “STAR KING NETWORK is a private digital service platform. We are not a government organization.”
        </div>
      </div>

      <div className="flex flex-wrap gap-2 text-[11px] font-bold text-amber-800">
        <span className="flex items-center gap-1 bg-amber-100/70 px-2.5 py-1 rounded-md border border-amber-200/60">
          <CheckCircle2 className="w-3.5 h-3.5 text-amber-700" />
          <span>સ્વતંત્ર ડિજિટલ પરામર્શ</span>
        </span>
        <span className="flex items-center gap-1 bg-amber-100/70 px-2.5 py-1 rounded-md border border-amber-200/60">
          <CheckCircle2 className="w-3.5 h-3.5 text-amber-700" />
          <span>સુરક્ષિત ગ્રાહક સેવા</span>
        </span>
      </div>

    </div>
  );
}
