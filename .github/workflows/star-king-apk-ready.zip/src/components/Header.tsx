import React, { useState } from 'react';
import { Menu, X, Phone, MessageCircle, ShieldAlert, Users, Info } from 'lucide-react';
import { SITE_CONFIG, buildWhatsAppLink } from '../config/siteConfig';

export type ScreenType = 'home' | 'services' | 'form' | 'track' | 'about-policies';

interface HeaderProps {
  activeScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
  onRequestClick: () => void;
  isMobileMenuOpen?: boolean;
  onToggleMobileMenu?: () => void;
  onCloseMobileMenu?: () => void;
}

export default function Header({ 
  activeScreen, 
  onNavigate, 
  onRequestClick,
  isMobileMenuOpen,
  onToggleMobileMenu,
  onCloseMobileMenu
}: HeaderProps) {
  const [internalMobileMenuOpen, setInternalMobileMenuOpen] = useState(false);
  
  const isMenuOpen = isMobileMenuOpen !== undefined ? isMobileMenuOpen : internalMobileMenuOpen;
  
  const toggleMenu = () => {
    if (onToggleMobileMenu) {
      onToggleMobileMenu();
    } else {
      setInternalMobileMenuOpen(!internalMobileMenuOpen);
    }
  };

  const closeMenu = () => {
    if (onCloseMobileMenu) {
      onCloseMobileMenu();
    } else {
      setInternalMobileMenuOpen(false);
    }
  };

  const navItems: { id: ScreenType; label: string; enLabel?: string }[] = [
    { id: 'home', label: 'હોમ પેજ' },
    { id: 'services', label: 'સેવાઓ' },
    { id: 'form', label: 'ફોર્મ ભરો' },
    { id: 'track', label: 'અરજી સ્ટેટસ' },
    { id: 'about-policies', label: 'About & Policies' }
  ];

  const handleNavClick = (id: ScreenType) => {
    onNavigate(id);
    closeMenu();
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-white border-b border-deep-indigo/15 shadow-sm">
      {/* Official Government Portal Top Letterhead Band */}
      <div className="gov-top-band" />

      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16 sm:h-20">
          
          {/* Logo Brand */}
          <div className="flex items-center gap-2.5 sm:gap-3 cursor-pointer py-1" onClick={() => handleNavClick('home')}>
            <img 
              src="/star_king_logo.png" 
              alt="STAR KING NETWORK" 
              className="star-king-logo"
            />
            <div className="min-w-0">
              <span id="brand-title" className="text-base sm:text-lg lg:text-xl font-heading font-black tracking-tight text-deep-indigo block truncate">
                STAR KING NETWORK
              </span>
              <p className="text-[9px] sm:text-[10px] text-warm-gray font-bold tracking-widest uppercase truncate">
                ઓનલાઇન સેવા કેન્દ્ર • GUJARAT
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`min-h-[44px] px-3 py-2 rounded-lg text-sm font-bold transition-all duration-150 cursor-pointer ${
                  activeScreen === item.id
                    ? 'text-deep-indigo bg-wheat-cream/80 border border-deep-indigo/20 font-black shadow-xs'
                    : 'text-warm-gray hover:text-deep-indigo hover:bg-wheat-cream/40 border border-transparent'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* CTA & Contact Details */}
          <div className="hidden lg:flex items-center gap-2.5">
            <a
              href={buildWhatsAppLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="min-h-[44px] flex items-center gap-2 text-field-green bg-field-green/5 hover:bg-field-green/10 border border-field-green/20 px-3.5 py-2 rounded-lg text-xs font-bold transition-colors duration-150"
              title="વોટ્સએપ કોલ / ચેટ (માત્ર વોટ્સએપ)"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>વોટ્સએપ સપોર્ટ</span>
            </a>

            <button
              onClick={onRequestClick}
              className="gov-btn-primary text-xs font-bold px-4 py-2"
            >
              માહિતી મોકલો
            </button>
          </div>

          {/* Mobile CTA and menu button with 44px min tap targets */}
          <div className="flex md:hidden items-center gap-1.5 shrink-0">
            <button
              onClick={onRequestClick}
              className="bg-deep-indigo hover:bg-deep-indigo-hover active:bg-deep-indigo-active text-white text-[11px] sm:text-xs font-bold px-2.5 sm:px-3 py-1.5 rounded-sm min-h-[34px] sm:min-h-[36px] shadow-2xs whitespace-nowrap inline-flex items-center justify-center border border-turmeric-gold/30 transition-colors cursor-pointer"
            >
              માહિતી મોકલો
            </button>
            <button
              onClick={toggleMenu}
              className="min-w-[38px] min-h-[38px] sm:min-w-[44px] sm:min-h-[44px] p-1.5 sm:p-2 rounded-sm text-deep-indigo hover:bg-wheat-cream/40 transition-colors flex items-center justify-center cursor-pointer"
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.5px]" /> : <Menu className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.25px]" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Menu Dropdown & Backdrop */}
      {isMenuOpen && (
        <>
          <div 
            className="fixed inset-0 top-[68px] bg-deep-indigo/60 backdrop-blur-xs z-40 md:hidden"
            onClick={closeMenu}
          />
          <div className="md:hidden bg-white border-t border-deep-indigo/15 absolute w-full left-0 py-4 px-3 space-y-3 z-50 shadow-xl max-h-[calc(100vh-4.5rem)] overflow-y-auto">
            
            <div className="grid gap-1.5">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`min-h-[44px] w-full text-left px-4 py-2.5 rounded-lg text-sm font-bold transition-colors duration-150 cursor-pointer flex items-center justify-between ${
                    activeScreen === item.id
                      ? 'text-deep-indigo bg-wheat-cream font-black border-l-4 border-turmeric-gold'
                      : 'text-warm-gray hover:bg-wheat-cream/30 hover:text-deep-indigo'
                  }`}
                >
                  <span>{item.label}</span>
                  {activeScreen === item.id && <span className="text-xs text-turmeric-gold font-black">●</span>}
                </button>
              ))}
            </div>

            <div className="pt-3 border-t border-deep-indigo/12 flex flex-col gap-2">
              <a
                href={SITE_CONFIG.whatsapp.groupInviteUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="gov-btn-primary w-full text-xs font-bold"
              >
                <Users className="w-4 h-4" />
                <span>સત્તાવાર વોટ્સએપ ગ્રુપ</span>
              </a>
              <a
                href={buildWhatsAppLink()}
                target="_blank"
                referrerPolicy="no-referrer"
                className="gov-btn-green w-full text-xs font-bold"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
                <span>વોટ્સએપ હેલ્પલાઈન ({SITE_CONFIG.whatsapp.displayNumber})</span>
              </a>
            </div>

            {/* Quick Notice Disclaimer */}
            <div className="p-3 bg-wheat-cream/40 rounded-xl border border-deep-indigo/12 flex gap-2 text-xs text-warm-gray leading-relaxed font-semibold">
              <ShieldAlert className="w-4 h-4 shrink-0 text-turmeric-gold mt-0.5" />
              <span>સ્ટાર કિંગ નેટવર્ક એ એક સ્વતંત્ર ઓનલાઇન સેવા કેન્દ્ર છે, અમે કોઈ સરકારી સંસ્થા નથી.</span>
            </div>
          </div>
        </>
      )}
    </header>
  );
}
