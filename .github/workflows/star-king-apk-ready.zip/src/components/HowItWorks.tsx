import React from 'react';
import { Send, FileText, CheckSquare, Sparkles, ChevronDown } from 'lucide-react';

export default function HowItWorks() {
  const steps = [
    {
      step: 'Step 1',
      title: 'Form Submit (અરજી વિગત મોકલો)',
      desc: 'અમારી વેબસાઇટ પર ઓનલાઇન ફોર્મ દ્વારા તમારું નામ, સેવા અને વિગતો સબમિટ કરો.',
      icon: Send,
      color: 'bg-deep-indigo text-white',
    },
    {
      step: 'Step 2',
      title: 'Send Documents on WhatsApp (દસ્તાવેજ વોટ્સએપ કરો)',
      desc: 'ફોર્મ સબમિટ કર્યા પછી "વોટ્સએપ પર દસ્તાવેજ મોકલો" બટન પર ક્લિક કરી જરૂરી પ્રૂફ (આધાર, ફોટો વગેરે) વોટ્સએપ કરો.',
      icon: FileText,
      color: 'bg-turmeric-gold text-white',
    },
    {
      step: 'Step 3',
      title: 'Verification (દસ્તાવેજ અને માહિતી ચકાસણી)',
      desc: 'અમારી ટીમ દ્વારા તમારા દસ્તાવેજો અને વિગતોની સચોટ રીતે ચકાસણી કરવામાં આવશે.',
      icon: CheckSquare,
      color: 'bg-deep-indigo text-white',
    },
    {
      step: 'Step 4',
      title: 'Work Completed (કામગીરી સફળતાપૂર્વક પૂર્ણ)',
      desc: 'ચોકસાઈપૂર્વક ફોર્મ ભરાઈ ગયા બાદ અરજીની પહોંચ / પીડીએફ ફાઈલ સીધી તમને વોટ્સએપ પર મોકલવામાં આવશે.',
      icon: Sparkles,
      color: 'bg-field-green text-white',
    },
  ];

  return (
    <section id="how-it-works" className="py-16 sm:py-24 bg-white border-b border-deep-indigo/10 relative">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Heading */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-deep-indigo/10 text-deep-indigo rounded-md text-xs font-bold border border-deep-indigo/15">
            <Sparkles className="w-3.5 h-3.5 text-turmeric-gold" />
            <span>સરળ ડિજિટલ પ્રક્રિયા</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-heading font-bold text-deep-indigo">
            અમારી પ્રક્રિયા કેવી રીતે કામ કરે છે?
          </h2>
          <p className="text-warm-gray text-sm sm:text-base">
            ખૂબ જ સરળ ૪ સ્ટેપ્સમાં તમારી અરજીની પ્રક્રિયા પૂર્ણ કરવામાં આવે છે:
          </p>
        </div>

        {/* Steps display - responsive layout */}
        <div className="flex flex-col lg:flex-row items-stretch justify-between gap-6 relative">
          {steps.map((item, idx) => {
            const IconComp = item.icon;
            return (
              <React.Fragment key={idx}>
                {/* Step Card */}
                <div className="flex-1 bg-white border border-deep-indigo/12 rounded-md p-6 sm:p-8 flex flex-col justify-between space-y-4 hover:border-turmeric-gold transition-colors duration-150 relative">
                  <div className="space-y-4">
                    {/* Badge and Icon */}
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-0.5 bg-wheat-cream border border-deep-indigo/10 text-deep-indigo text-[11px] font-black rounded-md uppercase">
                        {item.step}
                      </span>
                      <div className={`w-10 h-10 rounded-md ${item.color} flex items-center justify-center`}>
                        <IconComp className="w-5 h-5" />
                      </div>
                    </div>

                    <h3 className="font-heading font-bold text-deep-indigo text-lg leading-snug">
                      {item.title}
                    </h3>
                    
                    <p className="text-warm-gray text-xs sm:text-sm leading-relaxed font-semibold">
                      {item.desc}
                    </p>
                  </div>
                </div>

                {/* Arrow indicator between steps on desktop, and down on mobile */}
                {idx < steps.length - 1 && (
                  <div className="flex items-center justify-center py-2 lg:py-0 text-turmeric-gold shrink-0">
                    <ChevronDown className="w-6 h-6 lg:-rotate-90 animate-pulse" />
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </div>

      </div>
    </section>
  );
}
