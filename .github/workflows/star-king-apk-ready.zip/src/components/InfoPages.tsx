import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Info, 
  ShieldCheck, 
  Scale, 
  Receipt, 
  Contact, 
  AlertTriangle, 
  CheckCircle, 
  Lock, 
  FileText, 
  Coins, 
  Mail, 
  MessageCircle, 
  MapPin, 
  Users, 
  Building,
  Check,
  Youtube
} from 'lucide-react';

interface InfoPagesProps {
  isOpen: boolean;
  initialTab: string;
  onClose: () => void;
}

export default function InfoPages({ isOpen, initialTab, onClose }: InfoPagesProps) {
  const [activeTab, setActiveTab] = React.useState(initialTab);

  React.useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
    }
  }, [isOpen, initialTab]);

  const tabs = [
    { id: 'about', label: 'અમારા વિશે (About Us)', icon: Info },
    { id: 'privacy', label: 'ગોપનીયતા નીતિ (Privacy Policy)', icon: ShieldCheck },
    { id: 'terms', label: 'નિયમો અને શરતો (Terms & Conditions)', icon: Scale },
    { id: 'refund', label: 'રિફંડ પોલિસી (Refund Policy)', icon: Receipt },
    { id: 'contact', label: 'સંપર્ક વિગત (Contact Details)', icon: Contact },
    { id: 'disclaimer', label: 'ડિસ્ક્લેમર (Disclaimer)', icon: AlertTriangle },
  ];

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto">
        {/* Backdrop overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-deep-indigo/70 transition-opacity"
        />

        {/* Modal container */}
        <div className="flex min-h-full items-center justify-center p-4 text-center sm:p-6 lg:p-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: 'spring', duration: 0.4 }}
            className="relative transform overflow-hidden rounded-md bg-white text-left shadow-xl transition-all w-full max-w-5xl flex flex-col md:flex-row h-[85vh] md:h-[75vh] border border-deep-indigo/20"
          >
            {/* Left Sidebar/Nav (Desktop) or Top Nav (Mobile) */}
            <div className="w-full md:w-80 bg-wheat-cream/30 border-b md:border-b-0 md:border-r border-deep-indigo/15 flex flex-col p-6 shrink-0 justify-between">
              <div>
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-9 h-9 rounded-md bg-white overflow-hidden flex items-center justify-center shadow border border-turmeric-gold/30">
                    <img 
                      src="https://lh3.googleusercontent.com/d/1OF66JfK88VkWQ-lpgOAk3iuydf1pgk2q" 
                      alt="Star King Network Logo" 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div>
                    <h2 className="text-sm font-heading font-black text-deep-indigo tracking-tight">STAR KING NETWORK</h2>
                    <p className="text-[10px] text-gray-500 font-extrabold tracking-wider uppercase">ડિજિટલ સહાય કેન્દ્ર</p>
                  </div>
                </div>

                <nav className="space-y-1.5 overflow-x-auto md:overflow-x-visible pb-3 md:pb-0 flex flex-row md:flex-col gap-2 md:gap-0 scrollbar-none">
                  {tabs.map((tab) => {
                    const TabIcon = tab.icon;
                    const isActive = activeTab === tab.id;
                    return (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`w-auto md:w-full flex items-center gap-2.5 px-3.5 py-3 rounded-md text-xs font-bold transition-all duration-200 shrink-0 cursor-pointer text-left ${
                          isActive 
                            ? 'bg-white border border-deep-indigo/25 text-deep-indigo shadow-sm' 
                            : 'text-gray-600 hover:text-deep-indigo hover:bg-wheat-cream/40 border border-transparent'
                        }`}
                      >
                        <TabIcon className={`w-4 h-4 ${isActive ? 'text-turmeric-gold' : 'text-gray-450'}`} />
                        <span className="whitespace-nowrap">{tab.label.split(' (')[0]}</span>
                      </button>
                    );
                  })}
                </nav>
              </div>

              {/* Close Button & Brand Status (Desktop only) */}
              <div className="hidden md:block pt-6 border-t border-deep-indigo/10 space-y-3">
                <div className="flex items-center gap-1.5 text-[11px] text-gray-600 font-extrabold">
                  <Lock className="w-3.5 h-3.5 text-field-green" />
                  <span>ગોપનીય અને સુરક્ષિત પોર્ટલ</span>
                </div>
                <button
                  onClick={onClose}
                  className="w-full py-2.5 bg-deep-indigo hover:bg-deep-indigo/95 text-white font-extrabold text-xs rounded-md shadow transition-all cursor-pointer border border-transparent hover:border-turmeric-gold"
                >
                  બંધ કરો (Close)
                </button>
              </div>
            </div>

            {/* Content Area */}
            <div className="flex-1 flex flex-col min-w-0 h-full bg-white relative text-left">
              {/* Floating Close Button for Mobile & Header */}
              <div className="flex justify-between items-center px-6 py-4 border-b border-deep-indigo/10 shrink-0">
                <div className="flex items-center gap-2">
                  {React.createElement(tabs.find(t => t.id === activeTab)?.icon || Info, {
                    className: "w-5 h-5 text-turmeric-gold"
                  })}
                  <h3 className="text-sm font-heading font-black text-deep-indigo">
                    {tabs.find(t => t.id === activeTab)?.label}
                  </h3>
                </div>
                <button
                  onClick={onClose}
                  className="p-1.5 rounded-md bg-wheat-cream/40 text-deep-indigo hover:bg-wheat-cream transition-colors cursor-pointer border border-deep-indigo/10"
                  title="Close Dialog"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Tab Contents Pane */}
              <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-6 text-gray-700 font-medium text-xs sm:text-sm leading-relaxed">
                {activeTab === 'about' && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    <div className="bg-deep-indigo/[0.03] border border-deep-indigo/15 rounded-md p-4 flex gap-3.5 items-start">
                      <div className="p-2 bg-white rounded-md text-deep-indigo border border-deep-indigo/15 shrink-0">
                        <Building className="w-5 h-5 text-turmeric-gold" />
                      </div>
                      <p className="text-gray-700 font-semibold">
                        <strong>STAR KING NETWORK</strong> એક ખાનગી ડિજિટલ સેવા પ્લેટફોર્મ છે, જેનો હેતુ લોકોને વિવિધ સરકારી યોજનાઓ, ઓનલાઈન સેવાઓ અને ડિજિટલ પ્રક્રિયાઓ વિશે સરળ ભાષામાં માહિતી અને માર્ગદર્શન પૂરું પાડવાનો છે.
                      </p>
                    </div>

                    <div className="space-y-3">
                      <h4 className="font-heading font-extrabold text-deep-indigo flex items-center gap-1.5 text-sm">
                        <CheckCircle className="w-4 h-4 text-field-green" />
                        અમે લોકોને નીચે જેવી સેવાઓમાં સહાય કરવાનો પ્રયાસ કરીએ છીએ:
                      </h4>
                      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3 pl-1">
                        {[
                          'સરકારી યોજનાઓની માહિતી',
                          'ઓનલાઈન ફોર્મ ભરવાની સહાય',
                          'સ્કોલરશિપ અને એડમિશન સંબંધિત માર્ગદર્શન',
                          'ખેડૂત સંબંધિત સેવાઓની માહિતી',
                          'ડિજિટલ દસ્તાવેજ સેવાઓ અંગે માર્ગદર્શન'
                        ].map((srv, idx) => (
                          <li key={idx} className="flex items-center gap-2 bg-wheat-cream/10 p-3 rounded-md border border-deep-indigo/10 font-bold text-gray-700">
                            <Check className="w-4 h-4 text-field-green shrink-0" />
                            <span>{srv}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <p className="text-gray-750 font-semibold bg-wheat-cream/10 p-4 rounded-md border border-deep-indigo/10">
                      અમારું લક્ષ્ય ટેકનોલોજી દ્વારા લોકો માટે સરકારી અને ડિજિટલ સેવાઓને વધુ સરળ અને સમજવા યોગ્ય બનાવવાનું છે.
                    </p>

                    <div className="bg-turmeric-gold/10 border border-turmeric-gold/25 text-gray-800 rounded-md p-4 flex gap-3 items-start">
                      <AlertTriangle className="w-5 h-5 text-turmeric-gold shrink-0 mt-0.5" />
                      <div>
                        <h5 className="font-heading font-extrabold text-gray-900 mb-0.5 text-xs">મહત્વપૂર્ણ સૂચના:</h5>
                        <p className="text-xs font-bold text-gray-700">
                          STAR KING NETWORK કોઈ સરકારી વિભાગ, મંત્રાલય અથવા સરકારી સંસ્થા નથી. અમે એક સંપૂર્ણપણે ખાનગી સેવા પ્લેટફોર્મ છીએ.
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'privacy' && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    <div className="bg-field-green/10 border border-field-green/20 rounded-md p-4 flex gap-3 items-start">
                      <ShieldCheck className="w-5 h-5 text-field-green shrink-0 mt-0.5" />
                      <p className="text-gray-700 font-semibold">
                        <strong>STAR KING NETWORK</strong> તમારા દ્વારા આપવામાં આવેલી માહિતીની ગોપનીયતા અને સુરક્ષા જાળવવા માટે સંપૂર્ણપણે પ્રતિબદ્ધ છે.
                      </p>
                    </div>

                    <div className="space-y-3">
                      <h4 className="font-heading font-extrabold text-deep-indigo text-sm">અમે નીચેની માહિતી મેળવી શકીએ છીએ:</h4>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                        {[
                          'નામ (Name)',
                          'મોબાઇલ નંબર (Mobile)',
                          'સરનામું (Address)',
                          'ગામ/તાલુકો/જિલ્લો',
                          'સેવા સંબંધિત માહિતી',
                          'જરૂરી દસ્તાવેજો (જ્યારે જરૂરી હોય ત્યારે)'
                        ].map((info, idx) => (
                          <div key={idx} className="bg-wheat-cream/10 p-2.5 rounded-md border border-deep-indigo/10 text-center font-bold text-gray-700">
                            {info}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h4 className="font-heading font-extrabold text-deep-indigo text-sm">માહિતીનો ઉપયોગ:</h4>
                      <p className="text-xs text-gray-500 font-bold">તમારી માહિતીનો ઉપયોગ નીચેની બાબતો માટે કરવામાં આવશે:</p>
                      <ul className="space-y-2">
                        {[
                          'તમારી વિનંતી કરેલ ડિજિટલ સેવા આપવા માટે',
                          'યોજના અને ભરતીના અરજી પ્રક્રિયામાં સચોટ સહાય કરવા',
                          'પ્રક્રિયાના અપડેટ્સ અંગે તમારી સાથે સંપર્ક કરવા',
                          'સેવાની ગુણવત્તા અને અનુભવ સુધારવા માટે'
                        ].map((use, idx) => (
                          <li key={idx} className="flex items-center gap-2 font-bold text-gray-700">
                            <span className="w-1.5 h-1.5 rounded-full bg-field-green shrink-0" />
                            <span>{use}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-wheat-cream/10 p-4 rounded-md border border-deep-indigo/10 space-y-1.5">
                      <h4 className="font-heading font-extrabold text-deep-indigo flex items-center gap-1.5 text-sm">
                        <Lock className="w-4 h-4 text-field-green" />
                        ડેટા સુરક્ષા (Data Security):
                      </h4>
                      <p className="text-xs font-semibold text-gray-600">
                        અમે તમારી માહિતીની સુરક્ષા માટે યોગ્ય ટેકનિકલ પગલાં લઈએ છીએ. તમારી મંજૂરી વગર તમારી વ્યક્તિગત માહિતી કોઈપણ અન્ય તૃતીય પક્ષ સાથે વેચવામાં, ભાડે આપવા અથવા શેર કરવામાં આવશે નહીં.
                      </p>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'terms' && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    <div className="bg-turmeric-gold/10 border border-turmeric-gold/25 rounded-md p-4 text-gray-800 font-semibold">
                      STAR KING NETWORK નો ઉપયોગ કરતા પહેલા નીચેની શરતો કાળજીપૂર્વક વાંચવી અને સ્વીકારવી જરૂરી છે:
                    </div>

                    <div className="space-y-3">
                      <h4 className="font-heading font-extrabold text-deep-indigo text-sm">મુખ્ય શરતો અને નિયમો:</h4>
                      <ul className="space-y-3">
                        {[
                          'અમારી સેવાઓનો ઉપયોગ માત્ર કાયદેસર અને સત્તાવાર હેતુઓ માટે જ કરવો.',
                          'અરજી અથવા ફોર્મ ભરવા માટે ગ્રાહક દ્વારા આપવામાં આવેલી તમામ માહિતી અને દસ્તાવેજો સાચા અને સંપૂર્ણ હોવા જોઈએ.',
                          'ખોટી માહિતી અથવા નકલી દસ્તાવેજો આપવા બદલ તેની સંપૂર્ણ કાનૂની જવાબદારી ગ્રાહકની પોતાની રહેશે.',
                          'કોઈપણ સરકારી યોજના અથવા નોકરીની અરજી મંજૂર થવાની ગેરંટી STAR KING NETWORK આપતું નથી.',
                          'સરકારી નિયમો, પાત્રતા ધોરણો અને સરકારી અરજી પર અંતિમ નિર્ણય સંબંધિત સરકારી વિભાગનો રહેશે.',
                          'સરકારી નિયમો અનુસાર સેવાઓની પ્રક્રિયાઓ અને શુલ્કમાં સમયસર ફેરફાર થઈ શકે છે.'
                        ].map((term, idx) => (
                          <li key={idx} className="flex gap-2.5 bg-wheat-cream/10 p-3 rounded-md border border-deep-indigo/10 font-bold text-gray-700 text-left">
                            <span className="w-5 h-5 rounded-md bg-turmeric-gold text-white text-xs font-black flex items-center justify-center shrink-0">
                              {idx + 1}
                            </span>
                            <span>{term}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'refund' && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    <div className="bg-deep-indigo/[0.03] border border-deep-indigo/15 rounded-md p-4 flex gap-3.5 items-start">
                      <div className="p-2 bg-white rounded-md text-deep-indigo border border-deep-indigo/15 shrink-0">
                        <Coins className="w-5 h-5 text-turmeric-gold" />
                      </div>
                      <p className="text-gray-700 font-semibold">
                        <strong>STAR KING NETWORK</strong> દ્વારા આપવામાં આવતી તમામ સેવાઓ માટેની વ્યાવસાયિક ફી સેવા શરૂ કરતા પહેલા ગ્રાહકને સ્પષ્ટપણે જણાવવામાં આવે છે.
                      </p>
                    </div>

                    <div className="space-y-3">
                      <h4 className="font-heading font-extrabold text-deep-indigo text-sm">રિફંડ સંબંધિત નિયમો:</h4>
                      <ul className="space-y-3">
                        {[
                          'જો ગ્રાહક તરફથી ચૂકવણી કર્યા બાદ અરજી ફોર્મ ભરવાની સેવા હજુ શરૂ કરવામાં આવી ન હોય અને સંજોગો અનુસાર યોગ્ય જણાય, તો જ રિફંડ માટે વિચારણા કરવામાં આવશે.',
                          'એકવાર ફોર્મ ભરવાની પ્રક્રિયા પૂર્ણ થઈ જાય અથવા સબમિટ થઈ જાય, ત્યાર પછી સામાન્ય રીતે કોઈપણ સંજોગોમાં લીધેલી વ્યાવસાયિક ફી પરત કરવામાં આવશે નહીં.',
                          'અધિકૃત સરકારી પોર્ટલની નિયત અરજી ફી, સરકારી ચાર્જ અથવા પેમેન્ટ ગેટવે ચાર્જ પર STAR KING NETWORK નું કોઈ નિયંત્રણ નથી, તેથી તેમાં કોઈ રિફંડ મળી શકશે નહીં.',
                          'રિફંડ સંબંધિત કોઈપણ પ્રશ્નો અથવા મૂંઝવણ માટે ગ્રાહક સીધો જ અમારા સંપર્ક નંબરો દ્વારા અમારો સંપર્ક સાધી શકે છે.'
                        ].map((refundRule, idx) => (
                          <li key={idx} className="flex items-start gap-2.5 font-semibold text-gray-700 text-left">
                            <CheckCircle className="w-4 h-4 text-field-green shrink-0 mt-0.5" />
                            <span>{refundRule}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'contact' && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    <div className="bg-wheat-cream/10 p-5 rounded-md border border-deep-indigo/15 space-y-4">
                      <div className="text-center pb-2 border-b border-deep-indigo/10">
                        <h4 className="text-base font-heading font-black text-deep-indigo">STAR KING NETWORK CONTACT PANEL</h4>
                        <p className="text-xs text-turmeric-gold font-extrabold">અમારો હેતુ લોકોને સરળ અને વિશ્વસનીય ડિજિટલ સેવા સહાય પૂરી પાડવાનો છે.</p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <a 
                          href="https://wa.me/919726074581" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center gap-3.5 bg-field-green/10 hover:bg-field-green/15 text-field-green border border-field-green/20 p-4 rounded-md transition-all hover:scale-[1.02]"
                        >
                          <div className="p-2.5 bg-white rounded-md shadow-sm text-field-green shrink-0 border border-field-green/15">
                            <MessageCircle className="w-5 h-5 fill-current" />
                          </div>
                          <div className="text-left">
                            <p className="text-[10px] font-bold text-gray-500 uppercase">WhatsApp Chat & Call</p>
                            <p className="text-sm font-black">+91 97260 74581</p>
                          </div>
                        </a>

                        <a 
                          href="mailto:starkingnetwork@gmail.com"
                          className="flex items-center gap-3.5 bg-deep-indigo/10 hover:bg-deep-indigo/15 text-deep-indigo border border-deep-indigo/20 p-4 rounded-md transition-all hover:scale-[1.02]"
                        >
                          <div className="p-2.5 bg-white rounded-md shadow-sm text-deep-indigo shrink-0 border border-deep-indigo/15">
                            <Mail className="w-5 h-5 text-turmeric-gold" />
                          </div>
                          <div className="text-left">
                            <p className="text-[10px] font-bold text-gray-500 uppercase">Email Address</p>
                            <p className="text-xs font-black">starkingnetwork@gmail.com</p>
                          </div>
                        </a>

                        <a 
                          href="https://chat.whatsapp.com/GUpckcU2YiSKa9WdyN87ZX?s=sh&p=a&mlu=0&ilr=0"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-3.5 bg-deep-indigo/10 hover:bg-deep-indigo/15 text-deep-indigo border border-deep-indigo/20 p-4 rounded-md transition-all hover:scale-[1.02] sm:col-span-2 justify-center"
                        >
                          <div className="p-2.5 bg-white rounded-md shadow-sm text-deep-indigo shrink-0 border border-deep-indigo/15">
                            <Users className="w-5 h-5 text-turmeric-gold" />
                          </div>
                          <div className="text-left">
                            <p className="text-[10px] font-bold text-gray-500 uppercase">Official Updates Group</p>
                            <p className="text-xs font-black">અમારા ઓફિશિયલ વોટ્સએપ ગ્રુપ લિંક (દરેક અપડેટ મેળવો)</p>
                          </div>
                        </a>

                        <a 
                          href="https://youtube.com/@starking-network?si=JCC6rgrnJSEUV1OJ"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-3.5 bg-brick-red/10 hover:bg-brick-red/15 text-brick-red border border-brick-red/20 p-4 rounded-md transition-all hover:scale-[1.02] sm:col-span-2 justify-center"
                        >
                          <div className="p-2.5 bg-white rounded-md shadow-sm text-brick-red shrink-0 border border-brick-red/15">
                            <Youtube className="w-5 h-5" />
                          </div>
                          <div className="text-left">
                            <p className="text-[10px] font-bold text-gray-500 uppercase">YouTube Channel</p>
                            <p className="text-xs font-black">અમારી યુટ્યુબ ચેનલ (સ્ટાર કિંગ નેટવર્ક) સબસ્ક્રાઇબ કરો</p>
                          </div>
                        </a>
                      </div>
                    </div>

                    <div className="flex gap-2.5 text-xs text-brick-red bg-brick-red/10 border border-brick-red/20 p-3.5 rounded-md font-bold">
                      <AlertTriangle className="w-5 h-5 text-brick-red shrink-0 mt-0.5 animate-pulse" />
                      <span>સાદો મોબાઇલ વોઇસ કોલ કરવો નહિ. કૃપા કરીને કોલ અને મેસેજ માટે માત્ર વોટ્સએપનો જ ઉપયોગ કરવો જેથી અમે સચોટ જવાબ આપી શકીએ.</span>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'disclaimer' && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    <div className="bg-brick-red/10 border border-brick-red/20 text-brick-red rounded-md p-5 flex gap-4 items-start">
                      <AlertTriangle className="w-6 h-6 text-brick-red shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-heading font-extrabold text-brick-red mb-1 text-sm">મહત્વપૂર્ણ ડિસ્ક્લેમર સૂચના:</h4>
                        <p className="text-xs font-bold leading-relaxed text-gray-800">
                          STAR KING NETWORK એક સંપૂર્ણપણે ખાનગી અને સ્વતંત્ર ડિજિટલ સેવા પ્લેટફોર્મ છે.
                        </p>
                      </div>
                    </div>

                    <div className="space-y-3 font-semibold text-gray-700 text-xs sm:text-sm text-left">
                      <p>
                        અમે ભારત સરકાર, ગુજરાત સરકાર અથવા અન્ય કોઈપણ સરકારી વિભાગ, મંત્રાલય, યોજના સંચાલક સંસ્થા કે અધિકૃત સરકારી એજન્સી સાથે કોઈપણ પ્રકારનું જોડાણ કે સંલગ્નતા ધરાવતા નથી.
                      </p>
                      <p>
                        અમે માત્ર સાર્વજનિક પોર્ટલ પર ઉપલબ્ધ સરકારી યોજનાઓ, નવી ભરતી અને ડિજિટલ સેવાઓ અંગે ગ્રાહકોની સુવિધા માટે માહિતી, પરામર્શ અને ઓનલાઈન ફોર્મ સબમિટ કરવામાં સહાય પૂરી પાડીએ છીએ.
                      </p>
                      <p>
                        કોઈપણ યોજના માટે પાત્રતા નક્કી કરવી, અરજીની મંજૂરી આપવી, સરકારી સહાય ચૂકવવી કે અન્ય કોઈપણ સત્તાવાર નિર્ણય લેવાનો અધિકાર ફક્ત અને ફક્ત જે તે સરકારી વિભાગના અધીન છે.
                      </p>
                      <p className="text-deep-indigo font-extrabold bg-wheat-cream/15 p-4 rounded-md border border-deep-indigo/15">
                        * વપરાશકર્તાઓને નમ્ર અપીલ અને સલાહ આપવામાં આવે છે કે કોઈપણ મહત્વપૂર્ણ અરજી સબમિટ કરતા પહેલા સંબંધિત સત્તાવાર સરકારી વેબસાઇટ્સ પર નિયમો અને વિગતોની ખાતરીપૂર્વક ચકાસણી કરી લેવી.
                      </p>
                    </div>
                  </motion.div>
                )}
              </div>

              {/* Close Button at bottom of scroll (Mobile Only) */}
              <div className="p-4 bg-wheat-cream/30 border-t border-deep-indigo/10 flex justify-end md:hidden shrink-0">
                <button
                  onClick={onClose}
                  className="w-full py-3 bg-deep-indigo hover:bg-deep-indigo/95 text-white font-extrabold text-xs rounded-md shadow transition-all cursor-pointer border border-transparent hover:border-turmeric-gold"
                >
                  બંધ કરો (Close)
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </AnimatePresence>
  );
}
