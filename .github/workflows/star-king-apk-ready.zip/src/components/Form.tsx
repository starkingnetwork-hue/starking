import React, { useState, useEffect } from 'react';
import { submitApplication } from '../utils/localStore';
import { GUJARAT_DISTRICTS } from '../utils/gujaratData';
import { SITE_CONFIG, buildWhatsAppLink } from '../config/siteConfig';
import { 
  User, 
  MapPin, 
  Building, 
  Home, 
  FileText, 
  MessageSquare, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  Copy, 
  Check, 
  Printer, 
  Search, 
  ArrowRight, 
  PlusCircle,
  HelpCircle,
  ExternalLink
} from 'lucide-react';

interface FormProps {
  prefilledService?: string;
  onRequestSubmitted?: () => void;
  onNavigateHome?: () => void;
  onNavigateTrack?: (appId?: string) => void;
  onNavigateServices?: () => void;
}

// 7 Required Primary Service Categories with their services
export interface ServiceCategoryConfig {
  id: string;
  name: string; // Exact category name
  services: string[];
}

export const CATEGORY_OPTIONS: ServiceCategoryConfig[] = [
  {
    id: 'student',
    name: 'વિદ્યાર્થી / Student',
    services: [
      'ડિજિટલ ગુજરાત શિષ્યવૃત્તિ (Digital Gujarat Scholarship)',
      'મુખ્યમંત્રી યુવા સ્વાવલંબન યોજના (MYSY શિષ્યવૃત્તિ)',
      'નેશનલ સ્કોલરશિપ પોર્ટલ (NSP શિષ્યવૃત્તિ)',
      'ACPC એન્જિનિયરિંગ / ડિપ્લોમા એડમિશન',
      'ગુજરાત યુનિવર્સિટી કોલેજ પ્રવેશ ફોર્મ',
      'ITI પ્રવેશ ફોર્મ (ટેકનિકલ ટ્રેડ્સ)',
      'B.Ed / M.Ed સેન્ટ્રલાઇઝ્ડ ઓનલાઇન પ્રવેશ',
      'વિદેશ અભ્યાસ લોન સહાય (૪% વ્યાજ સબસિડી)',
      'અન્ય વિદ્યાર્થી સેવા (Other Student Service)'
    ]
  },
  {
    id: 'farmer',
    name: 'ખેડૂત / Farmer',
    services: [
      'i-Khedut ટ્રેક્ટર અને ખેત ઓજાર સબસિડી',
      'PM કિસાન સન્માન નિધિ (નવી નોંધણી / e-KYC)',
      'પીએમ કુસુમ સોલાર પંપ સબસિડી (૯૦% સહાય)',
      'કાંટાળી તારની વાડ / તાર ફેન્સિંગ યોજના',
      'ખેડૂત સ્માર્ટફોન ખરીદી સહાય યોજના',
      '૭/૧૨ અને ૮-અ ના ડિજિટલ ઉતારા (AnyRoR)',
      'ટપક સિંચાઈ / ડ્રીપ ઇરિગેશન સહાય',
      'અન્ય ખેડૂત સહાય યોજના (Other Farmer Scheme)'
    ]
  },
  {
    id: 'animal_husbandry',
    name: 'પશુપાલન / Animal Husbandry',
    services: [
      'પશુપાલન સહાય યોજના (i-Khedut પશુપાલન)',
      'દૂધાળા પશુ (ગાય / ભેંસ) ખરીદી સહાય અને લોન',
      'પશુ શેડ નિર્માણ સહાય યોજના',
      'ઘાસચારો કાપવાનું મશીન (ચાફ કટર) સબસિડી',
      'મુખ્યમંત્રી ગૌમાતા પોષણ યોજના',
      'પશુધન વિમા યોજના (Animal Insurance)',
      'અન્ય પશુપાલન સહાય સેવા (Other Animal Husbandry Service)'
    ]
  },
  {
    id: 'employment',
    name: 'નોકરી / Employment',
    services: [
      'ગુજરાત પોલીસ કોન્સ્ટેબલ અને PSI ભરતી ફોર્મ',
      'GSSSB જુનિયર / સિનિયર ક્લાર્ક (CBRT) ફોર્મ',
      'ગુજરાત વનરક્ષક (Forest Guard) ભરતી',
      'GPSC વર્ગ ૧ અને વર્ગ ૨ ઓનલાઇન ફોર્મ',
      'ઇન્ડિયન આર્મી અગ્નિવીર (Army Agniveer) ભરતી રેલી',
      'GPSSB પંચાયત તલાટી કમ મંત્રી ભરતી સહાય',
      'ગુજરાત હાઇકોર્ટ પટાવાળા / આસિસ્ટન્ટ ભરતી',
      'અન્ય સરકારી / બોર્ડ ભરતી ફોર્મ (Other Recruitment Form)'
    ]
  },
  {
    id: 'government_scheme',
    name: 'સરકારી યોજના / Government Scheme',
    services: [
      'આયુષ્માન ભારત કાર્ડ (PM-JAY - ₹૧૦ લાખ નિઃશુલ્ક સારવાર)',
      'પ્રધાનમંત્રી આવાસ યોજના (PMAY - ₹૧.૨૦ લાખ મકાન સહાય)',
      'વહાલી દીકરી યોજના (કુલ ₹૧,૧૦,૦૦૦ ની સહાય)',
      'પીએમ વિશ્વકર્મા યોજના (ટૂલકિટ સહાય + ₹૩ લાખ લોન)',
      'ગંગા સ્વરૂપા વિધવા આર્થિક સહાય (માસિક પેન્શન)',
      'ઈ-શ્રમ કાર્ડ અને શ્રમિક સુરક્ષા વીમો',
      'માનવ ગરિમા યોજના (મફત ટૂલકિટ સહાય)',
      'માનવ કલ્યાણ યોજના (કારીગર સહાય)',
      'અન્ય સરકારી યોજના (Other Government Scheme)'
    ]
  },
  {
    id: 'certificates_documents',
    name: 'દસ્તાવેજ / પ્રમાણપત્ર / Certificate & Document Assistance',
    services: [
      'આધાર કાર્ડ (Aadhaar Card Update / e-KYC)',
      'પાન કાર્ડ (PAN Card - નવું / સુધારો)',
      'આવકનો દાખલો (Income Certificate)',
      'જાતિનો દાખલો (SC/ST/SEBC) / નોન-ક્રીમીલેયર (NCL)',
      'ઈડબલ્યુએસ પ્રમાણપત્ર (EWS Certificate)',
      'રેશન કાર્ડ સેવાઓ (Ration Card)',
      'ચૂંટણી કાર્ડ (Voter ID Card)',
      'ડ્રાઇવિંગ લાયસન્સ / લર્નિંગ લાયસન્સ (Sarathi)',
      'પોલીસ વેરિફિકેશન અને ચારિત્ર્ય પ્રમાણપત્ર (PCC)',
      'અન્ય દસ્તાવેજ / પ્રમાણપત્ર સહાય (Other Document Assistance)'
    ]
  },
  {
    id: 'other',
    name: 'અન્ય / Other',
    services: [
      '💻 અન્ય ઓનલાઈન સેવાઓ (Other Online Services)'
    ]
  }
];

export const Form: React.FC<FormProps> = ({
  prefilledService,
  onRequestSubmitted = () => {},
  onNavigateHome = () => {},
  onNavigateTrack = (_appId?: string) => {},
  onNavigateServices = () => {}
}) => {
  // Form Input States
  const [fullName, setFullName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [district, setDistrict] = useState('');
  const [taluka, setTaluka] = useState('');
  const [village, setVillage] = useState('');
  
  // Category & Service Selection States
  const [selectedCategory, setSelectedCategory] = useState('દસ્તાવેજ / પ્રમાણપત્ર / Certificate & Document Assistance');
  const [selectedService, setSelectedService] = useState('આધાર કાર્ડ (Aadhaar Card Update / e-KYC)');
  const [customService, setCustomService] = useState('');
  const [message, setMessage] = useState('');
  const [agreedToTerms, setAgreedToTerms] = useState(true);

  // Current category object and service options
  const activeCategoryObj = CATEGORY_OPTIONS.find(c => c.name === selectedCategory) || CATEGORY_OPTIONS[0];
  const activeServicesList = activeCategoryObj.services;

  // UI States
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [lastSubmittedId, setLastSubmittedId] = useState('');
  const [lastSubmittedDetails, setLastSubmittedDetails] = useState<{
    fullName: string;
    mobileNumber: string;
    village: string;
    taluka: string;
    district: string;
    category: string;
    service: string;
    message: string;
    dateTime: string;
  } | null>(null);

  const [copied, setCopied] = useState(false);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);

  // Find selected district object and its talukas
  const selectedDistrictObj = GUJARAT_DISTRICTS.find(
    (d) => d.name === district || district.includes(d.name) || (d.englishName && district.toLowerCase().includes(d.englishName.toLowerCase()))
  );
  const currentTalukaList = selectedDistrictObj ? selectedDistrictObj.talukas : [];

  // Handle prefilled service from navigation
  useEffect(() => {
    if (prefilledService) {
      let matchedCat: ServiceCategoryConfig | undefined;
      let matchedSrv: string | undefined;

      // Find if prefilled matches any service in our categories
      for (const cat of CATEGORY_OPTIONS) {
        const found = cat.services.find(s => 
          s.toLowerCase().includes(prefilledService.toLowerCase()) || 
          prefilledService.toLowerCase().includes(s.toLowerCase())
        );
        if (found) {
          matchedCat = cat;
          matchedSrv = found;
          break;
        }
      }

      if (matchedCat && matchedSrv) {
        setSelectedCategory(matchedCat.name);
        setSelectedService(matchedSrv);
      } else {
        // Fallback to "અન્ય / Other"
        const otherCat = CATEGORY_OPTIONS.find(c => c.id === 'other') || CATEGORY_OPTIONS[CATEGORY_OPTIONS.length - 1];
        setSelectedCategory(otherCat.name);
        setSelectedService(otherCat.services[0]);
        setCustomService(prefilledService);
      }
    }
  }, [prefilledService]);

  // Form Validation
  const validateForm = () => {
    const errors: Record<string, string> = {};

    if (!fullName.trim()) {
      errors.fullName = 'કૃપા કરીને અરજદારનું પૂરું નામ દાખલ કરો.';
    }

    if (!mobileNumber.trim()) {
      errors.mobileNumber = 'મોબાઈલ નંબર દાખલ કરવો જરૂરી છે.';
    } else if (!/^[0-9]{10}$/.test(mobileNumber.trim())) {
      errors.mobileNumber = 'કૃપા કરીને સાચો ૧૦ આંકડાનો મોબાઈલ નંબર દાખલ કરો.';
    }

    if (!district.trim()) {
      errors.district = 'કૃપા કરીને જિલ્લો પસંદ કરો.';
    }

    if (!taluka.trim()) {
      errors.taluka = 'કૃપા કરીને તાલુકો પસંદ કરો.';
    }

    if (!village.trim()) {
      errors.village = 'ગામ / શહેરનું નામ દાખલ કરો.';
    }

    if (!selectedCategory.trim()) {
      errors.selectedCategory = 'કૃપા કરીને કેટેગરી પસંદ કરો.';
    }

    if ((selectedCategory.includes('અન્ય') || selectedService.includes('અન્ય')) && !customService.trim()) {
      errors.customService = 'કૃપા કરીને સેવાનું નામ સ્પષ્ટ લખો.';
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Final Form Submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!validateForm()) {
      // Scroll to first error
      const firstErr = document.querySelector('.border-red-400, .text-red-600');
      if (firstErr) {
        firstErr.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }

    if (!agreedToTerms) {
      setErrorMessage('કૃપા કરીને નિયમો અને શરતોની સ્વ-ઘોષણા સ્વીકારો.');
      return;
    }

    setIsSubmitting(true);

    try {
      const finalServiceName = (selectedCategory.includes('અન્ય') || selectedService.includes('અન્ય')) && customService.trim()
        ? `અન્ય: ${customService.trim()}`
        : `${selectedCategory.split(' / ')[0]} - ${selectedService}`;

      // Submit to local store
      const generatedId = await submitApplication({
        fullName: fullName.trim(),
        mobile: mobileNumber.trim(),
        village: village.trim(),
        taluka: taluka.trim(),
        district: district.trim(),
        service: finalServiceName,
        message: message.trim()
      });

      const submittedData = {
        fullName: fullName.trim(),
        mobileNumber: mobileNumber.trim(),
        village: village.trim(),
        taluka: taluka.trim(),
        district: district.trim(),
        category: selectedCategory,
        service: finalServiceName,
        message: message.trim(),
        dateTime: new Date().toLocaleString('gu-IN', { timeZone: 'Asia/Kolkata' })
      };

      setLastSubmittedId(generatedId);
      setLastSubmittedDetails(submittedData);
      setSubmitSuccess(true);
      onRequestSubmitted();

      window.scrollTo({ top: 0, behavior: 'smooth' });

    } catch (err: any) {
      console.error('Submission error:', err);
      setErrorMessage(err.message || 'સબમિશન દરમિયાન કોઈ ક્ષતિ સર્જાઈ છે. કૃપા કરીને ફરી પ્રયાસ કરો.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Copy Application ID to Clipboard
  const handleCopyId = () => {
    if (!lastSubmittedId) return;
    navigator.clipboard.writeText(lastSubmittedId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Reset form for new submission
  const handleResetForm = () => {
    setFullName('');
    setMobileNumber('');
    setDistrict('');
    setTaluka('');
    setVillage('');
    setSelectedCategory('દસ્તાવેજ / પ્રમાણપત્ર / Certificate & Document Assistance');
    setSelectedService('આધાર કાર્ડ (Aadhaar Card Update / e-KYC)');
    setCustomService('');
    setMessage('');
    setValidationErrors({});
    setErrorMessage('');
    setSubmitSuccess(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // PDF Receipt Generation
  const handleDownloadPDF = () => {
    if (!lastSubmittedId || !lastSubmittedDetails) return;
    setIsGeneratingPDF(true);

    try {
      const iframe = document.createElement('iframe');
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0';
      iframe.style.height = '0';
      iframe.style.border = '0';
      document.body.appendChild(iframe);

      const doc = iframe.contentWindow?.document || iframe.contentDocument;
      if (!doc) throw new Error('પ્રિન્ટ એન્જિન ઉપલબ્ધ નથી.');

      const receiptHTML = `
        <!DOCTYPE html>
        <html lang="gu">
        <head>
          <meta charset="UTF-8">
          <title>STAR KING NETWORK - Receipt #${lastSubmittedId}</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Gujarati:wght@400;500;600;700&display=swap');
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body { font-family: 'Noto Sans Gujarati', sans-serif; background-color: #ffffff; color: #0f172a; padding: 10mm; }
            .container { border: 1.5mm solid #1e3a8a; padding: 5mm; min-height: 250mm; display: flex; flex-direction: column; justify-content: space-between; }
            .header { background-color: #1e3a8a; color: #ffffff; padding: 6mm; text-align: center; border-radius: 2mm; margin-bottom: 5mm; }
            .header h1 { font-size: 20px; font-weight: 700; margin-bottom: 2mm; }
            .header p { font-size: 11px; opacity: 0.95; }
            .receipt-title { text-align: center; font-size: 15px; font-weight: 700; color: #1e3a8a; margin-bottom: 4mm; }
            .meta-box { background-color: #f8fafc; border: 0.3mm solid #cbd5e1; border-radius: 2mm; padding: 4mm; display: flex; justify-content: space-between; margin-bottom: 5mm; }
            .meta-item { display: flex; flex-direction: column; }
            .meta-label { font-size: 10px; color: #64748b; font-weight: 700; text-transform: uppercase; margin-bottom: 1mm; }
            .meta-value { font-size: 14px; font-weight: 700; color: #1e3a8a; }
            .table-header { background-color: #1e3a8a; color: #ffffff; padding: 2.5mm 3mm; font-size: 11px; font-weight: 700; border-radius: 1mm; margin-bottom: 2mm; }
            .row { display: flex; padding: 3mm 1mm; border-bottom: 0.3mm solid #e2e8f0; align-items: center; font-size: 11px; }
            .row-label { width: 35%; color: #64748b; font-weight: 700; }
            .row-value { width: 65%; color: #0f172a; font-weight: 600; }
            .status-badge { background-color: #ecfdf5; border: 0.3mm solid #10b981; color: #047857; padding: 1mm 3mm; border-radius: 10mm; font-size: 10px; font-weight: 700; }
            .footer { display: flex; justify-content: space-between; align-items: flex-end; border-top: 0.3mm solid #cbd5e1; padding-top: 4mm; margin-top: 4mm; }
            .seal { border: 0.4mm solid #10b981; background-color: #f0fdf4; border-radius: 2mm; padding: 2.5mm 3.5mm; text-align: center; width: 45mm; }
          </style>
        </head>
        <body>
          <div class="container">
            <div>
              <div class="header">
                <h1>સ્ટાર કિંગ નેટવર્ક (STAR KING NETWORK)</h1>
                <p>ડિજિટલ સર્વિસ પ્લેટફોર્મ • તમામ સરકારી અને ઓનલાઇન સેવા સહાય કેન્દ્ર</p>
              </div>
              <div class="receipt-title">ઓનલાઇન અરજી સ્વીકૃતિ રસીદ (Application Receipt)</div>
              <div class="meta-box">
                <div class="meta-item">
                  <span class="meta-label">અરજી ક્રમાંક (Application ID):</span>
                  <span class="meta-value">#${lastSubmittedId}</span>
                </div>
                <div class="meta-item" style="text-align: right;">
                  <span class="meta-label">તારીખ અને સમય:</span>
                  <span class="meta-value">${lastSubmittedDetails.dateTime}</span>
                </div>
              </div>
              <div class="table-header">અરજદાર અને સેવાની વિગતો</div>
              <div class="row"><div class="row-label">અરજદારનું નામ:</div><div class="row-value">${lastSubmittedDetails.fullName}</div></div>
              <div class="row"><div class="row-label">મોબાઈલ નંબર:</div><div class="row-value">+91 ${lastSubmittedDetails.mobileNumber}</div></div>
              <div class="row"><div class="row-label">સરનામું:</div><div class="row-value">ગામ: ${lastSubmittedDetails.village}, તા: ${lastSubmittedDetails.taluka}, જિ: ${lastSubmittedDetails.district}</div></div>
              <div class="row"><div class="row-label">સેવાનું નામ:</div><div class="row-value" style="color: #1e3a8a; font-weight: 700;">${lastSubmittedDetails.service}</div></div>
              <div class="row"><div class="row-label">સ્થિતિ:</div><div class="row-value"><span class="status-badge">● સબમિટ કરેલ (Submitted)</span></div></div>
            </div>
            <div class="footer">
              <div>
                <div style="font-size: 10px; font-weight: 700; color: #1e3a8a; margin-bottom: 1mm;">સહાયતા સંપર્ક:</div>
                <div style="font-size: 10px; color: #475569;">વોટ્સએપ હેલ્પલાઇન: +91 97260 74581</div>
                <div style="font-size: 10px; color: #475569;">© ૨૦૨૬ STAR KING NETWORK. સર્વ હક સ્વાધીન.</div>
              </div>
              <div class="seal">
                <div style="font-size: 9px; font-weight: 700; color: #047857;">VERIFIED & ACCEPTED</div>
                <div style="font-size: 8px; font-weight: 700; color: #1e3a8a;">STAR KING NETWORK</div>
              </div>
            </div>
          </div>
          <script>
            document.fonts.ready.then(() => {
              setTimeout(() => { window.print(); }, 300);
            });
          </script>
        </body>
        </html>
      `;

      doc.open();
      doc.write(receiptHTML);
      doc.close();

      setTimeout(() => {
        if (document.body.contains(iframe)) {
          document.body.removeChild(iframe);
        }
      }, 5000);

    } catch (err) {
      console.error('PDF error:', err);
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  // WhatsApp Share Details - Clean connection with Application ID
  const handleWhatsAppShare = () => {
    if (!lastSubmittedId) return;
    const message = SITE_CONFIG.whatsapp.getApplicationQueryMessage(lastSubmittedId);
    const whatsappUrl = buildWhatsAppLink(message);
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div id="form-container" className="py-6 sm:py-10 px-3.5 sm:px-6">
      
      {/* Maximum Width Desktop Container */}
      <div className="max-w-2xl mx-auto space-y-6">

        {/* Page Title & Subtitle */}
        <div className="text-center space-y-2">
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            ફોર્મ ભરો
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto leading-relaxed">
            તમારી જરૂરી માહિતી મોકલો અને અમારી ટીમ તમને ઓનલાઈન સેવા માટે માર્ગદર્શન આપશે.
          </p>
        </div>

        {/* SUCCESS STATE CARD */}
        {submitSuccess && lastSubmittedDetails ? (
          <div id="success-card" className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-8 shadow-xs space-y-6 animate-fadeIn">
            
            {/* Header Status */}
            <div className="text-center space-y-3">
              <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-200 shadow-inner">
                <CheckCircle2 className="w-10 h-10 stroke-[2.5]" />
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                અરજી સફળતાપૂર્વક સબમિટ થઈ!
              </h2>
              <p className="text-xs sm:text-sm text-slate-600">
                તમારી ઓનલાઇન વિનંતી સફળતાપૂર્વક નોંધાઈ ગઈ છે. અમારી ટીમ દ્વારા દસ્તાવેજ ચકાસણીની પ્રક્રિયા શરૂ કરવામાં આવી છે.
              </p>
            </div>

            {/* Application ID Card */}
            <div className="p-4 sm:p-5 bg-slate-50 rounded-xl border border-slate-200 text-center space-y-2">
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                તમારો અરજી ક્રમાંક (Application ID)
              </div>
              <div className="flex items-center justify-center gap-2">
                <span className="text-2xl sm:text-3xl font-black font-mono text-deep-indigo tracking-wider">
                  #{lastSubmittedId}
                </span>
                <button
                  id="btn-copy-app-id"
                  type="button"
                  onClick={handleCopyId}
                  className="p-2 rounded-lg bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 transition-colors shadow-2xs min-w-[38px] min-h-[38px] flex items-center justify-center"
                  title="કોપી કરો"
                >
                  {copied ? (
                    <Check className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <Copy className="w-4 h-4 text-slate-600" />
                  )}
                </button>
              </div>
              <p className="text-[11px] text-amber-800 font-medium">
                ⚠️ આ Application ID ભવિષ્યમાં સ્ટેટસ ચેક કરવા સાચવી રાખો.
              </p>
            </div>

            {/* WhatsApp Document Submission Notice */}
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-left space-y-2">
              <div className="flex items-center gap-2 text-emerald-900 font-bold text-xs sm:text-sm">
                <MessageSquare className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>જરૂરી દસ્તાવેજો WhatsApp પર મોકલવા માટે અમારો સંપર્ક કરો.</span>
              </div>
              <p className="text-[11px] sm:text-xs text-emerald-800 leading-relaxed font-medium">
                તમારી અરજીની આગળની પ્રક્રિયા શરૂ કરવા માટે નીચે આપેલા લીલા બટન પર ક્લિક કરો અને તમારા જરૂરી દસ્તાવેજો સીધા વોટ્સએપ પર મોકલો.
              </p>
            </div>

            {/* Application Snapshot */}
            <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200/80 space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500 font-bold">અરજદારનું નામ:</span>
                <span className="text-slate-900 font-bold">{lastSubmittedDetails.fullName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500 font-bold">મોબાઈલ નંબર:</span>
                <span className="text-slate-900 font-bold font-mono">+91 {lastSubmittedDetails.mobileNumber}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500 font-bold">સરનામું:</span>
                <span className="text-slate-900 font-medium text-right">
                  {lastSubmittedDetails.village}, {lastSubmittedDetails.taluka}, {lastSubmittedDetails.district}
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-bold">પસંદ કરેલ સેવા:</span>
                <span className="text-deep-indigo font-bold text-right">{lastSubmittedDetails.service}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              
              {/* PDF Receipt Button */}
              <button
                id="btn-download-receipt-pdf"
                type="button"
                onClick={handleDownloadPDF}
                disabled={isGeneratingPDF}
                className="w-full py-3.5 px-4 rounded-xl bg-deep-indigo hover:bg-deep-indigo/90 text-white font-bold text-xs sm:text-sm shadow-xs transition-all flex items-center justify-center gap-2 min-h-[46px]"
              >
                {isGeneratingPDF ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>જનરેટ થઈ રહી છે...</span>
                  </>
                ) : (
                  <>
                    <Printer className="w-4 h-4 text-turmeric-gold" />
                    <span>ઓનલાઈન રસીદ (PDF)</span>
                  </>
                )}
              </button>

              {/* Status Track Button */}
              <button
                id="btn-goto-track-screen"
                type="button"
                onClick={() => onNavigateTrack(lastSubmittedId)}
                className="w-full py-3.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm shadow-xs transition-all flex items-center justify-center gap-2 min-h-[46px]"
              >
                <Search className="w-4 h-4 text-emerald-400" />
                <span>અરજીની સ્થિતિ જુઓ</span>
              </button>

              {/* WhatsApp Share Button */}
              <button
                id="btn-share-on-whatsapp"
                type="button"
                onClick={handleWhatsAppShare}
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-2xs transition-all flex items-center justify-center gap-2 min-h-[44px]"
              >
                <MessageSquare className="w-4 h-4" />
                <span>વોટ્સએપ પર મોકલો</span>
              </button>

              {/* New Form Button */}
              <button
                id="btn-start-new-form"
                type="button"
                onClick={handleResetForm}
                className="w-full py-3 px-4 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 font-bold text-xs shadow-2xs transition-all flex items-center justify-center gap-2 min-h-[44px]"
              >
                <PlusCircle className="w-4 h-4 text-deep-indigo" />
                <span>બીજી નવી અરજી કરો</span>
              </button>

            </div>

          </div>
        ) : (
          /* PRIMARY FORM CARD */
          <form
            id="customer-request-form"
            onSubmit={handleSubmit}
            noValidate
            className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-8 shadow-xs space-y-6"
          >
            
            {/* Error Banner if any */}
            {errorMessage && (
              <div className="p-3.5 sm:p-4 bg-red-50 border border-red-200 rounded-xl text-xs sm:text-sm text-red-700 flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-red-900 block">ધ્યાન આપો:</span>
                  <span>{errorMessage}</span>
                </div>
              </div>
            )}

            {/* ========================================================================= */}
            {/* SECTION 1: વ્યક્તિગત માહિતી (Personal Details) */}
            {/* ========================================================================= */}
            <div className="space-y-4">
              <div className="border-b border-slate-100 pb-2">
                <h2 className="text-sm sm:text-base font-bold text-slate-900 flex items-center gap-2">
                  <User className="w-4 h-4 text-deep-indigo" />
                  <span>વ્યક્તિગત માહિતી (Personal Details)</span>
                </h2>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Full Name */}
                <div>
                  <label htmlFor="input-fullname" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    અરજદારનું પૂરું નામ <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      id="input-fullname"
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="દા.ત. રમેશભાઈ કાંતિભાઈ પટેલ"
                      className={`w-full px-3.5 py-3 rounded-xl border text-sm text-slate-900 bg-white placeholder-slate-400 focus:outline-hidden focus:ring-2 transition-all min-h-[46px] ${
                        validationErrors.fullName
                          ? 'border-red-400 focus:ring-red-200 bg-red-50/20'
                          : 'border-slate-300 focus:border-deep-indigo focus:ring-deep-indigo/10'
                      }`}
                    />
                    <User className="w-4 h-4 text-slate-400 absolute right-3.5 top-3.5 pointer-events-none" />
                  </div>
                  {validationErrors.fullName && (
                    <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{validationErrors.fullName}</span>
                    </p>
                  )}
                </div>

                {/* Mobile Number */}
                <div>
                  <label htmlFor="input-mobile" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    મોબાઈલ નંબર (૧૦ આંકડા) <span className="text-red-500">*</span>
                  </label>
                  <div className="relative flex">
                    <span className="inline-flex items-center px-3 rounded-l-xl border border-r-0 border-slate-300 bg-slate-100 text-slate-600 text-xs font-bold select-none">
                      +91
                    </span>
                    <input
                      id="input-mobile"
                      type="tel"
                      maxLength={10}
                      value={mobileNumber}
                      onChange={(e) => setMobileNumber(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="૯૮૭૬૫ ૪૩૨૧૦"
                      className={`w-full px-3.5 py-3 rounded-r-xl border text-sm font-mono text-slate-900 bg-white placeholder-slate-400 focus:outline-hidden focus:ring-2 transition-all min-h-[46px] ${
                        validationErrors.mobileNumber
                          ? 'border-red-400 focus:ring-red-200 bg-red-50/20'
                          : 'border-slate-300 focus:border-deep-indigo focus:ring-deep-indigo/10'
                      }`}
                    />
                  </div>
                  {validationErrors.mobileNumber && (
                    <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{validationErrors.mobileNumber}</span>
                    </p>
                  )}
                </div>

              </div>
            </div>

            {/* ========================================================================= */}
            {/* SECTION 2: સંપર્ક / સરનામાની વિગત (Address Details) */}
            {/* ========================================================================= */}
            <div className="space-y-4 pt-2">
              <div className="border-b border-slate-100 pb-2">
                <h2 className="text-sm sm:text-base font-bold text-slate-900 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-deep-indigo" />
                  <span>સરનામાની વિગત (Address Details)</span>
                </h2>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                
                {/* District Dropdown: જિલ્લો ▼ */}
                <div>
                  <label htmlFor="select-district" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    જિલ્લો <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <select
                      id="select-district"
                      value={district}
                      onChange={(e) => {
                        const newDist = e.target.value;
                        setDistrict(newDist);
                        setTaluka(''); // Reset taluka whenever district changes
                      }}
                      className={`w-full pl-3.5 pr-8 py-3 rounded-xl border text-sm text-slate-900 bg-white focus:outline-hidden focus:ring-2 transition-all appearance-none min-h-[46px] cursor-pointer ${
                        validationErrors.district
                          ? 'border-red-400 focus:ring-red-200 bg-red-50/20'
                          : 'border-slate-300 focus:border-deep-indigo focus:ring-deep-indigo/10'
                      }`}
                    >
                      <option value="">-- જિલ્લો પસંદ કરો --</option>
                      {GUJARAT_DISTRICTS.map((dist, idx) => (
                        <option key={idx} value={dist.name}>
                          {dist.name} ({dist.englishName})
                        </option>
                      ))}
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-slate-500">
                      <span className="text-xs">▼</span>
                    </div>
                  </div>
                  {validationErrors.district && (
                    <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{validationErrors.district}</span>
                    </p>
                  )}
                </div>

                {/* Taluka Dropdown: તાલુકો ▼ (Dependent on District) */}
                <div>
                  <label htmlFor="select-taluka" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    તાલુકો <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <select
                      id="select-taluka"
                      value={taluka}
                      disabled={!district}
                      onChange={(e) => setTaluka(e.target.value)}
                      className={`w-full pl-3.5 pr-8 py-3 rounded-xl border text-sm text-slate-900 bg-white focus:outline-hidden focus:ring-2 transition-all appearance-none min-h-[46px] cursor-pointer disabled:bg-slate-100 disabled:text-slate-400 disabled:cursor-not-allowed ${
                        validationErrors.taluka
                          ? 'border-red-400 focus:ring-red-200 bg-red-50/20'
                          : 'border-slate-300 focus:border-deep-indigo focus:ring-deep-indigo/10'
                      }`}
                    >
                      <option value="">
                        {district ? '-- તાલુકો પસંદ કરો --' : '-- પહેલાં જિલ્લો પસંદ કરો --'}
                      </option>
                      {currentTalukaList.map((tName, idx) => (
                        <option key={idx} value={tName}>
                          {tName}
                        </option>
                      ))}
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-slate-500">
                      <span className="text-xs">▼</span>
                    </div>
                  </div>
                  {validationErrors.taluka && (
                    <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{validationErrors.taluka}</span>
                    </p>
                  )}
                </div>

                {/* Village / City */}
                <div>
                  <label htmlFor="input-village" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    ગામ / શહેર <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      id="input-village"
                      type="text"
                      value={village}
                      onChange={(e) => setVillage(e.target.value)}
                      placeholder="ગામ અથવા શહેરનું નામ"
                      className={`w-full px-3.5 py-3 rounded-xl border text-sm text-slate-900 bg-white placeholder-slate-400 focus:outline-hidden focus:ring-2 transition-all min-h-[46px] ${
                        validationErrors.village
                          ? 'border-red-400 focus:ring-red-200 bg-red-50/20'
                          : 'border-slate-300 focus:border-deep-indigo focus:ring-deep-indigo/10'
                      }`}
                    />
                    <Home className="w-4 h-4 text-slate-400 absolute right-3 top-3.5 pointer-events-none" />
                  </div>
                  {validationErrors.village && (
                    <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{validationErrors.village}</span>
                    </p>
                  )}
                </div>

              </div>
            </div>

            {/* ========================================================================= */}
            {/* SECTION 3: સેવાની માહિતી (Service Information) */}
            {/* ========================================================================= */}
            <div className="space-y-4 pt-2">
              <div className="border-b border-slate-100 pb-2">
                <h2 className="text-sm sm:text-base font-bold text-slate-900 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-deep-indigo" />
                  <span>સેવાની માહિતી (Category & Service Selection)</span>
                </h2>
              </div>

              {/* 1. Category Selection Dropdown */}
              <div>
                <label htmlFor="select-category" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  ૧. કેટેગરી પસંદ કરો (Select Category) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <select
                    id="select-category"
                    value={selectedCategory}
                    onChange={(e) => {
                      const newCatName = e.target.value;
                      setSelectedCategory(newCatName);
                      const catObj = CATEGORY_OPTIONS.find(c => c.name === newCatName);
                      if (catObj && catObj.services.length > 0) {
                        setSelectedService(catObj.services[0]);
                      }
                    }}
                    className="w-full pl-3.5 pr-8 py-3 rounded-xl border border-slate-300 text-sm font-semibold text-slate-900 bg-white focus:outline-hidden focus:ring-2 focus:ring-deep-indigo/10 focus:border-deep-indigo transition-all appearance-none min-h-[46px] cursor-pointer"
                  >
                    {CATEGORY_OPTIONS.map((cat) => (
                      <option key={cat.id} value={cat.name}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-slate-500">
                    <span className="text-xs">▼</span>
                  </div>
                </div>
                {validationErrors.selectedCategory && (
                  <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{validationErrors.selectedCategory}</span>
                  </p>
                )}
              </div>

              {/* 2. Service Selection Dropdown */}
              <div>
                <label htmlFor="select-service" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  ૨. ચોક્કસ સેવા પસંદ કરો (Select Specific Service) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <select
                    id="select-service"
                    value={selectedService}
                    onChange={(e) => setSelectedService(e.target.value)}
                    className="w-full pl-3.5 pr-8 py-3 rounded-xl border border-slate-300 text-sm text-slate-900 bg-white focus:outline-hidden focus:ring-2 focus:ring-deep-indigo/10 focus:border-deep-indigo transition-all appearance-none min-h-[46px] cursor-pointer"
                  >
                    {activeServicesList.map((srv, idx) => (
                      <option key={idx} value={srv}>
                        {srv}
                      </option>
                    ))}
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-slate-500">
                    <span className="text-xs">▼</span>
                  </div>
                </div>
              </div>

              {/* If "અન્ય" is selected in Category or Service, show custom service name input */}
              {(selectedCategory.includes('અન્ય') || selectedService.includes('અન્ય')) && (
                <div className="animate-fadeIn">
                  <label htmlFor="input-custom-service" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    સેવાનું નામ સ્પષ્ટ લખો <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="input-custom-service"
                    type="text"
                    value={customService}
                    onChange={(e) => setCustomService(e.target.value)}
                    placeholder="દા.ત. નવો પાસપોર્ટ, ડ્રાઇવિંગ લાયસન્સ, સ્ટેમ્પ ડ્યુટી"
                    className={`w-full px-3.5 py-3 rounded-xl border text-sm text-slate-900 bg-white placeholder-slate-400 focus:outline-hidden focus:ring-2 transition-all min-h-[46px] ${
                      validationErrors.customService
                        ? 'border-red-400 focus:ring-red-200 bg-red-50/20'
                        : 'border-slate-300 focus:border-deep-indigo focus:ring-deep-indigo/10'
                    }`}
                  />
                  {validationErrors.customService && (
                    <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{validationErrors.customService}</span>
                    </p>
                  )}
                </div>
              )}
            </div>

            {/* ========================================================================= */}
            {/* SECTION 4: વધારાની માહિતી (Additional Message / Notes) */}
            {/* ========================================================================= */}
            <div className="space-y-4 pt-2">
              <div className="border-b border-slate-100 pb-2">
                <h2 className="text-sm sm:text-base font-bold text-slate-900 flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-deep-indigo" />
                  <span>વધારાની માહિતી (Additional Message - Optional)</span>
                </h2>
              </div>

              <div>
                <label htmlFor="textarea-message" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  સંદેશો અથવા ખાસ વિગત (વૈકલ્પિક)
                </label>
                <div className="relative">
                  <textarea
                    id="textarea-message"
                    rows={3}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="ફોર્મ સંબંધિત કોઈ ખાસ સૂચના અથવા પ્રશ્ન હોય તો અહીં લખો..."
                    className="w-full px-3.5 py-3 rounded-xl border border-slate-300 text-sm text-slate-900 bg-white placeholder-slate-400 focus:border-deep-indigo focus:ring-2 focus:ring-deep-indigo/10 focus:outline-hidden transition-all resize-y min-h-[80px]"
                  />
                  <MessageSquare className="w-4 h-4 text-slate-400 absolute right-3.5 top-3.5 pointer-events-none" />
                </div>
              </div>
            </div>

            {/* ========================================================================= */}
            {/* DECLARATION CHECKBOX */}
            {/* ========================================================================= */}
            <div className="pt-1">
              <label className="flex items-start gap-2.5 cursor-pointer select-none">
                <input
                  id="checkbox-agreement"
                  type="checkbox"
                  checked={agreedToTerms}
                  onChange={(e) => setAgreedToTerms(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-300 text-deep-indigo focus:ring-deep-indigo mt-0.5 cursor-pointer"
                />
                <span className="text-xs text-slate-600 leading-relaxed">
                  હું ખાતરી આપું છું કે ઉપર દર્શાવેલ વિગતો સાચી છે અને હું સ્ટાર કિંગ નેટવર્ક દ્વારા સંપર્ક કરવા માટે સંમત છું.
                </span>
              </label>
            </div>

            {/* ========================================================================= */}
            {/* PRIMARY SUBMIT BUTTON */}
            {/* ========================================================================= */}
            <div className="pt-2">
              <button
                id="btn-submit-form"
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 px-6 rounded-xl bg-deep-indigo hover:bg-deep-indigo/90 disabled:opacity-50 text-white font-bold text-sm sm:text-base shadow-sm hover:shadow-md transition-all flex items-center justify-center gap-2 min-h-[48px] cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>માહિતી સબમિટ થઈ રહી છે...</span>
                  </>
                ) : (
                  <>
                    <span>માહિતી મોકલો</span>
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>
            </div>

          </form>
        )}

      </div>

    </div>
  );
};

export default Form;
