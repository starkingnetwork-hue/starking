import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Copy, 
  Check, 
  Download, 
  Search, 
  Share2, 
  PlusCircle, 
  Home, 
  ShieldCheck, 
  MessageSquare,
  Loader2,
  Calendar,
  User,
  Phone,
  Printer
} from 'lucide-react';

interface StepSuccessProps {
  applicationId: string;
  details: {
    fullName: string;
    mobileNumber: string;
    village: string;
    taluka: string;
    district: string;
    category: string;
    message: string;
    dateTime: string;
  } | null;
  onDownloadPDF: () => void;
  isGeneratingPDF: boolean;
  onNavigateTrack: (appId?: string) => void;
  onNavigateHome: () => void;
  onResetNewForm: () => void;
  onWhatsAppShare: () => void;
}

export const StepSuccess: React.FC<StepSuccessProps> = ({
  applicationId,
  details,
  onDownloadPDF,
  isGeneratingPDF,
  onNavigateTrack,
  onNavigateHome,
  onResetNewForm,
  onWhatsAppShare
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopyId = () => {
    if (!applicationId) return;
    navigator.clipboard.writeText(applicationId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="step-success-screen" className="max-w-2xl mx-auto space-y-6 animate-fadeIn">
      
      {/* Primary Success Visual Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-10 text-center shadow-md relative overflow-hidden">
        
        {/* Top Decorative bar */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600" />

        {/* Big Success Icon */}
        <div className="w-20 h-20 rounded-3xl bg-emerald-50 border-2 border-emerald-200 flex items-center justify-center text-emerald-600 mx-auto shadow-inner mb-5">
          <CheckCircle2 className="w-12 h-12 stroke-[2.5]" />
        </div>

        {/* Heading */}
        <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
          અરજી સફળતાપૂર્વક સબમિટ થઈ!
        </h2>
        <p className="text-slate-600 text-sm sm:text-base mt-2 max-w-lg mx-auto">
          તમારી ઓનલાઇન વિનંતી સફળતાપૂર્વક નોંધાઈ ગઈ છે. અમારી ટીમ દ્વારા દસ્તાવેજ ચકાસણીની પ્રક્રિયા શરૂ કરવામાં આવી છે.
        </p>

        {/* Application ID Pill Box */}
        <div className="mt-6 p-4 sm:p-5 bg-slate-50 rounded-2xl border border-slate-200 max-w-md mx-auto">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
            તમારો અરજી ક્રમાંક (Application ID):
          </div>

          <div className="flex items-center justify-center gap-2">
            <span className="text-2xl sm:text-3xl font-black font-mono text-deep-indigo tracking-wider">
              #{applicationId || 'SKN100001'}
            </span>

            <button
              id="btn-copy-success-id"
              onClick={handleCopyId}
              type="button"
              className="p-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 transition-colors shadow-2xs min-w-[40px] min-h-[40px] flex items-center justify-center"
              title="કોપી કરો"
            >
              {copied ? (
                <Check className="w-5 h-5 text-emerald-600" />
              ) : (
                <Copy className="w-5 h-5 text-slate-600" />
              )}
            </button>
          </div>

          <p className="text-[11px] text-amber-800 font-semibold mt-2 flex items-center justify-center gap-1">
            <span>⚠️ આ Application ID ભવિષ્યમાં સ્ટેટસ ચેક કરવા સાચવી રાખો.</span>
          </p>
        </div>

        {/* Quick Details Snapshot */}
        {details && (
          <div className="mt-6 pt-5 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs text-left">
            <div className="bg-slate-50/70 p-3 rounded-xl border border-slate-100">
              <span className="text-slate-400 font-bold block mb-0.5">અરજદારનું નામ:</span>
              <span className="font-bold text-slate-900">{details.fullName}</span>
            </div>
            <div className="bg-slate-50/70 p-3 rounded-xl border border-slate-100">
              <span className="text-slate-400 font-bold block mb-0.5">મોબાઈલ નંબર:</span>
              <span className="font-bold text-slate-900 font-mono">+91 {details.mobileNumber}</span>
            </div>
            <div className="bg-slate-50/70 p-3 rounded-xl border border-slate-100 sm:col-span-2">
              <span className="text-slate-400 font-bold block mb-0.5">સેવા / કેટેગરી:</span>
              <span className="font-bold text-slate-900">{details.category}</span>
            </div>
          </div>
        )}

      </div>

      {/* Main Action Buttons Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        
        {/* PDF Download Receipt */}
        <button
          id="btn-download-pdf-success"
          type="button"
          onClick={onDownloadPDF}
          disabled={isGeneratingPDF}
          className="w-full py-4 px-5 rounded-2xl bg-deep-indigo hover:bg-deep-indigo/90 text-white font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 min-h-[52px]"
        >
          {isGeneratingPDF ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>રસીદ જનરેટ થઈ રહી છે...</span>
            </>
          ) : (
            <>
              <Printer className="w-5 h-5 text-turmeric-gold" />
              <span>ઓનલાઈન રસીદ (PDF) ડાઉનલોડ કરો</span>
            </>
          )}
        </button>

        {/* Track Status Direct Jump */}
        <button
          id="btn-track-status-success"
          type="button"
          onClick={() => onNavigateTrack(applicationId)}
          className="w-full py-4 px-5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 min-h-[52px]"
        >
          <Search className="w-5 h-5 text-emerald-400" />
          <span>અરજીની સ્થિતિ (Status) જુઓ</span>
        </button>

        {/* WhatsApp Share */}
        <button
          id="btn-whatsapp-share-success"
          type="button"
          onClick={onWhatsAppShare}
          className="w-full py-3.5 px-5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-xs transition-all flex items-center justify-center gap-2 min-h-[48px]"
        >
          <MessageSquare className="w-5 h-5" />
          <span>વોટ્સએપ હેલ્પલાઈન પર વિગત મોકલો</span>
        </button>

        {/* Reset / New Form */}
        <button
          id="btn-reset-new-form"
          type="button"
          onClick={onResetNewForm}
          className="w-full py-3.5 px-5 rounded-2xl bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 font-bold text-sm shadow-2xs transition-all flex items-center justify-center gap-2 min-h-[48px]"
        >
          <PlusCircle className="w-5 h-5 text-deep-indigo" />
          <span>બીજી નવી અરજી કરો</span>
        </button>

      </div>

    </div>
  );
};
