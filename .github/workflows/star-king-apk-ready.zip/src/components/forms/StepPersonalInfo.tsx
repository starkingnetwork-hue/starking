import React from 'react';
import { ActiveFormItem } from '../../types';
import { GUJARAT_DISTRICTS } from '../../utils/formsData';
import { 
  User, 
  Phone, 
  MapPin, 
  Home, 
  Building, 
  MessageSquare, 
  Layers, 
  AlertCircle, 
  CheckCircle2, 
  HelpCircle,
  Tag
} from 'lucide-react';

interface StepPersonalInfoProps {
  selectedForm: ActiveFormItem | null;
  fullName: string;
  setFullName: (val: string) => void;
  mobileNumber: string;
  setMobileNumber: (val: string) => void;
  village: string;
  setVillage: (val: string) => void;
  taluka: string;
  setTaluka: (val: string) => void;
  district: string;
  setDistrict: (val: string) => void;
  category: string;
  setCategory: (val: string) => void;
  message: string;
  setMessage: (val: string) => void;
  errors: Record<string, string>;
  onChangeService: () => void;
}

export const StepPersonalInfo: React.FC<StepPersonalInfoProps> = ({
  selectedForm,
  fullName,
  setFullName,
  mobileNumber,
  setMobileNumber,
  village,
  setVillage,
  taluka,
  setTaluka,
  district,
  setDistrict,
  category,
  setCategory,
  message,
  setMessage,
  errors,
  onChangeService
}) => {
  return (
    <div id="step-personal-info" className="space-y-6">
      
      {/* Active Selected Service Highlight Card */}
      <div className="bg-slate-900 text-white rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-white/10 text-turmeric-gold flex items-center justify-center shrink-0 border border-white/10">
            <Tag className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-bold text-turmeric-gold uppercase tracking-wider block">
              પસંદ કરેલ સેવા / ફોર્મ:
            </span>
            <h3 className="text-base sm:text-lg font-bold text-white leading-tight">
              {selectedForm ? selectedForm.title : category || 'સામાન્ય ઓનલાઇન સેવા'}
            </h3>
            {selectedForm && (
              <span className="text-xs text-slate-300 font-medium mt-0.5 inline-block">
                {selectedForm.categoryBadge} • છેલ્લી તારીખ: {selectedForm.deadline}
              </span>
            )}
          </div>
        </div>

        <button
          id="btn-change-service"
          type="button"
          onClick={onChangeService}
          className="self-end sm:self-center px-3.5 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-white text-xs font-bold transition-colors border border-white/20 shrink-0 min-h-[38px]"
        >
          સેવા બદલો
        </button>
      </div>

      {/* Form Fields Section */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-7 shadow-xs space-y-5">
        
        <div className="border-b border-slate-100 pb-3">
          <h4 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <User className="w-4 h-4 text-deep-indigo" />
            <span>અરજદારની પ્રાથમિક વિગતો</span>
          </h4>
          <p className="text-xs text-slate-500 mt-0.5">
            કૃપા કરીને તમારા આધાર કાર્ડ મુજબ સાચી માહિતી દાખલ કરો.
          </p>
        </div>

        {/* Name & Mobile Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5">
          
          {/* Full Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              અરજદારનું પૂરું નામ <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                id="input-fullname"
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="દા.ત. રમેશભાઈ કાંતિભાઈ પટેલ"
                className={`w-full px-4 py-3 rounded-xl border text-sm text-slate-900 bg-white placeholder-slate-400 focus:outline-hidden focus:ring-2 transition-all min-h-[46px] ${
                  errors.fullName
                    ? 'border-red-400 focus:ring-red-200 bg-red-50/20'
                    : 'border-slate-300 focus:border-deep-indigo focus:ring-deep-indigo/10'
                }`}
              />
              <User className="w-4 h-4 text-slate-400 absolute right-3.5 top-3.5 pointer-events-none" />
            </div>
            {errors.fullName && (
              <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{errors.fullName}</span>
              </p>
            )}
          </div>

          {/* Mobile Number */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              મોબાઈલ નંબર (૧૦ આંકડા) <span className="text-red-500">*</span>
            </label>
            <div className="relative flex">
              <span className="inline-flex items-center px-3.5 rounded-l-xl border border-r-0 border-slate-300 bg-slate-100 text-slate-600 text-xs font-bold select-none">
                +91
              </span>
              <input
                id="input-mobile"
                type="tel"
                maxLength={10}
                value={mobileNumber}
                onChange={(e) => setMobileNumber(e.target.value.replace(/[^0-9]/g, ''))}
                placeholder="૯૮૭૬૫ ૪૩૨૧૦"
                className={`w-full px-4 py-3 rounded-r-xl border text-sm font-mono text-slate-900 bg-white placeholder-slate-400 focus:outline-hidden focus:ring-2 transition-all min-h-[46px] ${
                  errors.mobileNumber
                    ? 'border-red-400 focus:ring-red-200 bg-red-50/20'
                    : 'border-slate-300 focus:border-deep-indigo focus:ring-deep-indigo/10'
                }`}
              />
            </div>
            {errors.mobileNumber && (
              <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{errors.mobileNumber}</span>
              </p>
            )}
            <p className="text-[11px] text-slate-500 mt-1">
              આ નંબર પર સ્ટેટસ અપડેટ અને ઓનલાઇન રસીદ મોકલવામાં આવશે.
            </p>
          </div>

        </div>

        {/* Address & Location Section */}
        <div className="border-t border-slate-100 pt-4">
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2.5">
            સરનામાની વિગત (Location Details) <span className="text-red-500">*</span>
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            
            {/* District Dropdown */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                જિલ્લો (District)
              </label>
              <div className="relative">
                <select
                  id="select-district"
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className={`w-full px-3.5 py-3 rounded-xl border text-sm text-slate-900 bg-white focus:outline-hidden focus:ring-2 transition-all appearance-none min-h-[46px] ${
                    errors.district
                      ? 'border-red-400 focus:ring-red-200 bg-red-50/20'
                      : 'border-slate-300 focus:border-deep-indigo focus:ring-deep-indigo/10'
                  }`}
                >
                  <option value="">-- જિલ્લો પસંદ કરો --</option>
                  {GUJARAT_DISTRICTS.map((dist, idx) => (
                    <option key={idx} value={dist.split(' (')[0]}>
                      {dist}
                    </option>
                  ))}
                </select>
                <MapPin className="w-4 h-4 text-slate-400 absolute right-3 top-3.5 pointer-events-none" />
              </div>
              {errors.district && (
                <p className="text-xs text-red-600 mt-1">{errors.district}</p>
              )}
            </div>

            {/* Taluka */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                તાલુકો (Taluka)
              </label>
              <div className="relative">
                <input
                  id="input-taluka"
                  type="text"
                  value={taluka}
                  onChange={(e) => setTaluka(e.target.value)}
                  placeholder="તાલુકાનું નામ"
                  className={`w-full px-3.5 py-3 rounded-xl border text-sm text-slate-900 bg-white placeholder-slate-400 focus:outline-hidden focus:ring-2 transition-all min-h-[46px] ${
                    errors.taluka
                      ? 'border-red-400 focus:ring-red-200 bg-red-50/20'
                      : 'border-slate-300 focus:border-deep-indigo focus:ring-deep-indigo/10'
                  }`}
                />
                <Building className="w-4 h-4 text-slate-400 absolute right-3 top-3.5 pointer-events-none" />
              </div>
              {errors.taluka && (
                <p className="text-xs text-red-600 mt-1">{errors.taluka}</p>
              )}
            </div>

            {/* Village */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                ગામ / શહેર (Village / City)
              </label>
              <div className="relative">
                <input
                  id="input-village"
                  type="text"
                  value={village}
                  onChange={(e) => setVillage(e.target.value)}
                  placeholder="ગામનું નામ"
                  className={`w-full px-3.5 py-3 rounded-xl border text-sm text-slate-900 bg-white placeholder-slate-400 focus:outline-hidden focus:ring-2 transition-all min-h-[46px] ${
                    errors.village
                      ? 'border-red-400 focus:ring-red-200 bg-red-50/20'
                      : 'border-slate-300 focus:border-deep-indigo focus:ring-deep-indigo/10'
                  }`}
                />
                <Home className="w-4 h-4 text-slate-400 absolute right-3 top-3.5 pointer-events-none" />
              </div>
              {errors.village && (
                <p className="text-xs text-red-600 mt-1">{errors.village}</p>
              )}
            </div>

          </div>
        </div>

        {/* Additional Message / Notes */}
        <div className="border-t border-slate-100 pt-4">
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center justify-between">
            <span>વધારાની નોંધ અથવા સંદેશો (વૈકલ્પિક - Optional)</span>
            <span className="text-slate-400 font-normal text-[11px]">મહત્તમ ૫૦૦ અક્ષર</span>
          </label>
          <div className="relative">
            <textarea
              id="input-message"
              rows={3}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="ફોર્મ સંબંધિત કોઈ ખાસ સૂચના કે વિગત લખવી હોય તો અહીં લખો..."
              className="w-full px-4 py-3 rounded-xl border border-slate-300 text-sm text-slate-900 bg-white placeholder-slate-400 focus:border-deep-indigo focus:ring-2 focus:ring-deep-indigo/10 focus:outline-hidden transition-all resize-y min-h-[80px]"
            />
            <MessageSquare className="w-4 h-4 text-slate-400 absolute right-3.5 top-3.5 pointer-events-none" />
          </div>
        </div>

      </div>

    </div>
  );
};
