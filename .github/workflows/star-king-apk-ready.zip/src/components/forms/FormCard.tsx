import React from 'react';
import { ActiveFormItem } from '../../types';
import { Calendar, FileCheck, ArrowRight, Info, AlertTriangle, CheckCircle2, Clock } from 'lucide-react';

interface FormCardProps {
  form: ActiveFormItem;
  onSelect: (form: ActiveFormItem) => void;
  onViewDetails: (form: ActiveFormItem) => void;
}

export const FormCard: React.FC<FormCardProps> = ({ form, onSelect, onViewDetails }) => {
  const isClosingSoon = form.status === 'closing_soon' || (form.daysLeft !== undefined && form.daysLeft <= 5);
  const isUpcoming = form.status === 'upcoming';

  return (
    <div 
      id={`form-card-${form.id}`}
      className={`group bg-white rounded-xl border transition-all duration-200 hover:shadow-md flex flex-col justify-between p-5 relative overflow-hidden ${
        isClosingSoon 
          ? 'border-amber-400/60 shadow-xs' 
          : 'border-slate-200/90 hover:border-deep-indigo/30'
      }`}
    >
      {/* Top Accent Line for Closing Soon */}
      {isClosingSoon && (
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 to-amber-600" />
      )}

      <div>
        {/* Badges Row */}
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold tracking-tight bg-slate-100 text-slate-700 border border-slate-200">
            {form.categoryBadge}
          </span>

          {/* Status Badge */}
          {isClosingSoon ? (
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-300">
              <AlertTriangle className="w-3 h-3 text-amber-600" />
              <span>{form.statusText}</span>
            </span>
          ) : isUpcoming ? (
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
              <Clock className="w-3 h-3 text-blue-600" />
              <span>{form.statusText}</span>
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              <span>{form.statusText}</span>
            </span>
          )}
        </div>

        {/* Title & English Subtitle */}
        <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-snug group-hover:text-deep-indigo transition-colors line-clamp-2">
          {form.title}
        </h3>
        {form.englishTitle && (
          <p className="text-xs text-slate-500 mt-1 line-clamp-1">
            {form.englishTitle}
          </p>
        )}

        {/* Department */}
        <p className="text-xs text-slate-600 mt-2 font-medium flex items-center gap-1">
          <span className="text-slate-400">વિભાગ:</span>
          <span className="truncate">{form.department}</span>
        </p>

        {/* Meta Info Grid (Deadline & Required Docs) */}
        <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs">
          <div className="bg-slate-50 rounded-lg p-2.5 border border-slate-100 flex flex-col justify-center">
            <span className="text-slate-500 font-medium flex items-center gap-1 mb-0.5">
              <Calendar className="w-3 h-3 text-slate-400" />
              છેલ્લી તારીખ:
            </span>
            <span className={`font-bold truncate ${isClosingSoon ? 'text-amber-700 font-bold' : 'text-slate-800'}`}>
              {form.deadline}
            </span>
          </div>

          <div className="bg-slate-50 rounded-lg p-2.5 border border-slate-100 flex flex-col justify-center">
            <span className="text-slate-500 font-medium flex items-center gap-1 mb-0.5">
              <FileCheck className="w-3 h-3 text-slate-400" />
              દસ્તાવેજો:
            </span>
            <span className="font-bold text-slate-800">
              {form.documents.length} દસ્તાવેજ જરૂરી
            </span>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-5 pt-3 border-t border-slate-100 flex items-center gap-2">
        <button
          id={`btn-details-${form.id}`}
          onClick={() => onViewDetails(form)}
          type="button"
          className="flex-1 py-2.5 px-3 rounded-lg text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 transition-colors flex items-center justify-center gap-1 min-h-[44px]"
        >
          <Info className="w-3.5 h-3.5" />
          <span>વિગતો જુઓ</span>
        </button>

        <button
          id={`btn-apply-${form.id}`}
          onClick={() => onSelect(form)}
          type="button"
          className="flex-1 py-2.5 px-3 rounded-lg text-xs font-bold text-white bg-deep-indigo hover:bg-deep-indigo/90 shadow-xs hover:shadow transition-all flex items-center justify-center gap-1.5 min-h-[44px]"
        >
          <span>ફોર્મ ભરો</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
