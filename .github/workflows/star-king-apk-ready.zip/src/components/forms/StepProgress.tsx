import React from 'react';
import { Check, User, FileText, CheckCircle2, Award } from 'lucide-react';

interface StepProgressProps {
  currentStep: number;
  totalSteps?: number;
  onStepClick?: (step: number) => void;
}

const STEPS = [
  { step: 1, label: 'માહિતી', subLabel: 'વ્યક્તિગત વિગત', icon: User },
  { step: 2, label: 'ચકાસણી', subLabel: 'વિગત રીવ્યુ', icon: CheckCircle2 },
  { step: 3, label: 'સફળતા', subLabel: 'અરજી ક્રમાંક', icon: Award }
];

export const StepProgress: React.FC<StepProgressProps> = ({ currentStep, totalSteps = 3, onStepClick }) => {
  const percentage = ((currentStep - 1) / (totalSteps - 1)) * 100;

  return (
    <div id="step-progress-container" className="w-full bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs">
      
      {/* Mobile compact header */}
      <div className="flex sm:hidden items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-deep-indigo text-white">
            Step {currentStep} of {totalSteps}
          </span>
          <span className="text-sm font-bold text-slate-800">
            {STEPS[currentStep - 1]?.label} ({STEPS[currentStep - 1]?.subLabel})
          </span>
        </div>
        <span className="text-xs font-bold text-slate-500 font-mono">
          {Math.round(percentage)}%
        </span>
      </div>

      {/* Mobile progress bar */}
      <div className="sm:hidden w-full bg-slate-100 h-2 rounded-full overflow-hidden">
        <div 
          className="bg-deep-indigo h-full transition-all duration-300 rounded-full"
          style={{ width: `${Math.max(10, percentage)}%` }}
        />
      </div>

      {/* Desktop Step Indicator */}
      <div className="hidden sm:block">
        <div className="relative flex items-center justify-between">
          
          {/* Progress connecting line */}
          <div className="absolute left-6 right-6 top-5 -translate-y-1/2 h-1 bg-slate-200 z-0">
            <div 
              className="h-full bg-deep-indigo transition-all duration-300"
              style={{ width: `${percentage}%` }}
            />
          </div>

          {/* Steps */}
          {STEPS.map((s) => {
            const isCompleted = currentStep > s.step;
            const isCurrent = currentStep === s.step;
            const StepIcon = s.icon;
            const isClickable = onStepClick && currentStep > s.step && currentStep < totalSteps;

            return (
              <div 
                key={s.step} 
                className="relative z-10 flex flex-col items-center group"
                onClick={() => isClickable && onStepClick(s.step)}
              >
                <div 
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all duration-200 ${
                    isCompleted
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : isCurrent
                      ? 'bg-deep-indigo text-white ring-4 ring-deep-indigo/20 shadow-xs'
                      : 'bg-white border-2 border-slate-300 text-slate-400'
                  } ${isClickable ? 'cursor-pointer hover:scale-105' : ''}`}
                >
                  {isCompleted ? (
                    <Check className="w-5 h-5 stroke-[2.5]" />
                  ) : (
                    <span>0{s.step}</span>
                  )}
                </div>

                <div className="text-center mt-2">
                  <div className={`text-xs font-bold ${
                    isCurrent ? 'text-deep-indigo' : isCompleted ? 'text-slate-800' : 'text-slate-400'
                  }`}>
                    {s.label}
                  </div>
                  <div className="text-[11px] text-slate-500 hidden md:block">
                    {s.subLabel}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
