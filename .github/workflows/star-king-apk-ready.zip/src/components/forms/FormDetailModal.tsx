import React from 'react';
import { ActiveFormItem } from '../../types';
import { 
  X, 
  Calendar, 
  Building2, 
  CheckCircle2, 
  ArrowRight, 
  FileCheck2, 
  ShieldCheck, 
  Clock, 
  AlertTriangle,
  UserCheck,
  FileText
} from 'lucide-react';

interface FormDetailModalProps {
  form: ActiveFormItem | null;
  isOpen: boolean;
  onClose: () => void;
  onStartFilling: (form: ActiveFormItem) => void;
}

export const FormDetailModal: React.FC<FormDetailModalProps> = ({
  form,
  isOpen,
  onClose,
  onStartFilling
}) => {
  if (!isOpen || !form) return null;

  const isClosingSoon = form.status === 'closing_soon' || (form.daysLeft !== undefined && form.daysLeft <= 5);

  return (
    <div 
      id="form-detail-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-slate-900/60 backdrop-blur-xs animate-fadeIn"
      onClick={onClose}
    >
      <div 
        className="bg-white w-full max-w-2xl rounded-2xl shadow-xl border border-slate-200 overflow-hidden my-8 max-h-[90vh] flex flex-col relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-5 sm:p-6 flex items-start justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-white/20 text-white">
                {form.categoryBadge}
              </span>
              {isClosingSoon ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500 text-white">
                  <AlertTriangle className="w-3 h-3" />
                  <span>{form.statusText}</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500 text-white">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>{form.statusText}</span>
                </span>
              )}
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-white leading-snug">
              {form.title}
            </h2>
            {form.englishTitle && (
              <p className="text-xs text-slate-300 mt-0.5">{form.englishTitle}</p>
            )}
          </div>

          <button
            id="btn-close-modal"
            onClick={onClose}
            type="button"
            className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white transition-colors shrink-0 min-w-[40px] min-h-[40px] flex items-center justify-center"
            aria-label="Close details"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1 text-slate-800 text-sm">
          
          {/* Key Facts Summary */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80 flex items-start gap-3">
              <Building2 className="w-5 h-5 text-deep-indigo shrink-0 mt-0.5" />
              <div>
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">સત્તાવાર વિભાગ</div>
                <div className="font-bold text-slate-900 mt-0.5">{form.department}</div>
              </div>
            </div>

            <div className={`p-3.5 rounded-xl border flex items-start gap-3 ${
              isClosingSoon ? 'bg-amber-50 border-amber-200 text-amber-900' : 'bg-slate-50 border-slate-200/80'
            }`}>
              <Calendar className={`w-5 h-5 shrink-0 mt-0.5 ${isClosingSoon ? 'text-amber-600' : 'text-deep-indigo'}`} />
              <div>
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">અંતિમ તારીખ (Deadline)</div>
                <div className="font-bold text-slate-900 mt-0.5">{form.deadline}</div>
                {form.daysLeft !== undefined && (
                  <div className="text-xs font-semibold text-amber-700 mt-0.5">
                    (બાકી સમય: {form.daysLeft} દિવસ)
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <h4 className="font-bold text-slate-900 flex items-center gap-2 mb-2">
              <FileText className="w-4 h-4 text-deep-indigo" />
              <span>વિગતવાર માહિતી</span>
            </h4>
            <p className="text-slate-600 text-sm leading-relaxed bg-slate-50/50 p-3.5 rounded-xl border border-slate-100">
              {form.description}
            </p>
          </div>

          {/* Eligibility */}
          <div>
            <h4 className="font-bold text-slate-900 flex items-center gap-2 mb-2">
              <UserCheck className="w-4 h-4 text-emerald-600" />
              <span>કોણ અરજી કરી શકે (લાયકાત / પાત્રતા)</span>
            </h4>
            <div className="p-3.5 bg-emerald-50/60 rounded-xl border border-emerald-200/60 text-emerald-950 font-medium text-sm">
              {form.eligibility}
            </div>
          </div>

          {/* Required Documents Checklist */}
          <div>
            <h4 className="font-bold text-slate-900 flex items-center gap-2 mb-3">
              <FileCheck2 className="w-4 h-4 text-deep-indigo" />
              <span>જરૂરી દસ્તાવેજોની યાદી ({form.documents.length} દસ્તાવેજ)</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {form.documents.map((doc, idx) => (
                <div 
                  key={idx}
                  className="flex items-center gap-2.5 p-3 rounded-lg bg-slate-50 border border-slate-200/70 text-slate-800 text-xs sm:text-sm font-medium"
                >
                  <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </div>
                  <span>{doc}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Service Note */}
          <div className="p-3.5 bg-amber-50/60 rounded-xl border border-amber-200/60 text-xs text-amber-900 space-y-1">
            <div className="font-bold flex items-center gap-1.5 text-amber-800">
              <ShieldCheck className="w-4 h-4" />
              <span>સ્ટાર કિંગ નેટવર્ક ગેરંટી:</span>
            </div>
            <p>
              તમારું ફોર્મ સત્તાવાર નિયમો અને તમામ માન્ય પુરાવાઓની સંપૂર્ણ ચકાસણી સાથે ૧૦૦% સાચી રીતે ઓનલાઈન સબમિટ કરી આપવામાં આવશે અને સત્તાવાર અરજી રસીદ તરત જ આપવામાં આવશે.
            </p>
          </div>

        </div>

        {/* Modal Footer / Action CTA */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            id="btn-cancel-modal"
            onClick={onClose}
            type="button"
            className="w-full sm:w-auto py-2.5 px-5 rounded-xl text-slate-600 hover:text-slate-800 hover:bg-slate-200 text-sm font-bold transition-colors min-h-[44px]"
          >
            બંધ કરો
          </button>

          <button
            id="btn-start-form-modal"
            onClick={() => {
              onClose();
              onStartFilling(form);
            }}
            type="button"
            className="w-full sm:w-auto py-3 px-6 rounded-xl bg-deep-indigo hover:bg-deep-indigo/90 text-white font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 min-h-[44px]"
          >
            <span>ફોર્મ ભરવાનું શરૂ કરો</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
