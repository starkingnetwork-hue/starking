import React from 'react';
import { ActiveFormItem } from '../../types';
import { 
  User, 
  Tag, 
  Edit3, 
  ShieldCheck, 
  AlertCircle
} from 'lucide-react';

interface StepReviewProps {
  selectedForm: ActiveFormItem | null;
  fullName: string;
  mobileNumber: string;
  village: string;
  taluka: string;
  district: string;
  category: string;
  message: string;
  agreedToTerms: boolean;
  setAgreedToTerms: (val: boolean) => void;
  onEditStep: (step: number) => void;
  errorMessage?: string;
}

export const StepReview: React.FC<StepReviewProps> = ({
  selectedForm,
  fullName,
  mobileNumber,
  village,
  taluka,
  district,
  category,
  message,
  agreedToTerms,
  setAgreedToTerms,
  onEditStep,
  errorMessage
}) => {
  return (
    <div id="step-review-section" className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-emerald-50/80 border border-emerald-200/90 rounded-2xl p-4 sm:p-5 flex items-start gap-3.5 text-emerald-950">
        <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
          <ShieldCheck className="w-6 h-6" />
        </div>
        <div>
          <h3 className="text-base font-bold text-emerald-950">
            તમારી માહિતી ચકાસો (Review Application)
          </h3>
          <p className="text-xs sm:text-sm text-emerald-800 mt-0.5 leading-relaxed">
            કૃપા કરીને નીચે આપેલી તમારી તમામ વિગતો ધ્યાનથી ચકાસી લો. જો કોઈ સુધારો કરવો હોય તો સંબંધિત વિભાગની બાજુમાં આપેલા <strong>"ફેરફાર કરો"</strong> બટન પર ક્લિક કરો.
          </p>
        </div>
      </div>

      {/* Error display if any */}
      {errorMessage && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-xl text-xs sm:text-sm text-red-700 flex items-start gap-2.5">
          <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
          <div>
            <div className="font-bold text-red-900">સબમિશન દરમિયાન ક્ષતિ:</div>
            <p>{errorMessage}</p>
          </div>
        </div>
      )}

      {/* Card 1: Selected Service */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs relative overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
          <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Tag className="w-4 h-4 text-deep-indigo" />
            <span>પસંદ કરેલ સેવા / ફોર્મ</span>
          </h4>
          <button
            type="button"
            onClick={() => onEditStep(1)}
            className="inline-flex items-center gap-1 text-xs font-bold text-deep-indigo hover:text-deep-indigo/80 hover:bg-slate-50 px-2.5 py-1 rounded-md transition-colors"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>ફેરફાર કરો</span>
          </button>
        </div>

        <div className="space-y-2">
          <div className="text-base sm:text-lg font-bold text-slate-900">
            {selectedForm ? selectedForm.title : category}
          </div>
          {selectedForm && (
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
              <span className="bg-slate-100 px-2 py-0.5 rounded font-semibold text-slate-700">
                {selectedForm.categoryBadge}
              </span>
              <span>•</span>
              <span>વિભાગ: {selectedForm.department}</span>
              <span>•</span>
              <span className="text-amber-700 font-bold">છેલ્લી તારીખ: {selectedForm.deadline}</span>
            </div>
          )}
        </div>
      </div>

      {/* Card 2: Applicant Personal Details */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
          <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <User className="w-4 h-4 text-deep-indigo" />
            <span>અરજદારની વિગતો</span>
          </h4>
          <button
            type="button"
            onClick={() => onEditStep(1)}
            className="inline-flex items-center gap-1 text-xs font-bold text-deep-indigo hover:text-deep-indigo/80 hover:bg-slate-50 px-2.5 py-1 rounded-md transition-colors"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>ફેરફાર કરો</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
              અરજદારનું નામ:
            </span>
            <span className="font-bold text-slate-900 text-base">{fullName}</span>
          </div>

          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
              મોબાઈલ નંબર:
            </span>
            <span className="font-bold text-slate-900 font-mono text-base">+91 {mobileNumber}</span>
          </div>

          <div className="sm:col-span-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
              સરનામું:
            </span>
            <span className="font-medium text-slate-800">
              ગામ: <strong>{village}</strong>, તાલુકો: <strong>{taluka}</strong>, જિલ્લો: <strong>{district}</strong>
            </span>
          </div>

          {message && (
            <div className="sm:col-span-2 bg-slate-50 p-3 rounded-xl border border-slate-100">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-0.5">
                વધારાની નોંધ:
              </span>
              <p className="text-slate-700 text-xs italic">{message}</p>
            </div>
          )}
        </div>
      </div>

      {/* Declaration Agreement Checkbox */}
      <div className="bg-slate-50 p-4 sm:p-5 rounded-2xl border border-slate-200">
        <label className="flex items-start gap-3 cursor-pointer select-none">
          <input
            id="checkbox-declaration"
            type="checkbox"
            checked={agreedToTerms}
            onChange={(e) => setAgreedToTerms(e.target.checked)}
            className="w-5 h-5 rounded border-slate-300 text-deep-indigo focus:ring-deep-indigo mt-0.5 cursor-pointer"
          />
          <div className="text-xs sm:text-sm text-slate-700 leading-relaxed">
            <span className="font-bold text-slate-900">સ્વ-ઘોષણા (Declaration):</span> હું ખાતરી આપું છું કે ઉપર દર્શાવેલ તમામ માહિતી મારી જાણ મુજબ સાચી છે અને મેં સ્ટાર કિંગ નેટવર્કની સેવા શરતો વાંચી છે.
          </div>
        </label>
      </div>

    </div>
  );
};
