import React from 'react';
import { REVIEWS } from '../utils/mockData';
import { Star, MessageSquare, Quote } from 'lucide-react';

export default function Reviews() {
  return (
    <section className="py-16 sm:py-24 bg-wheat-cream/30 relative overflow-hidden">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-deep-indigo/10 text-deep-indigo rounded-md text-xs font-bold border border-deep-indigo/20">
            <MessageSquare className="w-3.5 h-3.5 text-turmeric-gold" />
            <span>ગ્રાહકોના સાચા અભિપ્રાયો</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-heading font-black text-deep-indigo tracking-tight">
            ખુશ ગ્રાહકોની જુબાની
          </h2>
          <p className="text-gray-700 text-sm sm:text-base">
            અમારા સેવા કેન્દ્ર પરથી ફોર્મ ભરાવી સરકારી કલ્યાણ યોજનાઓ અને નોકરી મેળવનારા ગ્રાહકોના પ્રતિભાવો.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {REVIEWS.map((review) => (
            <div
              key={review.id}
              className="bg-white border border-deep-indigo/15 p-8 rounded-md shadow-sm hover:border-deep-indigo/35 transition-all flex flex-col justify-between relative group"
            >
              {/* Quote Icon watermark */}
              <Quote className="w-12 h-12 text-deep-indigo/5 absolute right-6 top-6 -z-0 group-hover:text-deep-indigo/10 transition-colors" />

              <div className="space-y-4 relative z-10 text-left">
                {/* Stars */}
                <div className="flex gap-1">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-turmeric-gold text-turmeric-gold" />
                  ))}
                </div>

                <p className="text-gray-600 text-xs sm:text-sm leading-relaxed italic font-semibold">
                  "{review.text}"
                </p>
              </div>

              <div className="pt-6 mt-6 border-t border-deep-indigo/10 flex items-center justify-between relative z-10 text-left">
                <div>
                  <h4 className="font-heading font-bold text-deep-indigo text-sm">{review.name}</h4>
                  <p className="text-xs text-gray-500 font-bold">{review.village}</p>
                </div>
                
                <span className="text-[10px] font-bold text-gray-400">
                  {review.date}
                </span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
