import React from 'react';
import { ArrowRight, LayoutGrid, Search, HelpCircle, ExternalLink } from 'lucide-react';

interface ImportantLinksProps {
  onNavigate?: (screen: 'home' | 'services' | 'form' | 'track' | 'about-policies') => void;
}

export default function ImportantLinks({ onNavigate }: ImportantLinksProps) {
  const links = [
    {
      title: 'સરકારી સેવાઓ',
      englishTitle: 'Government & Public Online Services',
      description: 'આઈ-ખેડૂત, સમાજ કલ્યાણ, ભરતી ફોર્મ્સ અને પ્રમાણપત્રોની યાદી.',
      action: () => onNavigate && onNavigate('services'),
      icon: LayoutGrid,
      isExternal: false
    },
    {
      title: 'અરજી ટ્રેકિંગ',
      englishTitle: 'Application Tracking Portal',
      description: 'તમારી અરજીનું રીઅલ-ટાઇમ સ્ટેટસ ID અને મોબાઈલ નંબરથી તપાસો.',
      action: () => onNavigate && onNavigate('track'),
      icon: Search,
      isExternal: false
    },
    {
      title: 'સપોર્ટ હેલ્પ',
      englishTitle: 'Customer Support & Assistance',
      description: 'વોટ્સએપ હેલ્પલાઇન દ્વારા તાત્કાલિક માર્ગદર્શન મેળવો.',
      action: () => {
        window.open('https://wa.me/919726074581?text=નમસ્તે સ્ટાર કિંગ નેટવર્ક, મને ઓનલાઈન સહાય જોઈએ છે.', '_blank');
      },
      icon: HelpCircle,
      isExternal: true
    }
  ];

  return (
    <div className="bg-white rounded-2xl border border-deep-indigo/15 p-6 sm:p-7 shadow-sm text-left space-y-4">
      <div className="border-b border-gray-100 pb-3">
        <h3 className="text-lg font-heading font-black text-deep-indigo flex items-center gap-2">
          <span>મહત્વની લિંક્સ (Important Links)</span>
        </h3>
        <p className="text-xs text-gray-500 font-medium mt-0.5">
          ઝડપી નેવિગેશન અને મહત્વપૂર્ણ સુવિધાઓ
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        {links.map((link, idx) => {
          const Icon = link.icon;
          return (
            <button
              key={idx}
              type="button"
              onClick={link.action}
              className="group p-4 rounded-xl bg-wheat-cream/20 hover:bg-wheat-cream/50 border border-deep-indigo/10 hover:border-deep-indigo/30 transition-all text-left flex flex-col justify-between cursor-pointer space-y-3 shadow-2xs hover:shadow-sm"
            >
              <div className="space-y-1.5">
                <div className="w-8 h-8 rounded-lg bg-deep-indigo/10 text-deep-indigo flex items-center justify-center group-hover:bg-deep-indigo group-hover:text-white transition-colors">
                  <Icon className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-heading font-black text-deep-indigo flex items-center gap-1.5 pt-1">
                  <span>→ {link.title}</span>
                </h4>
                <p className="text-[11px] text-gray-600 font-medium leading-relaxed">
                  {link.description}
                </p>
              </div>

              <div className="pt-2 border-t border-deep-indigo/10 flex items-center justify-between text-xs font-bold text-deep-indigo group-hover:text-field-green">
                <span>મુલાકાત લો</span>
                {link.isExternal ? (
                  <ExternalLink className="w-3.5 h-3.5 text-turmeric-gold group-hover:translate-x-0.5 transition-transform" />
                ) : (
                  <ArrowRight className="w-3.5 h-3.5 text-turmeric-gold group-hover:translate-x-1 transition-transform" />
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
