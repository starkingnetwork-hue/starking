import React, { useState } from 'react';
import { 
  Phone, 
  MessageCircle, 
  Mail, 
  Youtube, 
  MapPin, 
  Users, 
  Copy, 
  Check, 
  ExternalLink, 
  ShieldAlert, 
  Clock 
} from 'lucide-react';
import { SITE_CONFIG, buildWhatsAppLink } from '../config/siteConfig';

export default function ContactCard() {
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const handleCopy = (text: string, label: string) => {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => {
        setCopiedText(label);
        setTimeout(() => setCopiedText(null), 2000);
      });
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-deep-indigo/15 p-6 sm:p-7 shadow-sm text-left space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-100 pb-4">
        <div>
          <span className="text-[10px] font-black uppercase tracking-widest text-turmeric-gold bg-turmeric-gold/10 px-2.5 py-0.5 rounded-full border border-turmeric-gold/20">
            સત્તાવાર સહાય કેન્દ્ર
          </span>
          <h3 className="text-xl font-heading font-black text-deep-indigo tracking-tight mt-1">
            સંપર્ક વિગત (Contact Information)
          </h3>
        </div>

        <div className="flex items-center gap-1.5 text-xs font-bold text-gray-500 bg-gray-50 px-3 py-1.5 rounded-lg border border-gray-200/70">
          <Clock className="w-3.5 h-3.5 text-field-green" />
          <span>ઓનલાઇન સમય: {SITE_CONFIG.contact.supportHours}</span>
        </div>
      </div>

      {/* Critical Call Notice Banner */}
      <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3 text-rose-900">
        <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
        <div className="space-y-0.5">
          <p className="text-xs font-extrabold text-rose-700 uppercase tracking-wide">
            મહત્વપૂર્ણ સૂચના:
          </p>
          <p className="text-xs font-bold leading-relaxed">
            માત્ર વોટ્સએપ કોલ અને મેસેજ • <span className="underline decoration-rose-400 font-black">“સાદો ફોન કોલ ન કરવો”</span>
          </p>
        </div>
      </div>

      {/* Contact Channels Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        
        {/* WhatsApp Chat & Call */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-emerald-50 to-white border border-emerald-200/80 shadow-2xs space-y-2 flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-field-green text-white flex items-center justify-center shadow-xs">
                <MessageCircle className="w-5 h-5 fill-current" />
              </div>
              <div>
                <p className="text-[11px] font-bold text-gray-500 uppercase">WhatsApp Chat / Call</p>
                <p className="text-sm font-black text-deep-indigo font-mono">{SITE_CONFIG.whatsapp.displayNumber}</p>
              </div>
            </div>
          </div>

          <div className="pt-2 flex items-center gap-2">
            <a
              href={buildWhatsAppLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 py-2 px-3 bg-field-green hover:bg-field-green/90 text-white rounded-lg text-xs font-bold text-center transition-colors flex items-center justify-center gap-1.5 shadow-xs"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-current" />
              <span>ચેટ શરૂ કરો</span>
            </a>
            <button
              type="button"
              onClick={() => handleCopy(SITE_CONFIG.whatsapp.rawNumber, 'whatsapp')}
              className="p-2 bg-white hover:bg-gray-50 border border-gray-200 rounded-lg text-gray-600 transition-colors cursor-pointer"
              title="નંબર કોપી કરો"
            >
              {copiedText === 'whatsapp' ? (
                <Check className="w-4 h-4 text-emerald-600" />
              ) : (
                <Copy className="w-4 h-4 text-gray-500" />
              )}
            </button>
          </div>
        </div>

        {/* Official WhatsApp Community / Group */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-blue-50 to-white border border-blue-200/80 shadow-2xs space-y-2 flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-deep-indigo text-white flex items-center justify-center shadow-xs">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[11px] font-bold text-gray-500 uppercase">નવી ભરતી અને યોજના ગ્રુપ</p>
                <p className="text-sm font-black text-deep-indigo">WhatsApp Group</p>
              </div>
            </div>
          </div>

          <div className="pt-2">
            <a
              href={SITE_CONFIG.whatsapp.groupInviteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2 px-3 bg-deep-indigo hover:bg-deep-indigo/90 text-white rounded-lg text-xs font-bold text-center transition-colors flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Users className="w-3.5 h-3.5" />
              <span>ગ્રૂપમાં જોડાઓ (Join Group)</span>
              <ExternalLink className="w-3 h-3 text-white/70" />
            </a>
          </div>
        </div>

        {/* Email Support */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-amber-50 to-white border border-amber-200/80 shadow-2xs space-y-2 flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-turmeric-gold text-white flex items-center justify-center shadow-xs">
                <Mail className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <p className="text-[11px] font-bold text-gray-500 uppercase">સત્તાવાર ઈમેઈલ આઈડી</p>
                <p className="text-xs sm:text-sm font-extrabold text-deep-indigo truncate font-mono">{SITE_CONFIG.contact.email}</p>
              </div>
            </div>
          </div>

          <div className="pt-2 flex items-center gap-2">
            <a
              href={`mailto:${SITE_CONFIG.contact.email}`}
              className="flex-1 py-2 px-3 bg-turmeric-gold hover:bg-turmeric-gold/90 text-white rounded-lg text-xs font-bold text-center transition-colors flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Mail className="w-3.5 h-3.5" />
              <span>ઈમેઈલ મોકલો</span>
            </a>
            <button
              type="button"
              onClick={() => handleCopy(SITE_CONFIG.contact.email, 'email')}
              className="p-2 bg-white hover:bg-gray-50 border border-gray-200 rounded-lg text-gray-600 transition-colors cursor-pointer"
              title="ઈમેઈલ કોપી કરો"
            >
              {copiedText === 'email' ? (
                <Check className="w-4 h-4 text-emerald-600" />
              ) : (
                <Copy className="w-4 h-4 text-gray-500" />
              )}
            </button>
          </div>
        </div>

        {/* YouTube Channel */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-red-50 to-white border border-red-200/80 shadow-2xs space-y-2 flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-[#FF0000] text-white flex items-center justify-center shadow-xs">
                <Youtube className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[11px] font-bold text-gray-500 uppercase">માર્ગદર્શિકા વિડીયો</p>
                <p className="text-sm font-black text-deep-indigo">YouTube Channel</p>
              </div>
            </div>
          </div>

          <div className="pt-2">
            <a
              href="https://youtube.com/@starking-network?si=JCC6rgrnJSEUV1OJ"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2 px-3 bg-[#FF0000] hover:bg-[#FF0000]/90 text-white rounded-lg text-xs font-bold text-center transition-colors flex items-center justify-center gap-1.5 shadow-xs"
            >
              <Youtube className="w-3.5 h-3.5" />
              <span>ચેનલ સબ્સ્ક્રાઇબ કરો</span>
              <ExternalLink className="w-3 h-3 text-white/70" />
            </a>
          </div>
        </div>

      </div>

      {/* Location Bar */}
      <div className="p-3.5 rounded-xl bg-gray-50 border border-gray-200/80 flex items-center gap-3 text-xs text-gray-700 font-semibold">
        <div className="w-7 h-7 rounded-md bg-purple-100 text-purple-700 flex items-center justify-center shrink-0">
          <MapPin className="w-4 h-4" />
        </div>
        <div className="flex-1 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
          <span>
            <strong>કાર્યક્ષેત્ર / સરનામું:</strong> {SITE_CONFIG.contact.location}
          </span>
          <span className="text-[11px] text-gray-500 font-medium">સંપૂર્ણ ગુજરાત કવરેજ</span>
        </div>
      </div>

    </div>
  );
}
