import React, { useState } from 'react';
import { NEWS_UPDATES } from '../utils/mockData';
import { NewsUpdate } from '../types';
import { Bell, Calendar, Flame, CheckCircle, Search, Sparkles, Youtube } from 'lucide-react';

interface UpdatesProps {
  onApplyForService: (serviceName: string) => void;
}

export default function Updates({ onApplyForService }: UpdatesProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('તમામ');
  const [searchTerm, setSearchTerm] = useState<string>('');

  const categories = ['તમામ', 'નવી ભરતી', 'સરકારી યોજના', 'ખેડૂત', 'સ્કૉલરશિપ'];

  const filteredUpdates = NEWS_UPDATES.filter((item) => {
    const matchesCategory = selectedCategory === 'તમામ' || item.category === selectedCategory;
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <section id="updates" className="py-10 lg:py-16 bg-wheat-cream/30 relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-deep-indigo/10 text-deep-indigo rounded-md text-xs font-bold border border-deep-indigo/12">
            <Bell className="w-3.5 h-3.5 text-turmeric-gold" />
            <span>નવીનતમ સમાચાર અને રોજગાર અપડેટ્સ</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-heading font-bold text-deep-indigo">
            સરકારી યોજનાઓ અને ભરતી બોર્ડ
          </h2>
          <p className="text-warm-gray text-base sm:text-lg">
            ગુજરાત સરકારની નવી યોજનાઓ, આઈ-ખેડૂત પોર્ટલના ફોર્મ અને સરકારી ભરતી અંગેના રોજિંદા અપડેટ્સ મેળવો.
          </p>
        </div>

        {/* Filters and Search */}
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between mb-8">
          
          {/* Category Badges */}
          <div className="flex gap-2 overflow-x-auto pb-2 w-full md:w-auto no-scrollbar scroll-smooth">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-md text-xs sm:text-sm font-semibold whitespace-nowrap transition-colors duration-150 cursor-pointer ${
                  selectedCategory === category
                    ? 'bg-deep-indigo text-white border border-transparent'
                    : 'bg-white text-warm-gray border border-deep-indigo/12 hover:bg-wheat-cream/40'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Search bar */}
          <div className="relative w-full md:w-80">
            <input
              type="text"
              placeholder="અપડેટ શોધો (દા.ત. ભરતી)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-2.5 pl-10 rounded-lg bg-white border border-deep-indigo/12 focus:outline-none focus:border-deep-indigo text-sm text-deep-indigo placeholder-warm-gray font-semibold"
            />
            <Search className="w-4 h-4 text-warm-gray absolute left-3 top-3.5" />
          </div>

        </div>

        {/* Updates List Grid */}
        <div className="grid gap-4 max-w-4xl mx-auto">
          {filteredUpdates.length > 0 ? (
            filteredUpdates.map((update) => (
              <div
                key={update.id}
                className={`bg-white border p-5 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-colors duration-150 relative overflow-hidden ${
                  update.isUrgent ? 'border-brick-red bg-brick-red/[0.01]' : 'border-deep-indigo/12 hover:border-deep-indigo/25'
                }`}
              >
                {/* Visual Accent for Urgent Items */}
                {update.isUrgent && (
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-brick-red"></div>
                )}

                <div className="space-y-2 text-left">
                  <div className="flex items-center gap-2 flex-wrap">
                    {update.isUrgent ? (
                      <span className="flex items-center gap-1 bg-brick-red/10 text-brick-red text-[10px] font-bold px-2 py-0.5 rounded-md border border-brick-red/20">
                        <Flame className="w-3 h-3 fill-current text-brick-red" />
                        અગત્યનું
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 bg-deep-indigo/10 text-deep-indigo text-[10px] font-bold px-2 py-0.5 rounded-md border border-deep-indigo/20">
                        <Sparkles className="w-3 h-3 text-turmeric-gold" />
                        નવું
                      </span>
                    )}
                    {update.status && (
                      <span className="flex items-center gap-1 bg-field-green/10 text-field-green border border-field-green/20 text-[10px] font-bold px-2 py-0.5 rounded-md">
                        <CheckCircle className="w-3 h-3 shrink-0" />
                        સ્ટેટસ: {update.status}
                      </span>
                    )}
                    <span className="text-[11px] font-bold text-warm-gray uppercase">
                      {update.category}
                    </span>
                  </div>
                  
                  <h3 className="font-heading font-bold text-deep-indigo text-sm sm:text-base leading-snug">
                    {update.title}
                  </h3>
                  
                  <div className="flex items-center gap-1 text-xs text-warm-gray font-medium">
                    <Calendar className="w-3.5 h-3.5 text-turmeric-gold" />
                    <span>અપડેટ તારીખ: {update.date}</span>
                  </div>
                </div>

                <div className="shrink-0 flex items-center justify-end w-full sm:w-auto">
                  <button
                    onClick={() => onApplyForService(update.category === 'ખેડૂત' ? 'આઈ-ખેડૂત (i-Khedut)' : update.category === 'નવી ભરતી' ? 'સરકારી ભરતી' : 'સરકારી યોજનાઓ')}
                    className="w-full sm:w-auto px-5 py-2.5 bg-deep-indigo hover:bg-deep-indigo-hover active:bg-deep-indigo-active border border-transparent hover:border-turmeric-gold text-white font-semibold text-xs rounded-md transition-colors duration-150 cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <span>અરજી કરો (ઓનલાઈન ફોર્મ)</span>
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12 bg-white rounded-lg border border-deep-indigo/12 p-8 space-y-3">
              <Bell className="w-8 h-8 text-warm-gray mx-auto" />
              <p className="text-deep-indigo font-bold">કોઈ માહિતી કે નવી અપડેટ મળી નથી.</p>
              <p className="text-xs text-warm-gray">કૃપા કરીને અન્ય કેટેગરી પસંદ કરો અથવા અલગ શબ્દો શોધો.</p>
            </div>
          )}
        </div>

        {/* Dual Promotional/Support Banners */}
        <div className="mt-12 max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* WhatsApp Group Support CTA */}
          <div className="p-6 bg-white border border-deep-indigo/12 rounded-lg flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left transition-colors duration-150 hover:border-deep-indigo/25">
            <div className="w-12 h-12 rounded-md bg-field-green/10 flex items-center justify-center text-field-green shrink-0 border border-field-green/20">
              <Bell className="w-6 h-6 text-field-green" />
            </div>
            <div className="space-y-1">
              <p className="font-heading font-bold text-deep-indigo text-sm">અમારા ઓફિશિયલ વોટ્સએપ ગ્રુપમાં જોડાઓ!</p>
              <p className="text-xs text-warm-gray font-semibold leading-relaxed">નવી સરકારી ભરતી અને દરેક યોજનાઓની તાજી માહિતી વોટ્સએપ પર મેળવવા માટે અમારા ગ્રુપમાં જોડાવો.</p>
            </div>
            <a
              href="https://chat.whatsapp.com/GUpckcU2YiSKa9WdyN87ZX?s=sh&p=a&mlu=0&ilr=0"
              target="_blank"
              rel="noopener noreferrer"
              className="sm:ml-auto px-4 py-2.5 bg-field-green hover:bg-field-green/90 text-white font-semibold text-xs rounded-md transition-colors duration-150 whitespace-nowrap cursor-pointer border border-transparent"
            >
              વોટ્સએપ ગ્રુપ લિંક
            </a>
          </div>

          {/* YouTube Channel CTA */}
          <div className="p-6 bg-white border border-deep-indigo/12 rounded-lg flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left transition-colors duration-150 hover:border-deep-indigo/25">
            <div className="w-12 h-12 rounded-md bg-brick-red/10 flex items-center justify-center text-brick-red shrink-0 border border-brick-red/20">
              <Youtube className="w-6 h-6 text-brick-red" />
            </div>
            <div className="space-y-1">
              <p className="font-heading font-bold text-deep-indigo text-sm">અમારી ઓફિશિયલ યુટ્યુબ ચેનલ!</p>
              <p className="text-xs text-warm-gray font-semibold leading-relaxed">નવા સરકારી ફોર્મ ભરવાની સ્ટેપ-બાય-સ્ટેપ માહિતી અને યોજનાઓના સરળ લાઈવ વિડીયો જોવા માટે ચેનલ સબસ્ક્રાઇબ કરો.</p>
            </div>
            <a
              href="https://youtube.com/@starking-network?si=JCC6rgrnJSEUV1OJ"
              target="_blank"
              rel="noopener noreferrer"
              className="sm:ml-auto px-4 py-2.5 bg-brick-red hover:bg-brick-red/90 text-white font-semibold text-xs rounded-md transition-colors duration-150 whitespace-nowrap cursor-pointer border border-transparent"
            >
              યુટ્યુબ ચેનલ લિંક
            </a>
          </div>
        </div>

      </div>
    </section>
  );
}
