import React, { useState } from 'react';
import { trackApplication } from '../utils/localStore';
import { CustomerRequest } from '../types';
import { SITE_CONFIG, buildWhatsAppLink } from '../config/siteConfig';
import { 
  Search, 
  Loader2, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Smartphone, 
  Copy, 
  Check, 
  MapPin, 
  User, 
  Calendar, 
  Layers, 
  MessageSquare, 
  ExternalLink, 
  ShieldCheck, 
  RefreshCw,
  FileCheck,
  Send,
  Cpu,
  ArrowRight,
  HelpCircle,
  XCircle,
  Share2,
  Printer
} from 'lucide-react';

interface TrackingProps {
  refreshTrigger: number;
}

interface TimelineStage {
  id: number;
  title: string;
  englishTitle: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
}

const TIMELINE_STAGES: TimelineStage[] = [
  {
    id: 1,
    title: 'અરજી સબમિશન',
    englishTitle: 'Application Submitted',
    description: 'તમારી અરજી સફળતાપૂર્વક નોંધાઈ છે અને સિસ્ટમમાં દાખલ થઈ છે.',
    icon: Send
  },
  {
    id: 2,
    title: 'દસ્તાવેજ ચકાસણી',
    englishTitle: 'Document Verification',
    description: 'અરજદારની વિગતો અને જરૂરી દસ્તાવેજોની પ્રાથમિક ચકાસણી.',
    icon: FileCheck
  },
  {
    id: 3,
    title: 'પ્રક્રિયા હેઠળ',
    englishTitle: 'In Progress / Processing',
    description: 'સંબંધિત સરકારી/ઓનલાઇન પોર્ટલ પર અરજીની પ્રક્રિયા ચાલી રહી છે.',
    icon: Cpu
  },
  {
    id: 4,
    title: 'અરજી પૂર્ણ / મંજૂર',
    englishTitle: 'Completed / Approved',
    description: 'સેવા સફળતાપૂર્વક પૂર્ણ થયેલ છે અને જરૂરી દસ્તાવેજ/પ્રમાણપત્ર તૈયાર છે.',
    icon: CheckCircle2
  }
];

export default function Tracking({ refreshTrigger }: TrackingProps) {
  const [appId, setAppId] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [searched, setSearched] = useState(false);
  const [results, setResults] = useState<CustomerRequest[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Search for the single request matching BOTH ID and Mobile number
  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    const cleanId = appId.trim();
    const cleanMobile = mobileNumber.trim().replace(/[^0-9]/g, '');

    if (!cleanId) {
      setValidationError('કૃપા કરીને અરજી ID દાખલ કરો (દા.ત. SKN100001)');
      return;
    }

    if (!cleanMobile || cleanMobile.length !== 10) {
      setValidationError('કૃપા કરીને માન્ય ૧૦-આંકડાનો મોબાઈલ નંબર દાખલ કરો');
      return;
    }

    setIsSearching(true);
    try {
      const matchedRequests = await trackApplication(cleanId, cleanMobile);
      setResults(matchedRequests);
    } catch (err) {
      console.error("Error tracking application:", err);
      setResults([]);
    } finally {
      setIsSearching(false);
      setSearched(true);
    }
  };

  const handleResetSearch = () => {
    setAppId('');
    setMobileNumber('');
    setResults([]);
    setSearched(false);
    setValidationError(null);
  };

  // Copy Application ID to clipboard with feedback
  const handleCopyId = (id: string) => {
    const textToCopy = id.startsWith('#') ? id : `#${id}`;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(textToCopy).then(() => {
        setCopiedId(id);
        setTimeout(() => setCopiedId(null), 2200);
      }).catch(() => {
        setCopiedId(id);
        setTimeout(() => setCopiedId(null), 2200);
      });
    } else {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2200);
    }
  };

  // Get active timeline index from status
  const getStageIndex = (status: CustomerRequest['status']): number => {
    const normalized = (status || '').trim();
    if (normalized === 'સબમિટ કરેલ' || normalized === 'Submitted') return 0;
    if (normalized === 'દસ્તાવેજ ચકાસણી' || normalized === 'ચકાસણી હેઠળ' || normalized === 'Verification') return 1;
    if (normalized === 'પ્રક્રિયા હેઠળ' || normalized === 'પ્રક્રિયામાં' || normalized === 'Processing' || normalized === 'In Progress') return 2;
    if (normalized === 'પૂર્ણ થયેલ' || normalized === 'મંજૂર' || normalized === 'પૂર્ણ' || normalized === 'Completed' || normalized === 'Approved') return 3;
    if (normalized === 'અસ્વીકાર' || normalized === 'રદ' || normalized === 'Rejected') return -1; // Special rejected state
    return 0;
  };

  // Get comprehensive status metadata for UI rendering
  const getStatusMetadata = (status: CustomerRequest['status']) => {
    const normalized = (status || '').trim();

    if (normalized === 'પૂર્ણ થયેલ' || normalized === 'મંજૂર' || normalized === 'પૂર્ણ' || normalized === 'Completed') {
      return {
        badgeBg: 'bg-emerald-50 text-emerald-800 border-emerald-200 ring-1 ring-emerald-500/20',
        cardBg: 'from-emerald-500/10 via-emerald-500/5 to-white',
        borderAccent: 'border-emerald-500',
        textColor: 'text-emerald-800',
        iconBg: 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30',
        label: 'સફળતાપૂર્વક પૂર્ણ થયેલ (Completed)',
        shortLabel: 'પૂર્ણ થયેલ',
        explanation: 'તમારી અરજી સફળતાપૂર્વક પૂર્ણ થઈ ગઈ છે. તમારો દસ્તાવેજ/પ્રમાણપત્ર તૈયાર છે.',
        icon: CheckCircle2,
        progressPercent: 100,
        stageNumber: 4,
        isRejected: false
      };
    }

    if (normalized === 'પ્રક્રિયા હેઠળ' || normalized === 'પ્રક્રિયામાં' || normalized === 'Processing') {
      return {
        badgeBg: 'bg-indigo-50 text-indigo-900 border-indigo-200 ring-1 ring-indigo-500/20',
        cardBg: 'from-indigo-600/10 via-indigo-600/5 to-white',
        borderAccent: 'border-deep-indigo',
        textColor: 'text-deep-indigo',
        iconBg: 'bg-deep-indigo text-white shadow-md shadow-deep-indigo/30',
        label: 'પ્રક્રિયા હેઠળ છે (In Progress)',
        shortLabel: 'પ્રક્રિયા હેઠળ',
        explanation: 'તમારી અરજી હાલમાં સંબંધિત સરકારી/ઓનલાઇન વિભાગમાં પ્રોસેસ થઈ રહી છે.',
        icon: Cpu,
        progressPercent: 75,
        stageNumber: 3,
        isRejected: false
      };
    }

    if (normalized === 'દસ્તાવેજ ચકાસણી' || normalized === 'ચકાસણી હેઠળ' || normalized === 'Verification') {
      return {
        badgeBg: 'bg-amber-50 text-amber-900 border-amber-200 ring-1 ring-amber-500/20',
        cardBg: 'from-turmeric-gold/10 via-turmeric-gold/5 to-white',
        borderAccent: 'border-turmeric-gold',
        textColor: 'text-amber-900',
        iconBg: 'bg-turmeric-gold text-white shadow-md shadow-turmeric-gold/30',
        label: 'દસ્તાવેજ ચકાસણી ચાલુ છે (Reviewing Documents)',
        shortLabel: 'દસ્તાવેજ ચકાસણી',
        explanation: 'તમારી અરજીના જરૂરી દસ્તાવેજો અને વિગતોની ચકાસણી ચાલી રહી છે.',
        icon: FileCheck,
        progressPercent: 50,
        stageNumber: 2,
        isRejected: false
      };
    }

    if (normalized === 'અસ્વીકાર' || normalized === 'રદ' || normalized === 'Rejected') {
      return {
        badgeBg: 'bg-rose-50 text-rose-800 border-rose-200 ring-1 ring-rose-500/20',
        cardBg: 'from-rose-500/10 via-rose-500/5 to-white',
        borderAccent: 'border-rose-600',
        textColor: 'text-rose-800',
        iconBg: 'bg-rose-600 text-white shadow-md shadow-rose-600/30',
        label: 'અરજી અસ્વીકાર / રદ (Rejected)',
        shortLabel: 'અસ્વીકાર થયેલ',
        explanation: 'અધૂરા દસ્તાવેજ અથવા તકનીકી કારણોસર અરજી અસ્વીકાર થયેલ છે. વિગત માટે નીચે વહીવટી નોંધ તપાસો અથવા વોટ્સએપ પર સંપર્ક કરો.',
        icon: XCircle,
        progressPercent: 0,
        stageNumber: 0,
        isRejected: true
      };
    }

    // Default: સબમિટ કરેલ (Submitted)
    return {
      badgeBg: 'bg-blue-50 text-blue-900 border-blue-200 ring-1 ring-blue-500/20',
      cardBg: 'from-blue-600/10 via-blue-600/5 to-white',
      borderAccent: 'border-blue-600',
      textColor: 'text-blue-900',
      iconBg: 'bg-blue-600 text-white shadow-md shadow-blue-600/30',
      label: 'સબમિટ કરેલ (Application Submitted)',
      shortLabel: 'સબમિટ કરેલ',
      explanation: 'તમારી અરજી સફળતાપૂર્વક નોંધાઈ ગઈ છે. ટૂંક સમયમાં દસ્તાવેજ ચકાસણી પ્રક્રિયા શરૂ કરવામાં આવશે.',
      icon: Clock,
      progressPercent: 25,
      stageNumber: 1,
      isRejected: false
    };
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <section id="tracking" className="py-12 sm:py-20 bg-gradient-to-b from-wheat-cream/40 via-white to-wheat-cream/20 relative">
      <div id="tracking-status" className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-8 sm:mb-12 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-deep-indigo/10 text-deep-indigo rounded-full text-xs font-bold border border-deep-indigo/15 shadow-2xs">
            <span className="w-2 h-2 rounded-full bg-field-green animate-pulse"></span>
            <Smartphone className="w-3.5 h-3.5 text-turmeric-gold" />
            <span>લાઇવ એપ્લિકેશન ટ્રેકિંગ પોર્ટલ</span>
          </div>

          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-black text-deep-indigo tracking-tight">
            મારી અરજીનું સ્ટેટસ તપાસો
          </h2>

          <p className="text-gray-600 text-sm sm:text-base leading-relaxed">
            તમારી અરજીની સ્થિતિ જાણવા માટે તમારી રસીદ પર આપેલો <strong className="text-deep-indigo">અરજી ID</strong> અને રજીસ્ટર્ડ <strong className="text-deep-indigo">૧૦-આંકડાનો મોબાઇલ નંબર</strong> દાખલ કરો.
          </p>
        </div>

        {/* Modern Search Card */}
        <div className="bg-white rounded-2xl border border-deep-indigo/15 p-5 sm:p-7 shadow-lg shadow-deep-indigo/5 mb-10 max-w-2xl mx-auto transition-all">
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* Application ID Input */}
              <div className="space-y-1.5">
                <label className="block text-xs font-extrabold text-gray-700">
                  અરજી ID (Application ID) <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="દા.ત. SKN100001"
                    value={appId}
                    onChange={(e) => {
                      setAppId(e.target.value);
                      if (validationError) setValidationError(null);
                    }}
                    className="w-full pl-11 pr-4 py-3 bg-gray-50/70 hover:bg-white focus:bg-white border border-gray-200 focus:border-deep-indigo rounded-xl text-base sm:text-sm font-bold text-deep-indigo placeholder-gray-400 transition-all font-mono"
                    required
                  />
                  <FileText className="w-5 h-5 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>

              {/* Mobile Number Input */}
              <div className="space-y-1.5">
                <label className="block text-xs font-extrabold text-gray-700">
                  મોબાઇલ નંબર (Registered Mobile) <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    placeholder="૧૦ આંકડાનો મોબાઇલ નંબર"
                    value={mobileNumber}
                    onChange={(e) => {
                      setMobileNumber(e.target.value);
                      if (validationError) setValidationError(null);
                    }}
                    maxLength={10}
                    className="w-full pl-11 pr-4 py-3 bg-gray-50/70 hover:bg-white focus:bg-white border border-gray-200 focus:border-deep-indigo rounded-xl text-base sm:text-sm font-bold text-deep-indigo placeholder-gray-400 transition-all font-mono"
                    required
                  />
                  <Smartphone className="w-5 h-5 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>

            </div>

            {/* Validation Error */}
            {validationError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs font-bold text-rose-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{validationError}</span>
              </div>
            )}

            {/* Search Submit Button */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
              <button
                type="submit"
                disabled={isSearching}
                className="w-full py-3.5 px-6 bg-deep-indigo hover:bg-deep-indigo/95 text-white font-bold rounded-xl text-sm shadow-md shadow-deep-indigo/15 hover:shadow-lg hover:shadow-deep-indigo/25 transition-all cursor-pointer flex items-center justify-center gap-2.5 min-h-[48px] disabled:opacity-60"
              >
                {isSearching ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin text-turmeric-gold" />
                    <span>ડેટાબેઝમાં તપાસ થઈ રહી છે...</span>
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 text-turmeric-gold" />
                    <span>સ્ટેટસ તપાસો (Track Status)</span>
                    <ArrowRight className="w-4 h-4 text-white/70" />
                  </>
                )}
              </button>

              {searched && (
                <button
                  type="button"
                  onClick={handleResetSearch}
                  className="w-full sm:w-auto px-4 py-3.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap min-h-[48px]"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-gray-500" />
                  <span>નવી શોધ</span>
                </button>
              )}
            </div>

            {/* Small Quick Info Tip */}
            <div className="pt-2 flex items-center justify-between text-[11px] text-gray-500 font-medium border-t border-gray-100">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-field-green" />
                <span>તમારી માહિતી સંપૂર્ણપણે સુરક્ષિત છે</span>
              </span>
              <span>૨૪x૭ રીઅલ-ટાઇમ સિંક્રોનાઇઝેશન</span>
            </div>

          </form>
        </div>

        {/* LOADING SKELETON PLACEHOLDER */}
        {isSearching && (
          <div className="space-y-6 max-w-3xl mx-auto animate-pulse">
            
            {/* Top Status Header Skeleton */}
            <div className="bg-white p-6 rounded-2xl border border-gray-200 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-2">
                  <div className="h-4 w-28 bg-gray-200 rounded-md"></div>
                  <div className="h-7 w-44 bg-gray-300 rounded-md"></div>
                </div>
                <div className="h-9 w-36 bg-gray-200 rounded-xl"></div>
              </div>
              <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-gray-300 w-2/3"></div>
              </div>
            </div>

            {/* Timeline Skeleton */}
            <div className="bg-white p-6 rounded-2xl border border-gray-200">
              <div className="h-4 w-32 bg-gray-200 rounded-md mb-6"></div>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="space-y-2">
                    <div className="w-10 h-10 bg-gray-200 rounded-full mx-auto sm:mx-0"></div>
                    <div className="h-4 w-24 bg-gray-200 rounded mx-auto sm:mx-0"></div>
                    <div className="h-3 w-32 bg-gray-100 rounded mx-auto sm:mx-0"></div>
                  </div>
                ))}
              </div>
            </div>

            {/* Info Grid Skeleton */}
            <div className="bg-white p-6 rounded-2xl border border-gray-200">
              <div className="h-4 w-36 bg-gray-200 rounded-md mb-4"></div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {[1, 2, 3, 4, 5, 6].map(i => (
                  <div key={i} className="space-y-1.5 p-3 bg-gray-50 rounded-xl">
                    <div className="h-3 w-16 bg-gray-200 rounded"></div>
                    <div className="h-4 w-28 bg-gray-300 rounded"></div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* RESULTS SECTION */}
        {!isSearching && searched && (
          <div className="space-y-6 max-w-3xl mx-auto animate-fade-in text-left">
            
            {results.length > 0 ? (
              results.map((req) => {
                const meta = getStatusMetadata(req.status);
                const currentStageIdx = getStageIndex(req.status);
                const StatusIcon = meta.icon;

                return (
                  <div key={req.id} className="space-y-6">
                    
                    {/* 1. TOP APPLICATION STATUS DASHBOARD CARD */}
                    <div className="bg-white rounded-2xl border border-deep-indigo/15 shadow-xl shadow-deep-indigo/5 overflow-hidden transition-all">
                      
                      {/* Top Bar Header */}
                      <div className="bg-gradient-to-r from-deep-indigo via-deep-indigo to-deep-indigo-hover text-white p-5 sm:p-6">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                          
                          {/* Application ID & Title */}
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="text-[11px] font-bold uppercase tracking-widest text-turmeric-gold bg-white/10 px-2.5 py-0.5 rounded-full border border-turmeric-gold/30">
                                Application Status
                              </span>
                              <span className="text-white/60 text-xs font-semibold">• અરજી સ્થિતિ</span>
                            </div>

                            <div className="flex items-center gap-3 pt-1">
                              <h3 className="text-xl sm:text-2xl font-black font-mono tracking-tight text-white flex items-center gap-2">
                                <span>#{req.id.replace(/^#/, '')}</span>
                              </h3>

                              {/* Copy ID Button */}
                              <button
                                type="button"
                                onClick={() => handleCopyId(req.id)}
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/15 hover:bg-white/25 text-white text-xs font-bold transition-all cursor-pointer border border-white/20 active:scale-95"
                                title="અરજી ID કોપી કરો"
                              >
                                {copiedId === req.id ? (
                                  <>
                                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                                    <span className="text-emerald-300">કોપી થઈ ગયું!</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy className="w-3.5 h-3.5 text-turmeric-gold" />
                                    <span>કોપી ID</span>
                                  </>
                                )}
                              </button>
                            </div>
                          </div>

                          {/* Top Status Pill */}
                          <div className="flex items-center gap-2">
                            <div className={`px-4 py-2 rounded-xl text-xs font-black flex items-center gap-2 shadow-xs bg-white text-deep-indigo border border-white/30`}>
                              <StatusIcon className={`w-4 h-4 ${req.status === 'પ્રક્રિયા હેઠળ' ? 'animate-spin text-turmeric-gold' : 'text-emerald-600'}`} />
                              <span>{req.status}</span>
                            </div>
                          </div>

                        </div>
                      </div>

                      {/* 2. HIGHLIGHTED CURRENT STATUS HERO CARD */}
                      <div className={`p-5 sm:p-6 bg-gradient-to-b ${meta.cardBg} border-b border-gray-100`}>
                        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                          
                          <div className="flex items-start gap-4">
                            <div className={`w-12 h-12 sm:w-14 sm:h-14 rounded-2xl ${meta.iconBg} flex items-center justify-center shrink-0`}>
                              <StatusIcon className="w-6 h-6 sm:w-7 sm:h-7" />
                            </div>

                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="text-[11px] font-extrabold uppercase tracking-wider text-gray-500">
                                  હાલની સ્થિતિ (Current Stage)
                                </span>
                                <span className={`text-[10px] px-2 py-0.5 rounded-full font-black ${meta.badgeBg}`}>
                                  તબક્કો {meta.stageNumber} / 4
                                </span>
                              </div>

                              <h4 className={`text-lg sm:text-xl font-heading font-black ${meta.textColor}`}>
                                {meta.label}
                              </h4>

                              <p className="text-xs sm:text-sm text-gray-700 leading-relaxed max-w-xl font-medium">
                                {meta.explanation}
                              </p>
                            </div>
                          </div>

                          {/* Progress Percentage Circular / Metric Display */}
                          {!meta.isRejected && (
                            <div className="self-end md:self-center shrink-0 bg-white/80 backdrop-blur-xs p-3 rounded-2xl border border-gray-200/80 shadow-xs text-center min-w-[110px]">
                              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block">પ્રગતિ (Progress)</span>
                              <span className="text-2xl font-black text-deep-indigo font-mono block">
                                {meta.progressPercent}%
                              </span>
                              <span className="text-[10px] font-bold text-field-green">રીઅલ-ટાઇમ અપડેટ</span>
                            </div>
                          )}

                        </div>

                        {/* Visual Progress Bar */}
                        {!meta.isRejected && (
                          <div className="mt-5 space-y-1.5">
                            <div className="h-2.5 w-full bg-gray-200/80 rounded-full overflow-hidden p-0.5">
                              <div 
                                className="h-full bg-gradient-to-r from-turmeric-gold via-deep-indigo to-field-green rounded-full transition-all duration-700 ease-out shadow-xs"
                                style={{ width: `${meta.progressPercent}%` }}
                              ></div>
                            </div>
                            <div className="flex justify-between items-center text-[10px] text-gray-500 font-bold px-0.5">
                              <span>સબમિશન (0%)</span>
                              <span>ચકાસણી (50%)</span>
                              <span>પૂર્ણ થયેલ (100%)</span>
                            </div>
                          </div>
                        )}

                      </div>

                      {/* 3. MODERN TIMELINE (Horizontal on Desktop, Vertical on Mobile) */}
                      <div className="p-5 sm:p-7 border-b border-gray-100 bg-white">
                        <div className="flex items-center justify-between mb-6">
                          <h4 className="text-sm font-heading font-black text-deep-indigo flex items-center gap-2">
                            <Layers className="w-4 h-4 text-turmeric-gold" />
                            <span>અરજી પ્રોસેસ ટાઈમલાઇન (Process Milestones)</span>
                          </h4>
                          <span className="text-[11px] text-gray-500 font-semibold">
                            તારીખ: {req.createdAt || 'નોંધાયેલ'}
                          </span>
                        </div>

                        {/* DESKTOP HORIZONTAL TIMELINE */}
                        <div className="hidden md:grid md:grid-cols-4 gap-4 relative">
                          {/* Background Connector Track */}
                          <div className="absolute top-5 left-8 right-8 h-1 bg-gray-200 -z-0"></div>
                          
                          {/* Active Connector Fill */}
                          {!meta.isRejected && currentStageIdx >= 0 && (
                            <div 
                              className="absolute top-5 left-8 h-1 bg-field-green transition-all duration-500 -z-0"
                              style={{ 
                                width: currentStageIdx === 0 
                                  ? '0%' 
                                  : currentStageIdx === 1 
                                  ? '33.33%' 
                                  : currentStageIdx === 2 
                                  ? '66.66%' 
                                  : 'calc(100% - 4rem)' 
                              }}
                            ></div>
                          )}

                          {TIMELINE_STAGES.map((stage, idx) => {
                            const isCompleted = !meta.isRejected && idx < currentStageIdx;
                            const isCurrent = !meta.isRejected && idx === currentStageIdx;
                            const isUpcoming = !meta.isRejected && idx > currentStageIdx;
                            const StageIcon = stage.icon;

                            return (
                              <div key={stage.id} className="relative z-10 flex flex-col items-center text-center space-y-2">
                                
                                {/* Step Node Icon */}
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 ${
                                  isCompleted 
                                    ? 'bg-field-green text-white shadow-md shadow-field-green/20 ring-4 ring-field-green/10' 
                                    : isCurrent 
                                    ? 'bg-deep-indigo text-white ring-4 ring-deep-indigo/20 shadow-md animate-pulse' 
                                    : 'bg-gray-100 text-gray-400 border border-gray-200'
                                }`}>
                                  {isCompleted ? (
                                    <Check className="w-5 h-5" />
                                  ) : (
                                    <StageIcon className="w-4 h-4" />
                                  )}
                                </div>

                                {/* Step Label */}
                                <div className="space-y-0.5">
                                  <div className="flex items-center justify-center gap-1">
                                    <span className={`text-[11px] font-bold ${
                                      isCurrent 
                                        ? 'text-deep-indigo font-black' 
                                        : isCompleted 
                                        ? 'text-field-green' 
                                        : 'text-gray-400'
                                    }`}>
                                      {stage.title}
                                    </span>
                                  </div>

                                  {isCurrent && (
                                    <span className="inline-block text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-deep-indigo text-white shadow-2xs">
                                      હાલની સ્થિતિ
                                    </span>
                                  )}

                                  <p className="text-[10px] text-gray-500 font-medium line-clamp-2 px-1">
                                    {stage.description}
                                  </p>
                                </div>

                              </div>
                            );
                          })}
                        </div>

                        {/* MOBILE VERTICAL TIMELINE */}
                        <div className="md:hidden space-y-4 relative pl-2">
                          {TIMELINE_STAGES.map((stage, idx) => {
                            const isCompleted = !meta.isRejected && idx < currentStageIdx;
                            const isCurrent = !meta.isRejected && idx === currentStageIdx;
                            const isUpcoming = !meta.isRejected && idx > currentStageIdx;
                            const StageIcon = stage.icon;
                            const isLast = idx === TIMELINE_STAGES.length - 1;

                            return (
                              <div key={stage.id} className="relative flex items-start gap-3.5">
                                
                                {/* Vertical Connector Line */}
                                {!isLast && (
                                  <div className={`absolute left-[17px] top-9 bottom-[-16px] w-0.5 ${
                                    isCompleted ? 'bg-field-green' : 'bg-gray-200'
                                  }`}></div>
                                )}

                                {/* Node Circle */}
                                <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 z-10 transition-all ${
                                  isCompleted 
                                    ? 'bg-field-green text-white ring-4 ring-field-green/10 shadow-xs' 
                                    : isCurrent 
                                    ? 'bg-deep-indigo text-white ring-4 ring-deep-indigo/20 shadow-md scale-105' 
                                    : 'bg-gray-100 text-gray-400 border border-gray-200'
                                }`}>
                                  {isCompleted ? (
                                    <Check className="w-4 h-4" />
                                  ) : (
                                    <StageIcon className="w-4 h-4" />
                                  )}
                                </div>

                                {/* Content Details */}
                                <div className={`flex-1 p-3 rounded-xl border transition-all ${
                                  isCurrent 
                                    ? 'bg-deep-indigo/5 border-deep-indigo/30 shadow-xs' 
                                    : isCompleted 
                                    ? 'bg-gray-50/70 border-gray-200/80' 
                                    : 'bg-transparent border-transparent opacity-60'
                                }`}>
                                  <div className="flex items-center justify-between gap-2">
                                    <h5 className={`text-xs font-bold ${
                                      isCurrent ? 'text-deep-indigo font-black' : isCompleted ? 'text-gray-900' : 'text-gray-500'
                                    }`}>
                                      {stage.title}
                                    </h5>

                                    {isCurrent && (
                                      <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-deep-indigo text-white">
                                        હાલની સ્થિતિ
                                      </span>
                                    )}

                                    {isCompleted && (
                                      <span className="text-[10px] font-bold text-field-green flex items-center gap-0.5">
                                        <Check className="w-3 h-3" /> પૂર્ણ
                                      </span>
                                    )}
                                  </div>

                                  <p className="text-[11px] text-gray-600 mt-1 leading-relaxed">
                                    {stage.description}
                                  </p>
                                </div>

                              </div>
                            );
                          })}
                        </div>

                      </div>

                      {/* 4. ADMINISTRATIVE NOTES CARD (Only shown if notes exist) */}
                      {req.notes && req.notes.trim() !== '' && (
                        <div className="p-5 sm:p-6 bg-amber-50/70 border-b border-amber-200/60">
                          <div className="flex items-start gap-3">
                            <div className="w-9 h-9 rounded-xl bg-turmeric-gold text-white flex items-center justify-center shrink-0 shadow-xs">
                              <MessageSquare className="w-4 h-4" />
                            </div>
                            <div className="space-y-1 flex-1">
                              <div className="flex items-center justify-between">
                                <h4 className="text-xs font-extrabold uppercase tracking-wider text-amber-900 flex items-center gap-1.5">
                                  <span>વહીવટી નોંધ (Admin Remarks)</span>
                                </h4>
                                <span className="text-[10px] font-bold text-amber-800 bg-amber-100/80 px-2 py-0.5 rounded">
                                  સત્તાવાર અપડેટ
                                </span>
                              </div>
                              <p className="text-xs sm:text-sm font-semibold text-amber-950 bg-white/90 p-3.5 rounded-xl border border-amber-200 shadow-2xs leading-relaxed">
                                "{req.notes}"
                              </p>
                              <p className="text-[10px] text-amber-800 font-medium">
                                * આ નોંધ સ્ટાર કિંગ નેટવર્ક વહીવટી ટીમ દ્વારા ગ્રાહકની જાણકારી માટે ઉમેરવામાં આવી છે.
                              </p>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* 5. APPLICATION INFORMATION GRID */}
                      <div className="p-5 sm:p-7 bg-gray-50/60">
                        <h4 className="text-xs font-extrabold uppercase tracking-wider text-gray-500 mb-4 flex items-center gap-1.5">
                          <FileText className="w-4 h-4 text-deep-indigo" />
                          <span>અરજીની વિગતવાર માહિતી (Applicant Information)</span>
                        </h4>

                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                          
                          {/* Applicant Name */}
                          <div className="bg-white p-3.5 rounded-xl border border-gray-200/80 shadow-2xs space-y-1">
                            <span className="text-[11px] text-gray-400 font-bold block flex items-center gap-1">
                              <User className="w-3.5 h-3.5 text-gray-400" />
                              <span>અરજદારનું પૂરું નામ</span>
                            </span>
                            <p className="text-sm font-extrabold text-deep-indigo truncate">{req.fullName}</p>
                          </div>

                          {/* Registered Mobile */}
                          <div className="bg-white p-3.5 rounded-xl border border-gray-200/80 shadow-2xs space-y-1">
                            <span className="text-[11px] text-gray-400 font-bold block flex items-center gap-1">
                              <Smartphone className="w-3.5 h-3.5 text-gray-400" />
                              <span>મોબાઈલ નંબર</span>
                            </span>
                            <p className="text-sm font-extrabold text-deep-indigo font-mono">
                              {req.mobileNumber.startsWith('X') ? (
                                <span>{req.mobileNumber}</span>
                              ) : (
                                <a href={`tel:${req.mobileNumber}`} className="hover:underline hover:text-field-green">
                                  {req.mobileNumber}
                                </a>
                              )}
                            </p>
                          </div>

                          {/* Requested Service */}
                          <div className="bg-white p-3.5 rounded-xl border border-gray-200/80 shadow-2xs space-y-1">
                            <span className="text-[11px] text-gray-400 font-bold block flex items-center gap-1">
                              <Layers className="w-3.5 h-3.5 text-gray-400" />
                              <span>સેવા પ્રકાર / કેટેગરી</span>
                            </span>
                            <p className="text-sm font-extrabold text-field-green truncate">{req.category}</p>
                          </div>

                          {/* Address / Location */}
                          <div className="bg-white p-3.5 rounded-xl border border-gray-200/80 shadow-2xs space-y-1 sm:col-span-2">
                            <span className="text-[11px] text-gray-400 font-bold block flex items-center gap-1">
                              <MapPin className="w-3.5 h-3.5 text-gray-400" />
                              <span>સરનામું / સ્થળ</span>
                            </span>
                            <p className="text-xs sm:text-sm font-bold text-gray-800">
                              ગામ: <strong className="text-deep-indigo">{req.village}</strong>, તાલુકો: <strong className="text-deep-indigo">{req.taluka}</strong>, જીલ્લો: <strong className="text-deep-indigo">{req.district}</strong>
                            </p>
                          </div>

                          {/* Registration Date */}
                          <div className="bg-white p-3.5 rounded-xl border border-gray-200/80 shadow-2xs space-y-1">
                            <span className="text-[11px] text-gray-400 font-bold block flex items-center gap-1">
                              <Calendar className="w-3.5 h-3.5 text-gray-400" />
                              <span>સબમિશન તારીખ</span>
                            </span>
                            <p className="text-xs font-bold text-gray-700 font-mono">{req.createdAt || 'નોંધાયેલ'}</p>
                          </div>

                        </div>

                        {/* Customer Special Message / Instructions */}
                        {req.message && req.message.trim() !== '' && (
                          <div className="mt-3.5 bg-white p-3.5 rounded-xl border border-gray-200/80 shadow-2xs space-y-1">
                            <span className="text-[11px] text-gray-400 font-bold block">ગ્રાહકનો સંદેશ / વિશેષ નોંધ:</span>
                            <p className="text-xs text-gray-700 italic">"{req.message}"</p>
                          </div>
                        )}

                      </div>

                      {/* 6. BOTTOM ACTION CONTROLS */}
                      <div className="p-4 sm:p-5 bg-white border-t border-gray-100 flex flex-col sm:flex-row items-center justify-between gap-3">
                        
                        <div className="text-xs text-gray-500 font-semibold text-center sm:text-left">
                          પ્રશ્ન અથવા સહાયતા માટે સંપર્ક કરો: <strong className="text-deep-indigo">+91 97260 74581</strong>
                        </div>

                        <div className="flex items-center gap-2.5 w-full sm:w-auto">
                          <button
                            type="button"
                            onClick={handlePrint}
                            className="hidden sm:inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-bold rounded-xl transition-all cursor-pointer"
                            title="સ્ટેટસ પેજ પ્રિન્ટ કરો"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>પ્રિન્ટ (Print)</span>
                          </button>

                          <a
                            href={buildWhatsAppLink(SITE_CONFIG.whatsapp.getApplicationQueryMessage(req.id))}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-field-green hover:bg-field-green/90 text-white text-xs font-bold rounded-xl shadow-md shadow-field-green/20 transition-all cursor-pointer"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>વોટ્સએપ પર સપોર્ટ મેળવો</span>
                          </a>
                        </div>

                      </div>

                    </div>

                  </div>
                );
              })
            ) : (
              /* EMPTY / NOT FOUND ERROR STATE */
              <div className="bg-white rounded-2xl border border-rose-200/80 p-8 sm:p-10 shadow-lg shadow-rose-500/5 text-center space-y-5 transition-all">
                
                <div className="w-16 h-16 rounded-2xl bg-rose-50 text-rose-600 border border-rose-200 flex items-center justify-center mx-auto shadow-xs">
                  <AlertCircle className="w-8 h-8" />
                </div>

                <div className="space-y-2 max-w-md mx-auto">
                  <h3 className="text-xl font-heading font-black text-gray-900">
                    અરજી મળી નથી અથવા માહિતી ખોટી છે.
                  </h3>
                  <p className="text-xs sm:text-sm text-gray-600 leading-relaxed font-medium">
                    કૃપા કરીને સાચો <strong className="text-deep-indigo">૧૦-આંકડાનો મોબાઇલ નંબર</strong> અને સાચો <strong className="text-deep-indigo">અરજી ID</strong> દાખલ કરો.
                  </p>
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 max-w-md mx-auto text-left space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900">
                    <HelpCircle className="w-4 h-4 text-turmeric-gold shrink-0" />
                    <span>મદદરૂપ સૂચનાઓ:</span>
                  </div>
                  <ul className="text-[11px] text-amber-800 list-disc pl-5 space-y-0.5 font-medium">
                    <li>અરજી ID તમારી સબમિશન રસીદ પર <code className="font-bold bg-white px-1 rounded">SKN...</code> ફોર્મેટમાં લખાયેલ છે.</li>
                    <li>મોબાઇલ નંબર ફોર્મ ભરતી વખતે આપેલો જ હોવો જોઈએ.</li>
                  </ul>
                </div>

                <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
                  <button
                    type="button"
                    onClick={handleResetSearch}
                    className="w-full sm:w-auto px-6 py-3 bg-deep-indigo hover:bg-deep-indigo/95 text-white font-bold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-2 shadow-sm"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>ફરીથી પ્રયાસ કરો (Try Again)</span>
                  </button>

                  <a
                    href={buildWhatsAppLink(SITE_CONFIG.whatsapp.getTrackingHelpMessage())}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full sm:w-auto px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <span>વોટ્સએપ હેલ્પલાઈન</span>
                  </a>
                </div>

              </div>
            )}

          </div>
        )}

      </div>
    </section>
  );
}

