import React, { useState } from 'react';
import { SERVICES } from '../utils/mockData';
import { ServiceItem } from '../types';
import * as Icons from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { SITE_CONFIG, buildWhatsAppLink } from '../config/siteConfig';

interface ServicesProps {
  onApplyForService: (serviceName: string) => void;
}

// Icon rendering helper mapped from Lucide-react
function renderServiceIcon(iconName: string, className: string = 'w-6 h-6') {
  const IconComponent = (Icons as any)[iconName];
  if (!IconComponent) {
    return <Icons.Layers className={className} />;
  }
  return <IconComponent className={className} />;
}

export default function Services({ onApplyForService }: ServicesProps) {
  const [searchTerm, setSearchTerm] = useState('');

  // Search filter logic
  const filteredServices = SERVICES.filter((service) => {
    const term = searchTerm.toLowerCase().trim();
    if (!term) return true;
    return (
      service.gujaratiTitle.toLowerCase().includes(term) ||
      service.title.toLowerCase().includes(term) ||
      service.description.toLowerCase().includes(term)
    );
  });

  return (
    <section id="services" className="py-16 lg:py-24 bg-white relative border-b border-deep-indigo/10">

      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-deep-indigo/10 text-deep-indigo rounded-md text-xs font-bold border border-deep-indigo/15">
            <Icons.Layers className="w-3.5 h-3.5 text-turmeric-gold" />
            <span>અમારી શ્રેષ્ઠ ઓનલાઈન સેવાઓ</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-heading font-bold text-deep-indigo">
            લોકપ્રિય ડિજિટલ સેવાઓ
          </h2>
          <p className="text-warm-gray text-sm sm:text-base">
            નીચે આપેલી કોઈપણ સેવા માટે ઘરે બેઠા અરજી કરો. માત્ર ફોર્મ સબમિટ કરો અને બાકીનું કામ અમારા પર છોડો.
          </p>
        </div>

        {/* Search Input Field */}
        <div className="max-w-md mx-auto mb-10">
          <div className="relative group">
            <Icons.Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-warm-gray" />
            <input
              type="text"
              id="services-search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="સેવાઓ શોધો... (દા.ત. આધાર, પાન, આયુષ્માન)"
              className="gov-input pl-12 pr-10 text-sm font-semibold text-deep-indigo placeholder-warm-gray w-full"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="min-w-[44px] min-h-[44px] absolute right-1 top-1/2 -translate-y-1/2 text-warm-gray hover:text-deep-indigo transition-colors duration-150 cursor-pointer flex items-center justify-center"
                title="સાફ કરો"
              >
                <Icons.X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Services Grid with AnimatePresence */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 min-h-[200px]">
          <AnimatePresence mode="popLayout">
            {filteredServices.map((service: ServiceItem) => {
              return (
                <motion.div
                  layout
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  transition={{ duration: 0.12 }}
                  key={service.id}
                  className="p-5 sm:p-6 rounded-sm flex flex-col justify-between transition-colors duration-150 relative group bg-white border border-deep-indigo/15 hover:border-turmeric-gold shadow-2xs"
                >
                  <div className="space-y-3.5">
                    {/* Icon with solid deep indigo background and official square styling */}
                    <div className="w-11 h-11 rounded-sm bg-deep-indigo flex items-center justify-center text-white border border-turmeric-gold/30 shadow-xs">
                      {renderServiceIcon(service.iconName, 'w-5 h-5 text-white')}
                    </div>

                    <div className="space-y-1.5">
                      <h3 className="text-base sm:text-lg font-heading font-black text-deep-indigo group-hover:text-turmeric-gold transition-colors duration-150">
                        {service.gujaratiTitle}
                      </h3>
                      <p className="text-warm-gray text-xs sm:text-sm leading-relaxed font-semibold">
                        {service.description}
                      </p>
                    </div>
                  </div>

                  <div className="pt-4 mt-4 border-t border-deep-indigo/10 flex items-center justify-between gap-2">
                    <span className="text-[10px] sm:text-[11px] font-bold text-deep-indigo bg-wheat-cream/70 px-2 py-1 rounded-sm border border-deep-indigo/10">
                      ઓનલાઇન સેવા
                    </span>
                    
                    <button
                      onClick={() => onApplyForService(service.gujaratiTitle)}
                      className="gov-btn-primary min-h-[40px] px-3.5 py-1.5 text-xs font-bold rounded-sm cursor-pointer inline-flex items-center gap-1.5"
                    >
                      <span>અરજી કરો</span>
                      <Icons.ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>

        {/* Empty State when no service matches */}
        {filteredServices.length === 0 && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-12 max-w-md mx-auto space-y-4"
          >
            <div className="w-16 h-16 rounded-md bg-turmeric-gold/10 text-turmeric-gold border border-turmeric-gold/12 flex items-center justify-center mx-auto">
              <Icons.AlertCircle className="w-8 h-8" />
            </div>
            <div className="space-y-1 px-4">
              <p className="font-heading font-bold text-deep-indigo text-base">આ નામની કોઈ સેવા મળી નથી</p>
              <p className="text-xs text-warm-gray font-semibold leading-relaxed">
                કૃપા કરીને અન્ય શબ્દોનો ઉપયોગ કરો અથવા નીચે આપેલા બટન પર ક્લિક કરીને અમને વોટ્સએપ પર તમારી જરૂરિયાત જણાવો.
              </p>
            </div>
            <a
              href={buildWhatsAppLink('નમસ્તે STAR KING NETWORK, મને એક સેવા વિશે જાણવું છે જે લિસ્ટમાં નથી.')}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-5 py-2.5 bg-field-green hover:bg-field-green/90 active:bg-field-green/80 text-white font-semibold text-xs rounded-md transition-colors duration-150 cursor-pointer"
            >
              <Icons.MessageCircle className="w-4 h-4 fill-current" />
              વોટ્સએપ પર પૂછો
            </a>
          </motion.div>
        )}

        {/* Support Callout banner with flat design */}
        <div className="mt-16 bg-wheat-cream/40 border border-deep-indigo/12 p-8 rounded-md flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <h4 className="text-lg font-heading font-bold text-deep-indigo">શું તમને જરૂરી સેવા યાદીમાં મળતી નથી?</h4>
            <p className="text-xs sm:text-sm text-warm-gray font-semibold">કોઈ ચિંતા ન કરશો! અમારો સંપર્ક કરો, અમે કોઈપણ ઓનલાઈન દસ્તાવેજ કે સેવાના ફોર્મ ભરવામાં તમારી સહાય કરીશું.</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 shrink-0 items-center">
            <span className="text-[10px] font-bold text-brick-red bg-brick-red/10 border border-brick-red/12 px-2 py-1 rounded-md">
              * માત્ર વોટ્સએપ પર જ કોલ / મેસેજ કરવો
            </span>
            <div className="flex gap-2 w-full sm:w-auto">
              <a
                href={SITE_CONFIG.whatsapp.groupInviteUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto text-center px-4 py-2.5 bg-deep-indigo hover:bg-deep-indigo-hover active:bg-deep-indigo-active text-white border border-transparent hover:border-turmeric-gold font-semibold text-xs rounded-md transition-colors duration-150 cursor-pointer"
              >
                વોટ્સએપ ગ્રુપ લિંક
              </a>
              <a
                href={buildWhatsAppLink('નમસ્તે STAR KING NETWORK, મારી પાસે એક કસ્ટમ ઓનલાઈન ફોર્મ ભરવાનું કામ છે.')}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-4 py-2.5 bg-field-green hover:bg-field-green/90 active:bg-field-green/80 text-white font-semibold text-xs rounded-md transition-colors duration-150 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Icons.MessageCircle className="w-4 h-4 fill-current" />
                વોટ્સએપ મેસેજ / કોલ
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
