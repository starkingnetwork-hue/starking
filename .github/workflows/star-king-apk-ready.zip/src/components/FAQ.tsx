import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
}

export default function FAQ() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const faqs: FAQItem[] = [
    {
      question: 'સ્ટાર કિંગ નેટવર્ક કઈ-કઈ સેવાઓ પ્રદાન કરે છે?',
      answer: 'અમે આધાર કાર્ડ સુધારો, નવું પાન કાર્ડ, આવક અને જાતિના દાખલા, પીએમ કિસાન યોજના, આયુષ્માન ભારત કાર્ડ, વિવિધ શિષ્યવૃત્તિ ફોર્મ, ૭/૧૨ ના ઉતારા અને રેશન કાર્ડ જેવી તમામ જરૂરી ઓનલાઇન સેવાઓ પૂરી પાડીએ છીએ.',
    },
    {
      // What is the status of government relation
      question: 'શું આ કોઈ સરકારી સંસ્થા છે?',
      answer: 'ના, સ્ટાર કિંગ નેટવર્ક (STAR KING NETWORK) એ સંપૂર્ણપણે ખાનગી ડિજિટલ સેવા કેન્દ્ર છે. અમે કોઈપણ સરકારી સંસ્થા કે વિભાગ સાથે જોડાયેલા નથી. અમે સત્તાવાર વેબસાઇટ્સના માધ્યમથી નાગરિકોને સરળતાથી ઓનલાઇન ફોર્મ ભરવામાં મદદરૂપ થઈએ છીએ.',
    },
    {
      question: 'અરજી કર્યા પછી સ્ટેટસ કઈ રીતે જાણી શકાય?',
      answer: 'ફોર્મ સબમિટ થતાં જ તમને એક વિશિષ્ટ અરજી ID (દા.ત. #SKN000001) ફાળવવામાં આવશે. તમે અમારી વેબસાઇટ પર "અરજી સ્ટેટસ ચેક" ટેબમાં જઈને તમારો મોબાઈલ નંબર અને અરજી ID દાખલ કરીને સ્ટેટસ રીઅલ-ટાઇમ ચેક કરી શકો છો.',
    },
    {
      question: 'મારે મારા દસ્તાવેજો (Documents) કઈ રીતે મોકલવા?',
      answer: 'અહીં ઓનલાઇન માહિતી સબમિટ કર્યા બાદ સફળતાના પેજ પર આપેલા "વોટ્સએપ પર દસ્તાવેજ મોકલો" બટન પર ક્લિક કરો. તેનાથી અમારો વોટ્સએપ ચેટ બોક્સ ખુલશે, જ્યાં તમે સુરક્ષિત રીતે આધાર કાર્ડ કે અન્ય જરૂરી પુરાવાના ફોટો મોકલી શકો છો.',
    },
    {
      question: 'શું મારા દસ્તાવેજો અને માહિતી સુરક્ષિત રહેશે?',
      answer: 'હા, ૧૦૦%. સ્ટાર કિંગ નેટવર્ક ગ્રાહકોની પ્રાઈવસી અને ડેટા સુરક્ષાને સૌથી વધુ પ્રાધાન્ય આપે છે. તમારા અંગત દસ્તાવેજો માત્ર સંબંધિત ફોર્મ પ્રક્રિયા માટે જ વાપરવામાં આવે છે અને કામ પૂરું થયા બાદ તેનો દુરુપયોગ કે અન્ય કોઈ સાથે શેરિંગ ક્યારેય કરવામાં આવતું નથી.',
    }
  ];

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-16 sm:py-24 bg-wheat-cream/30 border-b border-deep-indigo/10">
      <div className="max-w-[800px] mx-auto px-4 sm:px-6">
        
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-deep-indigo/10 text-deep-indigo rounded-md text-xs font-bold border border-deep-indigo/15">
            <HelpCircle className="w-3.5 h-3.5 text-turmeric-gold" />
            <span>પ્રશ્નોત્તરી (FAQ)</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-heading font-bold text-deep-indigo">
            વારંવાર પુછાતા પ્રશ્નો
          </h2>
          <p className="text-warm-gray text-sm sm:text-base">
            તમારા મનમાં ઉઠતા સામાન્ય મૂંઝવણો અને સવાલોના અહીં સરળ જવાબો મેળવો:
          </p>
        </div>

        {/* Modern Flat Accordion */}
        <div className="space-y-4">
          {faqs.map((faq, index) => {
            const isOpen = activeIndex === index;
            return (
              <div 
                key={index} 
                className="bg-white border border-deep-indigo/12 rounded-md overflow-hidden transition-all duration-150"
              >
                <button
                  type="button"
                  onClick={() => toggleAccordion(index)}
                  className="w-full px-6 py-5 flex items-center justify-between gap-4 text-left font-heading font-bold text-deep-indigo hover:text-turmeric-gold transition-colors duration-150 cursor-pointer"
                >
                  <span className="text-sm sm:text-base">{faq.question}</span>
                  <ChevronDown className={`w-5 h-5 shrink-0 text-warm-gray transition-transform duration-150 ${isOpen ? 'rotate-180 text-turmeric-gold' : ''}`} />
                </button>
                
                {isOpen && (
                  <div className="px-6 pb-5 pt-1 text-warm-gray text-xs sm:text-sm font-semibold border-t border-deep-indigo/5 leading-relaxed bg-wheat-cream/10">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
