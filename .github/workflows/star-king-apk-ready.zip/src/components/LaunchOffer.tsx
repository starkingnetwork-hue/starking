import React from 'react';
import { Tag, HelpCircle, AlertCircle } from 'lucide-react';

interface LaunchOfferProps {
  onFormScroll: () => void;
}

export default function LaunchOffer({ onFormScroll }: LaunchOfferProps) {
  return (
    <section id="launch-offer" className="py-12 lg:py-16 bg-wheat-cream/30 border-t border-b border-deep-indigo/10 relative">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 md:mb-12 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-turmeric-gold/10 text-turmeric-gold rounded-md text-xs font-bold border border-turmeric-gold/15">
            <Tag className="w-3.5 h-3.5 shrink-0" />
            <span>મર્યાદિત સમય માટે વિશેષ ઓફર</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-heading font-bold text-deep-indigo">
            🏷️ લોન્ચ ઓફર
          </h2>
          <p className="text-warm-gray text-sm sm:text-base font-semibold">
            સ્ટાર કિંગ કનેક્ટ પર સૌથી ઓછા ચાર્જમાં શ્રેષ્ઠ સેવાઓનો ઓનલાઈન લાભ લો
          </p>
        </div>

        {/* Outer Premium Card (Flat design, 2-column bento style on desktop) */}
        <div className="max-w-4xl mx-auto bg-white border border-deep-indigo/12 rounded-xl overflow-hidden shadow-sm flex flex-col md:flex-row">
          
          {/* Left Column: Pricing, Badge & Bullet list of services included */}
          <div className="flex-1 p-6 sm:p-10 flex flex-col justify-between border-b md:border-b-0 md:border-r border-deep-indigo/12 bg-white">
            <div className="space-y-6">
              {/* Premium Badge */}
              <div className="inline-block px-3 py-1 bg-brick-red/10 border border-brick-red/15 text-brick-red text-xs font-black tracking-wider rounded">
                LIMITED TIME OFFER
              </div>

              {/* Pricing Blocks */}
              <div className="space-y-2">
                <div className="text-warm-gray text-sm font-bold">
                  જૂનો સેવા ચાર્જ: <span className="line-through text-brick-red font-bold text-lg ml-1">₹210</span>
                </div>
                <div>
                  <div className="text-4xl sm:text-5xl font-heading font-black text-field-green tracking-tight leading-none">
                    🔥 માત્ર ₹99
                  </div>
                </div>
              </div>

              {/* Value list items */}
              <div className="space-y-3 pt-2 text-left">
                {[
                  'ઓનલાઈન અરજી',
                  'દસ્તાવેજોની ચકાસણી',
                  'અરજી સબમિટ',
                  'Application ID',
                  'અરજી સ્ટેટસ'
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2.5 font-bold text-sm text-deep-indigo">
                    <span className="text-base shrink-0">✅</span>
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Large Call to Action Button */}
            <div className="pt-8">
              <button
                onClick={onFormScroll}
                className="w-full py-4 bg-deep-indigo hover:bg-deep-indigo-hover active:bg-deep-indigo-active text-white font-bold rounded-lg transition-colors duration-150 flex items-center justify-center gap-2 cursor-pointer text-base shadow-sm border border-transparent"
              >
                <span>🚀 માત્ર ₹99 માં અરજી કરો</span>
              </button>
            </div>
          </div>

          {/* Right Column: Process Information Box and Important Disclaimer Notice */}
          <div className="flex-1 p-6 sm:p-10 bg-wheat-cream/15 flex flex-col justify-between space-y-6">
            
            {/* Information Process Box */}
            <div className="space-y-4 text-left">
              <h3 className="text-base font-heading font-bold text-deep-indigo flex items-center gap-2 border-b border-deep-indigo/10 pb-2">
                <span className="text-lg shrink-0">📢</span>
                <span>અરજી પ્રક્રિયા</span>
              </h3>
              
              <ol className="space-y-2.5 text-xs sm:text-sm font-semibold text-warm-gray pl-5 list-decimal leading-relaxed">
                <li><span className="text-deep-indigo">Website</span> પર અરજી કરો.</li>
                <li>અરજી સબમિટ કરો.</li>
                <li>તમને <span className="text-deep-indigo">Application ID</span> મળશે.</li>
                <li><span className="text-field-green">WhatsApp</span> આપમેળે ખુલશે.</li>
                <li>જરૂરી દસ્તાવેજો મોકલો.</li>
                <li>અમારી ટીમ દસ્તાવેજો ચકાસશે.</li>
                <li>સેવા ચાર્જ <span className="text-field-green">WhatsApp</span> દ્વારા લેવામાં આવશે.</li>
                <li>ત્યારબાદ અરજીની પ્રક્રિયા શરૂ કરવામાં આવશે.</li>
              </ol>
            </div>

            {/* Important Notice Flat Box */}
            <div className="p-4 bg-brick-red/5 border border-brick-red/12 rounded-lg text-left space-y-2">
              <h4 className="text-xs font-bold text-brick-red flex items-center gap-1.5 uppercase tracking-wider">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>મહત્વપૂર્ણ સૂચના (Important Notice)</span>
              </h4>
              <ul className="space-y-1.5 text-xs text-warm-gray font-bold pl-4 list-disc leading-relaxed">
                <li>Website પર કોઈ Online Payment લેવામાં આવતું નથી.</li>
                <li>Payment માત્ર WhatsApp દ્વારા લેવામાં આવશે.</li>
                <li>કેટલીક સેવાઓમાં સરકારની ફી અલગથી લાગુ પડી શકે છે.</li>
              </ul>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
