import React from 'react';
import { ShieldCheck, MessageCircle, FileText, CheckCircle2, Award, Users, Smartphone } from 'lucide-react';
import { SITE_CONFIG, buildWhatsAppLink } from '../config/siteConfig';

interface HeroProps {
  onFormScroll: () => void;
  onTrackingScroll: () => void;
}

export default function Hero({ onFormScroll, onTrackingScroll }: HeroProps) {
  // Statistics items with flat design and thin borders
  const formattedStats = [
    { value: '૧૫,૦૦૦+', label: 'સફળતાપૂર્વક ભરેલા ફોર્મ', icon: FileText, color: 'text-deep-indigo' },
    { value: '૯૯.૮%', label: 'ચોકસાઈ અને સફળતા દર', icon: CheckCircle2, color: 'text-field-green' },
    { value: '૫૦+', label: 'ઓનલાઈન અને સરકારી સેવાઓ', icon: Award, color: 'text-turmeric-gold' },
    { value: '૧૦,૦૦૦+', label: 'વિશ્વાસુ ગ્રાહકો', icon: Users, color: 'text-deep-indigo' },
  ];

  return (
    <section id="home" className="relative overflow-hidden py-16 lg:py-24 bg-wheat-cream border-b border-deep-indigo/10">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Hero text side */}
          <div className="lg:col-span-7 space-y-8 text-center lg:text-left">
            
            {/* Minimal flat badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-sm bg-white border border-deep-indigo/15 text-deep-indigo text-xs font-bold uppercase mx-auto lg:mx-0 shadow-2xs">
              <ShieldCheck className="w-4 h-4 text-turmeric-gold shrink-0" />
              <span>૧૦૦% સચોટ, ભરોસાપાત્ર અને ઝડપી ડિજિટલ સેવાઓ</span>
            </div>

            {/* Standard Large Heading & Subtitle */}
            <div className="space-y-3 sm:space-y-4">
              <h1 className="text-2xl sm:text-4xl lg:text-5xl font-heading font-black leading-tight text-deep-indigo tracking-tight">
                ગુજરાતની વિશ્વસનીય ઓનલાઈન સેવા
              </h1>
              <p className="text-sm sm:text-base lg:text-lg font-medium text-warm-gray leading-relaxed max-w-xl mx-auto lg:mx-0">
                સરકારી અને અન્ય ઓનલાઈન સેવાઓ માટે સરળ, ઝડપી અને સુરક્ષિત પ્લેટફોર્મ.
              </p>
            </div>

            {/* Premium, flat, high-contrast action buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center lg:justify-start gap-3 pt-2">
              <button
                onClick={onFormScroll}
                className="gov-btn-primary w-full sm:w-auto min-h-[48px] px-6 py-3 text-sm sm:text-base"
              >
                <span>🚀 અરજી કરો</span>
              </button>
              
              <button
                onClick={onTrackingScroll}
                className="gov-btn-secondary w-full sm:w-auto min-h-[48px] px-6 py-3 text-sm sm:text-base"
              >
                <span>🔍 અરજી સ્ટેટસ તપાસો</span>
              </button>

              <a
                href={buildWhatsAppLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="gov-btn-green w-full sm:w-auto min-h-[48px] px-5 py-3 text-sm sm:text-base"
              >
                <MessageCircle className="w-5 h-5 fill-current shrink-0" />
                <span>વોટ્સએપ હેલ્પલાઈન</span>
              </a>
            </div>

            {/* Live WhatsApp Group banner/link */}
            <div className="pt-2 flex flex-wrap items-center justify-center lg:justify-start gap-2.5 sm:gap-4 text-xs font-semibold">
              <span className="text-brick-red bg-brick-red/10 px-3 py-1.5 rounded-sm border border-brick-red/20 flex items-center gap-1.5 text-[11px] sm:text-xs">
                <span className="w-2 h-2 rounded-full bg-brick-red animate-pulse shrink-0"></span>
                માત્ર વોટ્સએપ મેસેજ અથવા કોલ કરવો. સાદો ફોન કોલ બંધ છે.
              </span>
              <a
                href={SITE_CONFIG.whatsapp.groupInviteUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-deep-indigo hover:text-turmeric-gold border-b-2 border-turmeric-gold pb-0.5 font-bold text-xs sm:text-sm"
              >
                અમારા વોટ્સએપ ગ્રુપમાં જોડાઓ →
              </a>
            </div>

          </div>

          {/* Graphic Side - Premium Minimal Flat Card Panel */}
          <div className="lg:col-span-5 flex justify-center">
            
            <div className="w-full max-w-sm bg-white border border-deep-indigo/12 rounded-md p-6 sm:p-8 space-y-6 shadow-sm relative">
              
              {/* Star King Digital Brand Badge */}
              <div className="text-center space-y-4">
                <img 
                  src="/star_king_logo.png" 
                  alt="STAR KING NETWORK" 
                  className="star-king-hero-logo"
                />
                <div>
                  <h3 className="font-heading font-black text-deep-indigo text-xl">સ્ટાર કિંગ નેટવર્ક</h3>
                  <p className="text-xs text-warm-gray font-semibold">દરેક ડિજિટલ સેવાનું એકમાત્ર વિશ્વસનીય સરનામું</p>
                </div>
                <div className="inline-flex gap-1.5 items-center justify-center px-3 py-1 bg-field-green/10 text-field-green rounded-md text-xs font-bold border border-field-green/20">
                  <span className="w-2 h-2 rounded-full bg-field-green"></span>
                  ઓનલાઇન સેવા ચાલુ છે
                </div>
              </div>

              {/* Bullet Quick Features */}
              <div className="space-y-3.5 border-t border-deep-indigo/10 pt-5 text-sm font-semibold text-deep-indigo">
                <div className="flex gap-2.5 items-start">
                  <CheckCircle2 className="w-5 h-5 text-field-green shrink-0 mt-0.5" />
                  <span>ઘરે બેઠા તમામ ઓનલાઇન ફોર્મ સબમિશન</span>
                </div>
                <div className="flex gap-2.5 items-start">
                  <CheckCircle2 className="w-5 h-5 text-field-green shrink-0 mt-0.5" />
                  <span>દસ્તાવેજો અને માહિતીની ૧૦૦% ગોપનીયતા</span>
                </div>
                <div className="flex gap-2.5 items-start">
                  <CheckCircle2 className="w-5 h-5 text-field-green shrink-0 mt-0.5" />
                  <span>વિનંતી સબમિટ કરી ઓનલાઇન સ્ટેટસ ટ્રેકિંગ</span>
                </div>
              </div>

            </div>

          </div>

        </div>

        {/* Counter Statistics Bar - Minimal Flat Design */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 bg-white border border-deep-indigo/12 rounded-md p-6 sm:p-8">
          {formattedStats.map((stat, idx) => {
            const IconComponent = stat.icon;
            return (
              <div key={idx} className="text-center p-3 sm:p-4 rounded-md hover:bg-wheat-cream/30 transition-colors duration-150">
                <div className="flex justify-center mb-2">
                  <IconComponent className={`w-8 h-8 ${stat.color}`} />
                </div>
                <p className="text-2xl sm:text-3xl font-heading font-bold text-deep-indigo">{stat.value}</p>
                <p className="text-xs sm:text-sm font-semibold text-warm-gray mt-1">{stat.label}</p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
