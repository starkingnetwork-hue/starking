import React, { useState, useEffect } from 'react';
import { 
  Building, 
  CheckCircle, 
  Check, 
  ShieldCheck, 
  Scale, 
  Receipt, 
  Info, 
  AlertTriangle, 
  Lock, 
  Sparkles, 
  HelpCircle, 
  ExternalLink,
  ChevronDown,
  ChevronUp,
  X,
  Heart,
  Bot
} from 'lucide-react';
import PolicyCard, { PolicyType } from './PolicyCard';
import ContactCard from './ContactCard';
import ServiceGuideCard from './ServiceGuideCard';
import DisclaimerCard from './DisclaimerCard';
import ImportantLinks from './ImportantLinks';

interface AboutPoliciesPageProps {
  onNavigate: (screen: 'home' | 'services' | 'form' | 'track' | 'about-policies') => void;
  initialTab?: string;
}

export default function AboutPoliciesPage({ onNavigate, initialTab }: AboutPoliciesPageProps) {
  const [selectedPolicy, setSelectedPolicy] = useState<PolicyType | null>(null);

  useEffect(() => {
    if (initialTab && (initialTab === 'privacy' || initialTab === 'terms' || initialTab === 'refund' || initialTab === 'about')) {
      setSelectedPolicy(initialTab as PolicyType);
      const element = document.getElementById('policies-section');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    } else if (initialTab === 'contact') {
      const element = document.getElementById('contact-section');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [initialTab]);

  const policiesData: Record<PolicyType, {
    title: string;
    englishTitle: string;
    badge: string;
    summary: string;
    icon: typeof ShieldCheck;
    fullContent: React.ReactNode;
  }> = {
    privacy: {
      title: 'ગોપનીયતા નીતિ',
      englishTitle: 'Privacy Policy',
      badge: '૧૦૦% સુરક્ષિત ડેટા',
      summary: 'તમારા અંગત દસ્તાવેજો અને માહિતીની સંપૂર્ણ ગુપ્તતા અને સુરક્ષાની ખાતરી.',
      icon: ShieldCheck,
      fullContent: (
        <div className="space-y-4 text-xs sm:text-sm text-gray-700 leading-relaxed">
          <div className="bg-field-green/10 border border-field-green/20 rounded-xl p-4 flex gap-3 items-start">
            <ShieldCheck className="w-5 h-5 text-field-green shrink-0 mt-0.5" />
            <p className="text-gray-800 font-semibold">
              <strong>STAR KING NETWORK</strong> તમારા દ્વારા આપવામાં આવેલી તમામ માહિતી અને દસ્તાવેજોની ગોપનીયતા અને સુરક્ષા જાળવવા માટે સંપૂર્ણપણે પ્રતિબદ્ધ છે.
            </p>
          </div>

          <div className="space-y-2">
            <h5 className="font-heading font-black text-deep-indigo text-sm">૧. અમે નીચેની માહિતી મેળવી શકીએ છીએ:</h5>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {['નામ (Applicant Name)', 'મોબાઇલ નંબર', 'સરનામું (Address)', 'ગામ / તાલુકો / જિલ્લો', 'સેવા સંબંધી માહિતી', 'જરૂરી સરકારી દસ્તાવેજો'].map((item, i) => (
                <div key={i} className="p-2.5 bg-gray-50 rounded-lg border border-gray-200 text-xs font-bold text-gray-700">
                  {item}
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <h5 className="font-heading font-black text-deep-indigo text-sm">૨. માહિતીનો સત્તાવાર ઉપયોગ:</h5>
            <ul className="space-y-1.5 text-xs sm:text-sm font-medium">
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4 text-field-green shrink-0" />
                <span>ગ્રાહકની વિનંતી મુજબ સરકારી પોર્ટલ પર ફોર્મ ભરવા અને પ્રક્રિયા કરવા માટે.</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4 text-field-green shrink-0" />
                <span>અરજીની સ્થિતિ (Application Status) અંગે વોટ્સએપ પર ગ્રાહકને અપડેટ મોકલવા.</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4 text-field-green shrink-0" />
                <span>કોઈપણ ભૂલ વિના સચોટ ઓનલાઇન સબમિશન સુનિશ્ચિત કરવા.</span>
              </li>
            </ul>
          </div>

          <div className="bg-wheat-cream/40 p-4 rounded-xl border border-deep-indigo/15 space-y-1.5">
            <h5 className="font-heading font-black text-deep-indigo flex items-center gap-1.5 text-xs sm:text-sm">
              <Lock className="w-4 h-4 text-field-green" />
              <span>ડેટા સુરક્ષા બાંહેધરી (Data Protection Guarantee):</span>
            </h5>
            <p className="text-xs text-gray-600 font-medium leading-relaxed">
              અમે તમારી માહિતી કોઈપણ તૃતીય પક્ષને વેચતા નથી, ભાડે આપતા નથી કે જાહેરાત હેતુઓ માટે શેર કરતા નથી. તમામ દસ્તાવેજો માત્ર સંબંધિત અરજી પૂર્ણ કરવા પૂરતા જ ઉપયોગમાં લેવાય છે.
            </p>
          </div>
        </div>
      )
    },
    terms: {
      title: 'નિયમો અને શરતો',
      englishTitle: 'Terms & Conditions',
      badge: 'સેવા કરાર',
      summary: 'પ્લેટફોર્મ ઉપયોગ, અરજી પ્રક્રિયા, અને ગ્રાહક જવાબદારીઓના સ્પષ્ટ નિયમો.',
      icon: Scale,
      fullContent: (
        <div className="space-y-4 text-xs sm:text-sm text-gray-700 leading-relaxed">
          <div className="bg-turmeric-gold/10 border border-turmeric-gold/30 rounded-xl p-4 text-gray-800 font-semibold">
            STAR KING NETWORK નો ઉપયોગ કરતા પહેલા નીચેની શરતો કાળજીપૂર્વક વાંચવી અને સ્વીકારવી જરૂરી છે:
          </div>

          <div className="space-y-2.5">
            {[
              'અમારી સેવાઓનો ઉપયોગ માત્ર કાયદેસર અને સત્તાવાર સરકારી સેવા સહાય હેતુ માટે જ કરવો.',
              'અરજી અથવા ફોર્મ ભરવા માટે ગ્રાહક દ્વારા આપવામાં આવેલી તમામ માહિતી અને દસ્તાવેજો સાચા અને કાયદેસર હોવા જોઈએ.',
              'ખોટી માહિતી અથવા નકલી દસ્તાવેજો આપવા બદલ તેની સંપૂર્ણ કાનૂની જવાબદારી ગ્રાહકની રહેશે.',
              'કોઈપણ સરકારી યોજના અથવા સરકારી નોકરીની અરજી મંજૂર થવાની ગેરંટી STAR KING NETWORK આપતું નથી.',
              'સરકારી નિયમો, પાત્રતા ધોરણો અને સરકારી અરજી પર અંતિમ નિર્ણય સંબંધિત સરકારી વિભાગનો રહેશે.',
              'સરકારી નિયમો અનુસાર પોર્ટલ ફી અથવા પ્રક્રિયાઓમાં ફેરફાર થઈ શકે છે.'
            ].map((term, idx) => (
              <div key={idx} className="flex gap-2.5 bg-gray-50/80 p-3 rounded-xl border border-gray-200 text-left">
                <span className="w-5 h-5 rounded-md bg-deep-indigo text-white text-xs font-black flex items-center justify-center shrink-0">
                  {idx + 1}
                </span>
                <span className="text-xs sm:text-sm font-semibold text-gray-800">{term}</span>
              </div>
            ))}
          </div>
        </div>
      )
    },
    refund: {
      title: 'રિફંડ પોલિસી',
      englishTitle: 'Refund Policy',
      badge: 'પારદર્શક નીતિ',
      summary: 'ઓનલાઈન સેવા શુલ્ક, અરજી પ્રક્રિયા અને રિફંડ સંબંધિત પારદર્શક નિયમો.',
      icon: Receipt,
      fullContent: (
        <div className="space-y-4 text-xs sm:text-sm text-gray-700 leading-relaxed">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-amber-950 font-semibold">
            અમારો હેતુ ગ્રાહકોને ઉત્તમ અને સચોટ ઓનલાઇન સહાય પૂરી પાડવાનો છે. અમારી ફી માત્ર ફોર્મ પ્રોસેસિંગ અને વ્યાવસાયિક સહાય માટે લેવામાં આવે છે.
          </div>

          <div className="space-y-2">
            <h5 className="font-heading font-black text-deep-indigo text-sm">રિફંડ નિયમો:</h5>
            <ul className="space-y-2">
              <li className="p-3 bg-gray-50 rounded-xl border border-gray-200 flex items-start gap-2.5">
                <Check className="w-4 h-4 text-field-green shrink-0 mt-0.5" />
                <span className="text-xs sm:text-sm font-medium">જો અમારા તરફથી ટેકનિકલ કારણોસર ફોર્મ સબમિટ ન થઈ શકે, તો લીધેલ સર્વિસ ચાર્જ ગ્રાહકને ૧૦૦% પરત કરવામાં આવશે.</span>
              </li>
              <li className="p-3 bg-gray-50 rounded-xl border border-gray-200 flex items-start gap-2.5">
                <Check className="w-4 h-4 text-field-green shrink-0 mt-0.5" />
                <span className="text-xs sm:text-sm font-medium">એકવાર સરકારી પોર્ટલ પર ફોર્મ સફળતાપૂર્વક સબમિટ થઈ ગયા પછી સર્વિસ ચાર્જ રિફંડપાત્ર રહેશે નહીં.</span>
              </li>
              <li className="p-3 bg-gray-50 rounded-xl border border-gray-200 flex items-start gap-2.5">
                <Check className="w-4 h-4 text-field-green shrink-0 mt-0.5" />
                <span className="text-xs sm:text-sm font-medium">ગ્રાહક દ્વારા અધૂરી કે ખોટી વિગતો આપવામાં આવે અને અરજી અટકે તો તેમાં સર્વિસ ચાર્જ પરત કરવામાં આવશે નહીં.</span>
              </li>
            </ul>
          </div>
        </div>
      )
    },
    about: {
      title: 'અમારા વિશે',
      englishTitle: 'About Us',
      badge: 'અગ્રણી એજન્સી',
      summary: 'ગુજરાતના નાગરિકો માટે વિશ્વસનીય ડિજિટલ સહાય અને માર્ગદર્શન પ્લેટફોર્મ.',
      icon: Info,
      fullContent: (
        <div className="space-y-4 text-xs sm:text-sm text-gray-700 leading-relaxed">
          <div className="bg-deep-indigo/5 border border-deep-indigo/15 rounded-xl p-4 flex gap-3 items-start">
            <Building className="w-5 h-5 text-turmeric-gold shrink-0 mt-0.5" />
            <p className="text-gray-800 font-semibold">
              <strong>STAR KING NETWORK</strong> એ ગુજરાતભરના નાગરિકો માટે સરકારી યોજના, ભરતી ફોર્મ, આઈ-ખેડૂત, સ્કૉલરશિપ અને કોલેજ એડમિશન સંબંધિત ઓનલાઈન કામગીરી ચોકસાઈપૂર્વક કરી આપતી અગ્રણી એજન્સી છે.
            </p>
          </div>

          <div className="space-y-2">
            <h5 className="font-heading font-black text-deep-indigo text-sm">અમારું મિશન:</h5>
            <p className="text-xs sm:text-sm text-gray-600 font-medium">
              ગામડાઓ અને શહેરોના સામાન્ય નાગરિકોને સાયબર કાફેના ધક્કા ખાધા વગર, ઘરે બેઠા પોતાના મોબાઈલ દ્વારા સરકારી લાભો અને ઓનલાઈન ફોર્મ્સ સરળતાથી અને ચોકસાઈપૂર્વક ભરી આપવા.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
            <div className="p-3 bg-wheat-cream/40 rounded-xl border border-deep-indigo/15">
              <span className="text-[11px] font-bold text-gray-500 uppercase block">મુખ્ય પ્લેટફોર્મ</span>
              <span className="text-sm font-black text-deep-indigo">ગુજરાત (ભારત)</span>
            </div>
            <div className="p-3 bg-wheat-cream/40 rounded-xl border border-deep-indigo/15">
              <span className="text-[11px] font-bold text-gray-500 uppercase block">સેવા માધ્યમ</span>
              <span className="text-sm font-black text-field-green">સંપૂર્ણ ઓનલાઈન સપોર્ટ</span>
            </div>
          </div>
        </div>
      )
    }
  };

  return (
    <div className="py-10 sm:py-16 bg-gradient-to-b from-wheat-cream/40 via-white to-wheat-cream/30 min-h-screen text-left">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        {/* 1. PAGE HEADER & ABOUT US HERO */}
        <div className="text-center space-y-4 max-w-3xl mx-auto">
          
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-deep-indigo/10 text-deep-indigo rounded-full text-xs font-black border border-deep-indigo/15 shadow-2xs">
            <Building className="w-3.5 h-3.5 text-turmeric-gold" />
            <span>સત્તાવાર પોર્ટલ માહિતી અને નીતિઓ</span>
          </div>

          <div className="space-y-1">
            <h1 className="text-2xl sm:text-4xl font-heading font-black text-deep-indigo tracking-tight">
              STAR KING NETWORK
            </h1>
            <p className="text-xs sm:text-sm font-extrabold text-turmeric-gold uppercase tracking-widest font-heading">
              Digital Service Platform
            </p>
          </div>

          <p className="text-sm sm:text-base text-gray-600 font-semibold leading-relaxed max-w-xl mx-auto">
            “ગુજરાતભરના નાગરિકો માટે ઓનલાઈન સેવા સહાય પ્લેટફોર્મ”
          </p>

        </div>

        {/* 2. ABOUT US HIGHLIGHT CARD */}
        <div className="bg-white rounded-2xl border border-deep-indigo/15 p-6 sm:p-8 shadow-sm space-y-6">
          <div className="flex items-center gap-3 border-b border-gray-100 pb-4">
            <div className="w-10 h-10 rounded-xl bg-deep-indigo text-white flex items-center justify-center shrink-0 shadow-xs">
              <Info className="w-5 h-5 text-turmeric-gold" />
            </div>
            <div>
              <h2 className="text-xl font-heading font-black text-deep-indigo">
                અમારા વિશે (About Us)
              </h2>
              <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
                ઓનલાઇન સેવા કેન્દ્ર પરિચય
              </p>
            </div>
          </div>

          <p className="text-sm sm:text-base text-gray-700 leading-relaxed font-semibold">
            સ્ટાર કિંગ નેટવર્ક એ ગુજરાતભરના નાગરિકો માટે સરકારી યોજના, ભરતી ફોર્મ, આઈ-ખેડૂત, સ્કૉલરશિપ અને કોલેજ એડમિશન સંબંધિત ઓનલાઈન કામગીરી ચોકસાઈપૂર્વક કરી આપતી અગ્રણી એજન્સી છે.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div className="p-4 rounded-xl bg-wheat-cream/30 border border-deep-indigo/10 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-deep-indigo text-white flex items-center justify-center shrink-0">
                <Building className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-gray-400 uppercase">કાર્યક્ષેત્ર</span>
                <p className="text-xs sm:text-sm font-extrabold text-deep-indigo">મુખ્ય પ્લેટફોર્મ: ગુજરાત (ભારત)</p>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-wheat-cream/30 border border-deep-indigo/10 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-field-green text-white flex items-center justify-center shrink-0">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-gray-400 uppercase">સુવિધા પ્રકાર</span>
                <p className="text-xs sm:text-sm font-extrabold text-field-green">સેવા: ઓનલાઈન સપોર્ટ</p>
              </div>
            </div>
          </div>
        </div>

        {/* 3. CONTACT INFORMATION */}
        <div id="contact-section">
          <ContactCard />
        </div>

        {/* 4. SERVICE GUIDE CARD */}
        <div>
          <ServiceGuideCard />
        </div>

        {/* 5. POLICIES SECTION WITH READ MORE CARDS */}
        <div id="policies-section" className="space-y-4">
          <div className="flex items-center justify-between border-b border-deep-indigo/10 pb-3">
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest text-turmeric-gold bg-turmeric-gold/10 px-2.5 py-0.5 rounded-full border border-turmeric-gold/20">
                કાનૂની અને નિયમો
              </span>
              <h3 className="text-xl font-heading font-black text-deep-indigo tracking-tight mt-1">
                પોલિસી અને નિયમો (Policies & Terms)
              </h3>
            </div>
            <span className="text-xs text-gray-500 font-bold hidden sm:inline-block">
              પારદર્શક અને સુરક્ષિત સેવા
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <PolicyCard
              id="privacy"
              title="🛡 ગોપનીયતા નીતિ"
              englishTitle="Privacy Policy"
              description="તમારા દ્વારા સબમિટ કરવામાં આવતા દસ્તાવેજો અને વ્યક્તિગત ડેટાની કડક સુરક્ષા અને ગોપનીયતા."
              iconName="privacy"
              badge="૧૦૦% સુરક્ષિત"
              onReadMore={(id) => setSelectedPolicy(id)}
            />

            <PolicyCard
              id="terms"
              title="⚖ નિયમો અને શરતો"
              englishTitle="Terms & Conditions"
              description="પ્લેટફોર્મ ઉપયોગ, ઓનલાઇન ફોર્મ્સ, અને ગ્રાહક સેવા સહાય સંબંધિત તમામ નિયમો."
              iconName="terms"
              badge="સેવા નિયમો"
              onReadMore={(id) => setSelectedPolicy(id)}
            />

            <PolicyCard
              id="refund"
              title="💰 રિફંડ પોલિસી"
              englishTitle="Refund Policy"
              description="સેવા શુલ્ક, ઓનલાઇન પ્રોસેસિંગ અને રદ કરવા સંબંધિત પારદર્શક રિફંડ નિયમો."
              iconName="refund"
              badge="પારદર્શક"
              onReadMore={(id) => setSelectedPolicy(id)}
            />

            <PolicyCard
              id="about"
              title="ℹ અમારા વિશે"
              englishTitle="About Us"
              description="સ્ટાર કિંગ નેટવર્કનો ઉદ્દેશ્ય, સેવા કાર્યક્ષેત્ર અને વિશ્વસનીય ડિજિટલ સહાય."
              iconName="about"
              badge="વિશ્વસનીય"
              onReadMore={(id) => setSelectedPolicy(id)}
            />
          </div>

          {/* ACTIVE EXPANDED POLICY MODAL / ACCORDION DETAIL */}
          {selectedPolicy && (
            <div className="mt-6 p-6 bg-white rounded-2xl border-2 border-deep-indigo/25 shadow-lg space-y-4 animate-fade-in relative">
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-deep-indigo text-white flex items-center justify-center">
                    {React.createElement(policiesData[selectedPolicy].icon, { className: 'w-4 h-4 text-turmeric-gold' })}
                  </div>
                  <div>
                    <h4 className="text-base font-heading font-black text-deep-indigo">
                      {policiesData[selectedPolicy].title}
                    </h4>
                    <p className="text-[10px] font-bold uppercase text-gray-400">
                      {policiesData[selectedPolicy].englishTitle}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setSelectedPolicy(null)}
                  className="p-1.5 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-700 transition-colors cursor-pointer"
                  title="બંધ કરો"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {policiesData[selectedPolicy].fullContent}

              <div className="pt-2 text-right">
                <button
                  type="button"
                  onClick={() => setSelectedPolicy(null)}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-bold rounded-lg cursor-pointer"
                >
                  બંધ કરો (Close)
                </button>
              </div>
            </div>
          )}
        </div>

        {/* 6. IMPORTANT DISCLAIMER */}
        <div>
          <DisclaimerCard />
        </div>

        {/* 7. IMPORTANT LINKS */}
        <div>
          <ImportantLinks onNavigate={onNavigate} />
        </div>

        {/* 8. DIGITAL ASSISTANT SIGN-OFF */}
        <div className="pt-6 border-t border-deep-indigo/10 text-center space-y-1">
          <div className="inline-flex items-center gap-1.5 text-xs font-extrabold text-gray-600">
            <Bot className="w-4 h-4 text-turmeric-gold" />
            <span>ડિજિટલ સહાયક:</span>
            <span className="text-deep-indigo font-black">સ્ટાર કિંગ નેટવર્ક</span>
          </div>
          <p className="text-[11px] text-gray-400 font-medium">
            ગુજરાતના નાગરિકો માટે હંમેશા તત્પર ડિજિટલ સહાયક
          </p>
        </div>

      </div>
    </div>
  );
}
