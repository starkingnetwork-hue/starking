# APK banavvani rit (GitHub thi, free)

1. github.com par free account banavo -> New repository (Private chalse).
2. Aa poori folder (zip extract kari ne) repository ma upload karo.
   (.github folder sathe upload thavu joiye)
3. Repository ma "Actions" tab -> "Build Android APK" -> "Run workflow".
4. 5-10 minute pachi run purn thay etle "Artifacts" ma "star-king-apk" download karo.
5. Zip ma app-debug.apk male. Phone ma install karo.
