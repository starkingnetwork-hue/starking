import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

/**
 * Health Check API
 */
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'Star King Connect (SC) Server',
    timestamp: new Date().toISOString()
  });
});

/**
 * Vite Dev Server & Static Asset Serving Setup
 */
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Star King Connect (SC) Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
