// ============================================================================
// [LEGACY / REFERENCE ONLY] Google Apps Script for STAR KING NETWORK
// ============================================================================
// STATUS: NOT USED IN PRODUCTION.
// ARCHITECTURE NOTE:
// Star King Connect (SC) uses SC Firebase (Firestore & Authentication) directly.
// The frontend does NOT connect to script.google.com or execute this script.
//
// This file is archived for historical reference only.
// Direct Google Apps Script execution and web app endpoints are disabled in SC.
// ============================================================================

/**
 * Scans the first row of the sheet to map standard header names to column indices.
 * If any of the essential headers are missing, it appends them to the end of row 1,
 * ensuring no column shifting or misaligning occurs for existing columns.
 */
function getHeaderIndices(sheet) {
  var lastColumn = sheet.getLastColumn();
  
  // If the sheet is completely empty, initialize it with default headers
  if (lastColumn === 0) {
    var defaultHeaders = [
      "Application ID", 
      "Timestamp", 
      "Full Name", 
      "Mobile", 
      "Village", 
      "Taluka", 
      "District", 
      "Service", 
      "Message", 
      "Status"
    ];
    sheet.appendRow(defaultHeaders);
    lastColumn = defaultHeaders.length;
  }
  
  var headers = sheet.getRange(1, 1, 1, lastColumn).getValues()[0];
  var indices = {
    id: -1,
    createdAt: -1,
    fullName: -1,
    mobileNumber: -1,
    village: -1,
    taluka: -1,
    district: -1,
    serviceRequired: -1,
    message: -1,
    status: -1,
    notes: -1
  };
  
  for (var i = 0; i < headers.length; i++) {
    var h = headers[i].toString().trim().toLowerCase();
    if (!h) continue;
    
    var colNum = i + 1;
    
    if (h === "application id" || h === "id" || h === "app id" || h === "uid") {
      indices.id = colNum;
    } else if (h === "timestamp" || h === "date" || h === "createdat" || h === "created_at") {
      indices.createdAt = colNum;
    } else if (h === "full name" || h === "fullname" || h === "name") {
      indices.fullName = colNum;
    } else if (h === "mobile" || h === "mobilenumber" || h === "mobile number" || h === "phone" || h === "contact") {
      indices.mobileNumber = colNum;
    } else if (h === "village" || h === "village name") {
      indices.village = colNum;
    } else if (h === "taluka" || h === "taluko" || h === "subdistrict" || h === "sub-district") {
      indices.taluka = colNum;
    } else if (h === "district" || h === "dist") {
      indices.district = colNum;
    } else if (h === "service" || h === "servicerequired" || h === "service required" || h === "service_required") {
      indices.serviceRequired = colNum;
    } else if (h === "message" || h === "msg" || h === "details") {
      indices.message = colNum;
    } else if (h === "status" || h === "state") {
      indices.status = colNum;
    } else if (h === "notes" || h === "remarks") {
      indices.notes = colNum;
    }
  }
  
  // Auto-create missing headers at the end of the header row (prevents shifting of existing columns!)
  var essentials = [
    { key: "id", name: "Application ID" },
    { key: "createdAt", name: "Timestamp" },
    { key: "fullName", name: "Full Name" },
    { key: "mobileNumber", name: "Mobile" },
    { key: "village", name: "Village" },
    { key: "taluka", name: "Taluka" },
    { key: "district", name: "District" },
    { key: "serviceRequired", name: "Service" },
    { key: "message", name: "Message" },
    { key: "status", name: "Status" }
  ];
  
  for (var j = 0; j < essentials.length; j++) {
    var item = essentials[j];
    if (indices[item.key] === -1) {
      lastColumn++;
      sheet.getRange(1, lastColumn).setValue(item.name);
      indices[item.key] = lastColumn;
    }
  }
  
  return indices;
}

/**
 * Handles GET requests to retrieve submissions.
 * Supports secure admin fetch (requires password) and secure customer tracking (requires ID and Mobile number).
 */
function doGet(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    var indices = getHeaderIndices(sheet);
    var lastRow = sheet.getLastRow();
    
    if (lastRow <= 1) {
      return ContentService.createTextOutput(JSON.stringify([]))
        .setMimeType(ContentService.MimeType.JSON);
    }
    
    var email = e && e.parameter && e.parameter.email;
    var password = e && e.parameter && e.parameter.password;
    var action = e && e.parameter && e.parameter.action;
    var reqId = e && e.parameter && e.parameter.id;
    var reqMobile = e && e.parameter && e.parameter.mobile;
    
    var scriptProperties = PropertiesService.getScriptProperties();
    var storedAdminEmail = scriptProperties.getProperty("ADMIN_EMAIL") || "admin@starkingnetwork.com";
    var storedAdminPassword = scriptProperties.getProperty("ADMIN_PASSWORD");
    var isAdmin = Boolean(storedAdminPassword && email === storedAdminEmail && password === storedAdminPassword);
    var isTrack = (action === "track" || (reqId && reqMobile));
    
    if (!isAdmin && !isTrack) {
      return ContentService.createTextOutput(JSON.stringify({ error: "અનધિકૃત વિનંતી (Unauthorized Request)" }))
        .setMimeType(ContentService.MimeType.JSON);
    }
    
    var lastColumn = sheet.getLastColumn();
    var data = sheet.getRange(2, 1, lastRow - 1, lastColumn).getValues();
    var jsonArray = [];
    
    for (var i = 0; i < data.length; i++) {
      var row = data[i];
      var record = {};
      
      for (var key in indices) {
        var colIndex = indices[key];
        if (colIndex !== -1 && colIndex <= row.length) {
          record[key] = row[colIndex - 1];
        } else {
          record[key] = "";
        }
      }
      
      var recordId = (record.id || "").toString().trim().replace('#', '').toLowerCase();
      var recordMobile = (record.mobileNumber || "").toString().trim();
      
      // Heuristic 1-column shift fallback checking:
      var isIdPattern = function(val) { return /^SKN\d+$/i.test(String(val).trim()); };
      var rawCreatedAt = (record.createdAt || "").toString().trim();
      var rawFullName = (record.fullName || "").toString().trim();
      
      if (isIdPattern(rawCreatedAt) && !isIdPattern(recordId)) {
        recordId = rawCreatedAt.toLowerCase().replace('#', '');
        recordMobile = rawFullName;
      }
      
      if (isAdmin) {
        jsonArray.push(record);
      } else if (isTrack) {
        var queryId = String(reqId || "").trim().replace('#', '').toLowerCase();
        var queryMobile = String(reqMobile || "").trim();
        
        if (recordId === queryId && recordMobile === queryMobile) {
          jsonArray.push(record);
        }
      }
    }
    
    if (isAdmin) {
      jsonArray.reverse();
    }
    
    return ContentService.createTextOutput(JSON.stringify(jsonArray))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({ error: error.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Handles POST requests to append a new submission.
 * Correctly inserts values into designated columns matching headers, regardless of column order.
 */
function doPost(e) {
  try {
    var postData = JSON.parse(e.postData.contents);
    
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    var indices = getHeaderIndices(sheet);
    
    // Calculate the next sequential ID
    var lastRow = sheet.getLastRow();
    var nextNum = 1;
    
    if (lastRow > 1 && indices.id !== -1) {
      var ids = sheet.getRange(2, indices.id, lastRow - 1, 1).getValues();
      var maxNum = 0;
      for (var i = 0; i < ids.length; i++) {
        var idStr = ids[i][0].toString().trim();
        var match = idStr.match(/^SKN(\d+)$/i);
        if (match) {
          var num = parseInt(match[1], 10);
          if (num > maxNum) {
            maxNum = num;
          }
        }
      }
      nextNum = maxNum + 1;
    }
    var applicationId = "SKN" + String(nextNum).padStart(6, '0');
    
    // Parse form input fields with fallbacks
    var dateStr = postData.date || new Date().toLocaleString("en-US", { timeZone: "Asia/Kolkata" });
    var fullName = postData.fullName || "";
    var mobile = postData.mobile || postData.mobileNumber || "";
    var village = postData.village || "";
    var taluka = postData.taluka || "";
    var district = postData.district || "";
    var service = postData.service || postData.serviceRequired || "";
    var message = postData.message || "";
    var status = postData.status || "સબમિટ કરેલ";
    
    var nextRow = lastRow + 1;
    
    var valuesMap = {
      id: applicationId,
      createdAt: dateStr,
      fullName: fullName,
      mobileNumber: mobile,
      village: village,
      taluka: taluka,
      district: district,
      serviceRequired: service,
      message: message,
      status: status
    };
    
    // Write values to their correct headers, maintaining column integrity
    for (var key in indices) {
      var colIndex = indices[key];
      if (colIndex !== -1) {
        sheet.getRange(nextRow, colIndex).setValue(valuesMap[key] || "");
      }
    }
    
    return ContentService.createTextOutput(JSON.stringify({ 
      success: true, 
      id: applicationId
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({ 
      success: false, 
      error: error.toString() 
    })).setMimeType(ContentService.MimeType.JSON);
  }
}
